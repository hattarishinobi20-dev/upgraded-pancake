from io import BufferedReader, BytesIO
import socket
import zlib

sockets = {}

class cryptoInfo:
    cryptobytesPosition = -1
    changed = False

class Pkt:
    def __init__(self, client, endian: str = 'big'):
        self.client = getattr(client, 'client', client)
        self.endian = endian
        self.buffer = b''
        self._bit = 0

    def _bits(self):
        self._bit = 0

    def wintLE(self, data, length=4):
        self._bits()
        self.buffer += data.to_bytes(length, 'little')

    def wi8(self, data):
        self.wint(data, 1)

    def wi16(self, data):
        self.wint(data, 2)

    def wi24(self, data):
        self.wint(data, 3)

    def _wmultibool(self, *args):
        boolean = 0
        i = 0
        for value in args:
            if value:
                boolean |= 1 << i
            i += 1
        self.wbyte(boolean)
        self._bits()

    def wint(self, data: int, length: int = 4):
        self._bits()
        if data > 0:
            self.buffer += data.to_bytes(length, 'big', signed=False)
        else:
            self.buffer += data.to_bytes(length, 'big', signed=True)

    def wuint(self, data: int, length: int = 1):
        self._bits()
        self.buffer += data.to_bytes(length, 'big', signed=False)

    def wu8(self, integer: int):
        self.wuint(integer)

    def wlong(self, high, low):
        self._bits()
        self.buffer += high.to_bytes(4, 'big') + low.to_bytes(4, 'big')

    def wvlong(self, high, low):
        self._bits()
        self.wvint(high)
        self.wvint(low)

    def warray(self, vintArray: list):
        self._bits()
        self.wvint(len(vintArray))
        for i in vintArray:
            self.wvint(i)

    def wbool(self, *args):
        if len(args) == 1:
            if self._bit == 0:
                self.buffer += b'\x00'
            if args[0]:
                self.buffer = self.buffer[:-1] + bytes((self.buffer[-1] | (1 << self._bit),))
            self._bit = (self._bit + 1) & 7
        else:
            self._wmultibool(args)

    def wstrz(self, data: bytes):
        self._bits()
        compressed = zlib.compress(data)
        self.wint(len(compressed) + 4)
        self.wintLE(len(data))
        self.buffer += compressed

    def whex(self, data):
        self._bits()
        if data:
            if data.startswith('0x'):
                data = data[2:]
            self.buffer += bytes.fromhex(''.join(data.split()).replace('-', ''))

    def wvint(self, data, rotate: bool = True):
        self._bits()
        final = b''
        if data == 0:
            self.wbyte(0)
        elif data < 0:
            self.wvint((2147483648 * 2) + data)
        else:
            data = (data << 1) ^ (data >> 31)
            while data:
                b = data & 0x7f

                if data >= 0x80:
                    b |= 0x80
                if rotate:
                    rotate = False
                    lsb = b & 0x1
                    msb = (b & 0x80) >> 7
                    b >>= 1
                    b = b & ~0xC0
                    b = b | (msb << 7) | (lsb << 6)
                final += b.to_bytes(1, 'big')
                data >>= 7
        self.buffer += final

    def wstr(self, string = None):
        self._bits()
        if string is None:
            self.wint((2 ** 32) - 1)
        else:
            if type(string) == bytes:
                encoded = string
            else:
                encoded = string.encode('utf-8')
            self.wint(len(encoded))
            self.buffer += encoded

    def wstrref(self, string: str = None):
        self._bits()
        encoded = string.encode('utf-8')
        self.wi16(0)
        self.wvint(len(encoded))
        self.buffer += encoded

    def wbyte(self, data):
        self._bits()
        if data > 255:
            self.buffer += data.to_bytes(2, 'big', signed=False)
        elif data > 127:
            self.buffer += data.to_bytes(1, 'big', signed=False)
        else:
            self.buffer += data.to_bytes(1, 'big', signed=True)

    def wbytes(self, data):
        self._bits()
        self.buffer += data

    def wref(self, x, y):
        self._bits()
        if x == 0:
            self.wvint(0)
        else:
            self.wvint(x)
            self.wvint(y)

    def warray(self, array):
        self.wvint(len(array))
        for i in array:
            self.wvint(i)

    def send(self, PlayerLowID, cryptoBytesEnd: int = 1):
        self.encode()
        self._bits()
        packet = self.buffer
        self.buffer = self.id.to_bytes(2, 'big', signed=True)
        self.wi24(len(packet))
        if hasattr(self, 'version'):
            self.wi16(self.version)
        else:
            self.version = 0
            self.wi16(0)

        print(f"→ {self.id} {self.__class__.__name__} ({len(packet)}b)")
        crypto_bytes = b'\xff\xff\x00\x00\x00\x00\x00'
        if cryptoInfo.changed == False:
            cryptoInfo.cryptobytesPosition = cryptoBytesEnd
            cryptoInfo.changed = True

        if cryptoInfo.cryptobytesPosition == 0:
            crypto_bytes += self.buffer + packet
        elif cryptoInfo.cryptobytesPosition == 1:
            crypto_bytes = self.buffer + packet + crypto_bytes
        elif cryptoInfo.cryptobytesPosition == 2:
            crypto_bytes = self.buffer + packet

        try:
            if self.id == 23457:
                self.client.sendall(crypto_bytes)
                return
            if PlayerLowID in sockets:
                sockets[PlayerLowID].sendall(crypto_bytes)
            else:
                self.client.sendall(crypto_bytes)
        except KeyError:
            pass

class Buf(BufferedReader):
    def __init__(self, header_bytes):
        super().__init__(BytesIO(header_bytes))
        self.bytes_of_packets = header_bytes
        self._bit = 0
        self._last = b'\x00'

    def _bits(self):
        self._bit = 0

    def rbool(self):
        if self._bit == 0:
            self._last = self.read(1) or b'\x00'
        value = (self._last[0] & (1 << self._bit)) != 0
        self._bit = (self._bit + 1) & 7
        return value

    def rbyte(self):
        self._bits()
        return int.from_bytes(self.read(1), "big")

    def rbytes(self, length):
        self._bits()
        return self.read(length)

    def rintLE(self):
        self._bits()
        return int.from_bytes(self.read(4), "little")

    def rint(self):
        self._bits()
        return int.from_bytes(self.read(4), "big")

    def ri8(self):
        self._bits()
        return int.from_bytes(self.read(1), "big")

    def ri16(self):
        self._bits()
        return int.from_bytes(self.read(2), "big")

    def ri24(self):
        self._bits()
        return int.from_bytes(self.read(3), "big")

    def rvint(self):
        self._bits()
        n = self.rvarint(True)
        return (n >> 1) ^ (-(n & 1))

    def rvlong(self):
        self._bits()
        ID = []
        ID.append(self.rvint())
        ID.append(self.rvint())
        return ID

    def rshort(self, length=2):
        self._bits()
        return int.from_bytes(self.read(length), "big")

    def rlong(self):
        self._bits()
        high = self.rint()
        low = self.rint()
        return [high, low]

    def rstrz(self):
        self._bits()
        self.rint()
        data_length = self.rintLE()

        compressed = self.rbytes(data_length)

        return zlib.decompress(compressed)

    def rstrref(self):
        self._bits()
        return self.rstr()

    def rui8(self):
        self._bits()
        return self.ruint()

    def ruint(self, length: int = 1, endian: str = 'big'):
        self._bits()
        result = 0
        i = 0
        for x in range(length):
            byte = self.bytes_of_packets[i]

            bit_padding = x * 8
            if endian == 'big':
                bit_padding = (8 * (length - 1)) - bit_padding

            result |= byte << bit_padding
            i += 1

        return result

    def rstrbot(self):
        self._bits()
        lenght = self.rvint()
        if lenght == pow(2, 32) - 1:
            return b""
        else:
            try:
                decoded = self.read(lenght)
            except MemoryError:
                raise IndexError("String out of range.")
            else:
                return decoded.decode('utf-8')

    def rstr(self):
        self._bits()
        lenght = self.rint()
        (pow(2, 32) - 1)
        if lenght == pow(2, 32) - 1:
            return b""
        else:
            try:
                decoded = self.read(lenght)
            except MemoryError:
                raise IndexError("String out of range.")
            else:
                return decoded.decode('utf-8')

    def rref(self):
        self._bits()
        high = self.rvint()
        low = self.rvint()
        if (high):
            return high * 1000000 + low
        else:
            return 0

    def rrefd(self):
        self._bits()
        high = self.rvint()
        if high == 0:
            return 0
        low = self.rvint()
        return [high, low]

    def rvarint(self, rotate: bool = True):
        self._bits()
        result = 0
        shift = 0
        while True:
            byte = self.rbyte()
            if rotate and shift == 0:
                seventh = (byte & 0x40) >> 6
                msb = (byte & 0x80) >> 7
                n = byte << 1
                n = n & ~0x181
                byte = n | (msb << 7) | seventh
            result |= (byte & 0x7f) << shift
            shift += 7
            if not (byte & 0x80):
                break
        return result
