import random

from G.BattlePlayer import BattlePlayer, BOT_BRAWLERS
from G.BattleMode import BattleMode
from M.Battle.StartLoadingMessage import StartLoadingMessage

TRAINING_LOCATION_GID = 15000121
TRAINING_GMV          = 13
TRAINING_BOTS         = 0

def start(connection, character_global_id: int, skin_global_id: int = 0):
    connection.character_global_id = character_global_id
    connection.skin_global_id      = skin_global_id

    players: list[BattlePlayer] = []

    human = BattlePlayer.create(
        client_socket       = connection.client,
        player_index        = 0,
        team_index          = 0,
        name                = getattr(connection, 'player_name', 'BSWS'),
        character_global_id = character_global_id,
        account_id          = getattr(connection, 'account_id', 1),
        skin_global_id      = skin_global_id,
        hero_power_level    = getattr(connection, 'hero_power_level', 9),
    )
    players.append(human)

    used = [character_global_id]
    for i in range(1, TRAINING_BOTS + 1):
        bot_gid = None
        for _ in range(20):
            c = 16000000 + random.choice(BOT_BRAWLERS)
            if c not in used:
                bot_gid = c
                break
        bot_gid = bot_gid or (16000000 + random.choice(BOT_BRAWLERS))
        used.append(bot_gid)
        bot = BattlePlayer.create_bot(i, 1, bot_gid)
        players.append(bot)

    battle = BattleMode(TRAINING_LOCATION_GID, TRAINING_GMV, players)
    battle.start()

    try:
        StartLoadingMessage(
            client             = connection.client,
            players            = players,
            own_index          = 0,
            team_index         = 0,
            location_global_id = TRAINING_LOCATION_GID,
            gmv                = TRAINING_GMV,
            game_type          = 8,
            msg_game_mode      = TRAINING_GMV,
        ).send(0)
        battle.register_connection(connection, 0)
    except Exception as exc:
        print(f'[Training] {exc}')
