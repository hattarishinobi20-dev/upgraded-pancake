import csv
import os

_BASE      = os.path.join(os.path.dirname(__file__), '..', 'Assets')
_LOGIC_DIR = os.path.join(_BASE, 'csv_logic')

_HP_FALLBACK = {
    0:  3800,  1:  2800,  2:  5000,  3:  2600,  4:  2600,
    5:  2400,  6:  2400,  7:  3200,  8:  4000,  9:  2800,
    10: 6000,  11: 3800,  12: 2400,  13: 4000,  14: 3600,
    15: 2400,  16: 4800,  17: 3400,  18: 5000,  19: 3200,
    20: 6400,  21: 3400,  22: 2200,  23: 3200,  24: 5400,
    25: 4400,  26: 3800,  27: 4800,  28: 3800,  29: 2400,
    50: 100000,
}

_SPEED_FALLBACK = {
    0:  720,  1:  720,  2:  770,  3:  720,  4:  720,
    5:  720,  6:  720,  7:  720,  8:  720,  9:  720,
    10: 770,  11: 820,  12: 820,  13: 720,  14: 720,
    15: 720,  16: 720,  17: 720,  18: 770,  19: 720,
    20: 770,  21: 720,  22: 720,  23: 820,  24: 770,
    25: 720,  26: 820,  27: 580,  28: 770,  29: 820,
}

_LOCATION_MAP: dict[int, str] = {}
_LOCATION_MODE: dict[int, str] = {}

_GMV_NAME_TO_INT = {
    "GemGrab":      0,  "Heist":         2,  "Bounty":        3,
    "BrawlBall":    5,  "Showdown":      6,  "BigGame":       7,
    "RoboRumble":   8,  "DuoShowdown":   9,  "BossFight":    10,
    "Siege":       11,  "Tutorial":     12,  "Training":     13,
    "Takedown":    14,  "LoneStar":     15,  "CTF":          16,
    "KingOfHill":  17,
}

_CHARACTERS:      list[dict]      = []
_CHARACTERS_BY_NAME: dict[str, dict] = {}
_TILES_BY_CODE:   dict[str, dict] = {}
_TILES_BY_NAME:   dict[str, dict] = {}
_TILES_DEFAULT:   dict            = {}
_PROJECTILES:     dict[str, dict] = {}
_AREA_EFFECTS:    dict[str, dict] = {}
_ITEMS:           dict[str, dict] = {}
_SKILLS:          dict[str, dict] = {}
_GAME_MODE_VARIATIONS: dict[str, int] = {}
_ACCESSORIES:     dict[str, dict] = {}
_GEARS:           dict[str, dict] = {}
_CARDS:           dict[str, dict] = {}
_MAPS:            dict[int, list] = {}
_MAPS_BY_NAME:    dict[str, list] = {}


def _read_table(name: str) -> list[dict]:
    path = os.path.join(_LOGIC_DIR, name + '.csv')
    if not os.path.exists(path):
        return []
    rows: list[dict] = []
    with open(path, newline='', encoding='utf-8') as handle:
        reader = csv.reader(handle)
        try:
            header = next(reader)
            next(reader)
        except StopIteration:
            return rows
        for values in reader:
            if not values or not values[0].strip():
                continue
            row = {}
            for index, column in enumerate(header):
                row[column] = values[index].strip() if index < len(values) else ''
            rows.append(row)
    return rows


def _str(row: dict, column: str, default: str = '') -> str:
    value = row.get(column, '')
    return value if value else default


def _int(row: dict, column: str, default: int = 0) -> int:
    value = row.get(column, '')
    if not value:
        return default
    try:
        return int(float(value))
    except ValueError:
        return default


def _bool(row: dict, column: str, default: bool = False) -> bool:
    value = row.get(column, '').lower()
    if not value:
        return default
    return value == 'true'


def _load_characters():
    global _CHARACTERS
    _CHARACTERS = _read_table('characters')
    for instance_id, row in enumerate(_CHARACTERS):
        name    = _str(row, 'Name')
        kind    = _str(row, 'Type')
        hp      = _int(row, 'Hitpoints')
        speed   = _int(row, 'Speed')
        if hp <= 0:
            hp = _HP_FALLBACK.get(instance_id, 3800)
        if speed <= 0:
            speed = _SPEED_FALLBACK.get(instance_id, 720)
        row['_instance']  = instance_id
        row['_name']      = name
        row['_type']      = kind
        row['_hp']        = hp
        row['_speed']     = speed
        _CHARACTERS_BY_NAME[name] = row


def _load_tiles():
    for row in _read_table('tiles'):
        code = _str(row, 'TileCode')
        if code:
            row['_code'] = code[0]
            _TILES_BY_CODE.setdefault(code[0], row)
        _TILES_BY_NAME[_str(row, 'Name')] = row


def _load_projectiles():
    for instance_id, row in enumerate(_read_table('projectiles')):
        row['_instance'] = instance_id
        _PROJECTILES[_str(row, 'Name')] = row


def _load_area_effects():
    for instance_id, row in enumerate(_read_table('area_effects')):
        row['_instance'] = instance_id
        _AREA_EFFECTS[_str(row, 'Name')] = row


def _load_items():
    for instance_id, row in enumerate(_read_table('items')):
        row['_instance'] = instance_id
        _ITEMS[_str(row, 'Name')] = row


def _load_accessories():
    for instance_id, row in enumerate(_read_table('accessories')):
        row['_instance'] = instance_id
        _ACCESSORIES[_str(row, 'Name')] = row


def _load_skills():
    for instance_id, row in enumerate(_read_table('skills')):
        row['_instance'] = instance_id
        _SKILLS[_str(row, 'Name')] = row


def _load_gears():
    for instance_id, row in enumerate(_read_table('gear_boosts')):
        row['_instance'] = instance_id
        _GEARS[_str(row, 'Name')] = row


def _load_cards():
    for instance_id, row in enumerate(_read_table('cards')):
        row['_instance'] = instance_id
        _CARDS[_str(row, 'Name')] = row


def _load_game_mode_variations():
    for row in _read_table('game_mode_variations'):
        name = _str(row, 'Name')
        if name:
            _GAME_MODE_VARIATIONS[name] = _int(row, 'Variation')


def _load_locations():
    path = os.path.join(_LOGIC_DIR, 'locations.csv')
    if not os.path.exists(path):
        return
    for instance_id, row in enumerate(_read_table('locations')):
        global_id = 15000000 + instance_id
        _LOCATION_MAP[global_id]  = _str(row, 'Map')
        _LOCATION_MODE[global_id] = _str(row, 'GameModeVariation')


def _load_maps():
    path = os.path.join(_LOGIC_DIR, 'maps.csv')
    if not os.path.exists(path):
        return
    with open(path, newline='', encoding='utf-8') as handle:
        reader = csv.reader(handle)
        next(reader, None)
        next(reader, None)
        current_name = None
        current_rows: list[str] = []
        for values in reader:
            if len(values) < 2:
                continue
            name = values[0].strip()
            data = values[1]
            if name:
                if current_name and current_rows:
                    _MAPS_BY_NAME[current_name] = current_rows
                current_name = name
                current_rows = [data]
            elif current_name and data:
                current_rows.append(data)
        if current_name and current_rows:
            _MAPS_BY_NAME[current_name] = current_rows

    for global_id, map_name in _LOCATION_MAP.items():
        rows = _MAPS_BY_NAME.get(map_name)
        if rows:
            _MAPS[global_id] = rows


_load_characters()
_load_game_mode_variations()
_load_locations()
_load_tiles()
_load_projectiles()
_load_area_effects()
_load_items()
_load_skills()
_load_accessories()
_load_gears()
_load_cards()
_load_maps()


def character_data(instance_id: int) -> dict | None:
    if 0 <= instance_id < len(_CHARACTERS):
        return _CHARACTERS[instance_id]
    return None


def character_data_by_name(name: str) -> dict | None:
    return _CHARACTERS_BY_NAME.get(name)


def character_instance_by_name(name: str) -> int:
    row = _CHARACTERS_BY_NAME.get(name)
    return row['_instance'] if row else 0


def get_character_hp(instance_id: int) -> int:
    row = character_data(instance_id)
    if row:
        return row['_hp']
    return _HP_FALLBACK.get(instance_id, 3800)


def get_character_speed(instance_id: int) -> int:
    row = character_data(instance_id)
    if row:
        return row['_speed']
    return _SPEED_FALLBACK.get(instance_id, 720)


def get_character_name(instance_id: int) -> str:
    row = character_data(instance_id)
    return row['_name'] if row else ''


def is_hero(instance_id: int) -> bool:
    row = character_data(instance_id)
    return bool(row) and row['_type'] == 'Hero'


def is_base(instance_id: int) -> bool:
    row = character_data(instance_id)
    return bool(row) and row['_type'] == 'Pvp_Base'


def has_auto_attack(instance_id: int) -> bool:
    row = character_data(instance_id)
    return bool(row) and _int(row, 'AutoAttackDamage') > 0


def has_very_much_hit_points(instance_id: int) -> bool:
    return get_character_hp(instance_id) > 5799


def tile_data(code: str) -> dict:
    return _TILES_BY_CODE.get(code, _TILES_DEFAULT)


def tile_data_by_name(name: str) -> dict:
    return _TILES_BY_NAME.get(name, _TILES_DEFAULT)


def tile_dynamic_data(dynamic_code: int) -> dict:
    for row in _TILES_BY_NAME.values():
        if _int(row, 'DynamicCode', -1) == dynamic_code:
            return row
    return _TILES_DEFAULT


def projectile_data(name: str) -> dict:
    return _PROJECTILES.get(name, {})


def area_effect_data(name: str) -> dict:
    return _AREA_EFFECTS.get(name, {})


def item_data(name: str) -> dict:
    return _ITEMS.get(name, {})


def skill_data(name: str) -> dict:
    return _SKILLS.get(name, {})


def accessory_data(name: str) -> dict:
    return _ACCESSORIES.get(name, {})


def gear_data(name: str) -> dict:
    return _GEARS.get(name, {})


def card_data(name: str) -> dict:
    return _CARDS.get(name, {})


def get_map_rows(location_global_id: int) -> list[str] | None:
    return _MAPS.get(location_global_id)


def get_map_rows_by_name(map_name: str) -> list[str] | None:
    return _MAPS_BY_NAME.get(map_name)


def get_location_gmv(location_global_id: int) -> int:
    return _GAME_MODE_VARIATIONS.get(_LOCATION_MODE.get(location_global_id, ''), -1)


def get_location_map_name(location_global_id: int) -> str | None:
    return _LOCATION_MAP.get(location_global_id)


def get_location_mode_name(location_global_id: int) -> str | None:
    return _LOCATION_MODE.get(location_global_id)


def gmv_name_to_int(name: str) -> int:
    return _GMV_NAME_TO_INT.get(name, 0)
