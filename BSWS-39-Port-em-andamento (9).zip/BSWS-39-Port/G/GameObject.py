from L.BitStream import BitStream
from G.LogicMath import clamp

OBJECT_TYPE_CHARACTER  = 0
OBJECT_TYPE_PROJECTILE = 1
OBJECT_TYPE_AREA       = 2
OBJECT_TYPE_ITEM       = 3

MAX_FADE_COUNTER = 10


class GameObject:
    __slots__ = (
        'data_id', 'data_class', 'data_instance',
        'object_global_id', 'clone_of_global_id',
        '_index', 'team_index',
        'x', 'y', 'z', 'render_z',
        'scale', 'uid',
        '_fade_counter',
        'is_in_realm',
        '_manager',
    )

    def __init__(self, data_class: int, data_instance: int):
        self.data_class           = data_class
        self.data_instance        = data_instance
        self.data_id              = data_class * 1000000 + data_instance
        self.object_global_id     = 0
        self.clone_of_global_id   = 0
        self._index               = 0
        self.team_index           = -1
        self.x                    = 0
        self.y                    = 0
        self.z                    = 0
        self.render_z             = -1
        self.scale                = 100
        self.uid                  = 0
        self._fade_counter        = MAX_FADE_COUNTER
        self.is_in_realm          = False
        self._manager             = None

    def attach(self, manager, global_id: int):
        self._manager         = manager
        self.object_global_id = global_id

    def get_manager(self):
        return self._manager

    def get_battle(self):
        return self._manager.battle if self._manager else None

    def get_ticks_gone(self) -> int:
        battle = self.get_battle()
        return battle.ticks if battle else 0

    def get_player(self):
        if not self._manager:
            return None
        battle = self._manager.battle
        team   = self._index // 16
        index  = self._index % 16
        for player in battle.players:
            if player.team_index == team and player.player_index == index:
                return player
        return None

    def get_viewer_player(self):
        if not self._manager:
            return None
        for player in self._manager.battle.players:
            if player.player_index == 0:
                return player
        return None

    def get_object_type(self) -> int:
        return -1

    def get_global_id(self) -> int:
        return self.object_global_id

    def get_clone_of_global_id(self) -> int:
        return self.clone_of_global_id

    def set_clone_of_global_id(self, value: int):
        self.clone_of_global_id = value

    def get_data_id(self) -> int:
        return self.data_id

    def get_index(self) -> int:
        return self._index

    def get_team_index(self) -> int:
        return self._index % 16

    def set_index(self, index: int):
        self._index = index

    def set_position(self, x: int, y: int, z: int = 0):
        self.x = x
        self.y = y
        self.z = z

    def get_fade_counter(self) -> int:
        return self._fade_counter

    def set_fade_counter(self, value: int):
        self._fade_counter = value

    def set_forced_visible(self):
        self._fade_counter = MAX_FADE_COUNTER

    def set_forced_invisible(self):
        self._fade_counter = 0

    def increment_fade(self):
        if self._fade_counter < MAX_FADE_COUNTER:
            self._fade_counter += 1

    def decrement_fade(self):
        if self._fade_counter > 0:
            self._fade_counter -= 1

    def is_alive(self) -> bool:
        return True

    def should_destruct(self) -> bool:
        return False

    def on_destruct(self):
        pass

    def reset_events(self):
        pass

    def tick(self):
        pass

    def get_radius(self) -> int:
        return self.scale

    def get_size(self) -> int:
        return 100

    def aligns_to_tiles(self) -> bool:
        return False

    def uses_raw_position(self) -> bool:
        return False

    def encode(self, bs: BitStream, is_own: bool, vision_team: int = 0):
        obj_type = self.get_object_type()

        if obj_type == OBJECT_TYPE_ITEM and self.aligns_to_tiles():
            bs.wpi6(self.x // 300)
            bs.wpi6(self.y // 300)
        else:
            if self.uses_raw_position():
                bs.wi16(self.x)
                bs.wi16(self.y)
            else:
                bs.wpvint65535(clamp(self.x, 0, 65535))
                bs.wpvint65535(clamp(self.y, 0, 65535))

            z = self.render_z if self.render_z != -1 else self.z
            bs.wpvint65535(clamp(z, 0, 65535))

        bs.write_positive_vint(self._index, 3)

        fade = self._fade_counter
        if obj_type == OBJECT_TYPE_CHARACTER:
            player = self.get_player()
            if is_own or (player is not None and player.team_index == vision_team):
                fade = 15

        if obj_type != OBJECT_TYPE_PROJECTILE:
            bs.wpi4(fade)
