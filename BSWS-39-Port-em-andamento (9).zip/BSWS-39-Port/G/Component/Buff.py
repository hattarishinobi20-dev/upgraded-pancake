DAMAGE          = 1
DAMAGE_AND_SIZE = 2
SPEED_SLOWER    = 3
SPEED_FASTER    = 4
DAMAGE2         = 5
HEALTH_REGEN    = 10
RUFFS_BUFF      = 13
BELLE_WEAPON    = 14
BELLE_ULTI      = 15

STACKABLE_TYPE          = HEALTH_REGEN
HOMING_RANGE            = 1200
SHIELD_GEAR_LOGIC_TYPE  = 19


class Buff:
    __slots__ = (
        'type', 'duration', 'start_duration', 'modifier', 'size_increase',
        'source_index', 'effect_type', 'normal_dmg', 'belle_weapon_bounces',
    )

    def __init__(self, type: int, duration: int, modifier: int, size_increase: int = 0):
        self.type                 = type
        self.duration             = duration
        self.start_duration       = duration
        self.modifier             = modifier
        self.size_increase        = size_increase
        self.source_index         = 0
        self.effect_type          = 0
        self.normal_dmg           = 0
        self.belle_weapon_bounces = 0

    def tick(self, owner) -> bool:
        self.duration -= 1
        if self.duration < 1:
            self.on_buff_end(owner)
            return True
        return False

    def can_stack(self) -> bool:
        return self.type == STACKABLE_TYPE

    def on_buff_end(self, owner):
        if self.type != BELLE_WEAPON:
            return
        manager = owner.get_manager()
        if manager is None:
            return

        target   = None
        distance = HOMING_RANGE
        for character in manager.get_characters():
            if not character.is_alive_state:
                continue
            if character is owner or character.get_index() // 16 == owner.get_index() // 16:
                continue
            if character.is_immune_and_bullets_go_through(owner.is_in_realm):
                continue
            if character.data.get('Type', '') == 'Train':
                continue
            distance_to_target = character.position_distance_to(owner)
            if distance_to_target < distance:
                distance = distance_to_target
                target   = character

        source = manager.get_by_index(self.source_index)
        if target is None:
            if source is not None:
                boost = source.get_gear_boost(SHIELD_GEAR_LOGIC_TYPE)
                if boost >= 1:
                    owner.cause_damage(boost // 2, source, False)
            return

        owner.shoot_homing_projectile('ElectroSniperSecondaryProjectile_001', target,
                                      self.modifier, self.normal_dmg,
                                      self.source_index, self.belle_weapon_bounces + 1)
