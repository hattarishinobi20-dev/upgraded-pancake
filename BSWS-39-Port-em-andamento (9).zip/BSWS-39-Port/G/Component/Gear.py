from G.LogicMath import clamp

BUSH_SPEED_LOGIC_TYPE = 0
LOW_HP_LOGIC_TYPE     = 2
SHIELD_LOGIC_TYPE     = 4

SHIELD_START_AMOUNT  = 600
BUSH_SPEED_DIVIDER   = 5
LOW_HP_PERCENT       = 50
FULL_HP_PERCENT      = 100
SHIELD_REGEN_TICKS   = 10
SHIELD_REGEN_DIVIDER = 20
MAX_SHIELD_AMOUNT    = 1023


class Gear:
    __slots__ = ('data', 'is_active', 'shield_amount')

    def __init__(self, data):
        self.data          = data or {}
        self.is_active     = False
        self.shield_amount = SHIELD_START_AMOUNT if self.logic_type() == SHIELD_LOGIC_TYPE else 0

    def logic_type(self) -> int:
        return int(self.data.get('LogicType') or 0)

    def modifier_value(self) -> int:
        return int(self.data.get('ModifierValue') or 0)

    def tick(self, character):
        self.is_active = False

        if self.logic_type() == BUSH_SPEED_LOGIC_TYPE:
            if character.is_in_bush():
                character.give_speed_faster_buff(character.speed // BUSH_SPEED_DIVIDER, 2, False)
                self.is_active = True
            return

        if self.logic_type() == LOW_HP_LOGIC_TYPE:
            if character.get_hitpoint_percentage() < LOW_HP_PERCENT:
                character.give_damage_buff(self.modifier_value(), 2)
                self.is_active = True
            return

        if self.logic_type() == SHIELD_LOGIC_TYPE:
            if character.get_hitpoint_percentage() == FULL_HP_PERCENT:
                ticks_since_full_health = character.get_ticks_gone() - character.last_self_heal_tick
                if ticks_since_full_health > 0 and ticks_since_full_health % SHIELD_REGEN_TICKS == 0:
                    self.shield_amount = min(self.modifier_value(),
                                             self.shield_amount + self.modifier_value() // SHIELD_REGEN_DIVIDER)

    def on_boost(self):
        self.is_active = True

    def encode(self, bs):
        bs.write_boolean(self.is_active)
        if self.logic_type() == SHIELD_LOGIC_TYPE:
            bs.write_positive_int(clamp(self.shield_amount, 0, MAX_SHIELD_AMOUNT), 10)
