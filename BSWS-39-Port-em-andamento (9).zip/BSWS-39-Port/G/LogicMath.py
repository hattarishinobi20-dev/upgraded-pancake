import math
import struct

SIN_TABLE  = [int(round(math.sin(math.radians(value)) * 1024)) for value in range(91)]
ATAN_TABLE = [int(round(math.degrees(math.atan(value / 128.0)))) for value in range(129)]


def clamp(value: int, minimum: int, maximum: int) -> int:
    if value < minimum:
        return minimum
    if value > maximum:
        return maximum
    return value


def abs_int(value: int) -> int:
    return -value if value < 0 else value


def distance(x1: int, y1: int, x2: int, y2: int) -> int:
    return path_length(x1, y1, x2, y2)


def path_length(x1: int, y1: int, x2: int, y2: int) -> int:
    dx = x1 - x2
    dy = y1 - y2
    return int(math.sqrt(dx * dx + dy * dy))


def normalize_angle360(angle: int) -> int:
    angle %= 360
    if angle < 0:
        angle += 360
    return angle


def normalize_angle180(angle: int) -> int:
    angle = normalize_angle360(angle)
    if angle >= 180:
        return angle - 180
    return angle


def sin_table_value(angle: int) -> int:
    angle = normalize_angle360(angle)
    if angle < 180:
        if angle > 90:
            angle = 180 - angle
        return SIN_TABLE[angle]
    angle -= 180
    if angle > 90:
        angle = 180 - angle
    return -SIN_TABLE[angle]


def cos_table_value(angle: int) -> int:
    return sin_table_value(angle + 90)


def get_angle(dx: int, dy: int) -> int:
    if dx == 0 and dy == 0:
        return 0
    if dx > 0 and dy >= 0:
        if dy >= dx:
            return 90 - ATAN_TABLE[(dx << 7) // dy]
        return ATAN_TABLE[(dy << 7) // dx]
    absolute_x = abs_int(dx)
    if dx <= 0 and dy > 0:
        if absolute_x < dy:
            return 90 + ATAN_TABLE[(absolute_x << 7) // dy]
        return 180 - ATAN_TABLE[(dy << 7) // absolute_x]
    absolute_y = abs_int(dy)
    if dx < 0 and dy <= 0:
        if absolute_y >= absolute_x:
            if absolute_y == 0:
                return 0
            return 270 - ATAN_TABLE[(absolute_x << 7) // absolute_y]
        return 180 + ATAN_TABLE[(absolute_y << 7) // absolute_x]
    if absolute_x < absolute_y:
        return 270 + ATAN_TABLE[(absolute_x << 7) // absolute_y]
    return normalize_angle360(360 - ATAN_TABLE[(absolute_y << 7) // absolute_x])


def get_angle_to(x1: int, y1: int, x2: int, y2: int) -> int:
    return get_angle(x2 - x1, y2 - y1)


def get_rotated_x(x: int, y: int, angle: int) -> int:
    return trunc_div(cos_table_value(angle) * x - sin_table_value(angle) * y, 1024)


def get_rotated_y(x: int, y: int, angle: int) -> int:
    return trunc_div(sin_table_value(angle) * x + cos_table_value(angle) * y, 1024)


def trunc_div(a: int, b: int) -> int:
    quotient = a // b
    if quotient * b != a and (a < 0) != (b < 0):
        quotient += 1
    return quotient


def to_float32(value) -> float:
    return struct.unpack('f', struct.pack('f', float(value)))[0]


def line_segment_intersection(x1, y1, x2, y2, x3, y3, x4, y4):
    delta_x = x2 - x1
    delta_y = y2 - y1
    denominator = to_float32((y4 - y3) * delta_x - (x4 - x3) * delta_y)
    if denominator == 0.0:
        return None
    ratio = to_float32(((x4 - x3) * (y1 - y3) - (y4 - y3) * (x1 - x3)) / denominator)
    if ratio > 1.0 or ratio < 0.0:
        return None
    second = to_float32(((y1 - y3) * delta_x - (x1 - x3) * delta_y) / denominator)
    if second < 0.0 or second > 1.0:
        return None
    return (int(to_float32(x1 + to_float32(ratio * delta_x))),
            int(to_float32(y1 + to_float32(ratio * delta_y))))


def closest_level_border_collision(x1, y1, x2, y2, logic_width, logic_height, padding=1):
    margin = 0 if padding > 0 else 95
    low     = -2 - margin
    high    = margin + 1
    width   = low + logic_width
    height  = low + logic_height
    borders = (
        (high, high, width, high),
        (high, high, high, height),
        (width, height, high, height),
        (width, height, width, high),
    )
    for border in borders:
        hit = line_segment_intersection(x1, y1, x2, y2, border[0], border[1], border[2], border[3])
        if hit is not None:
            return hit
    return None
