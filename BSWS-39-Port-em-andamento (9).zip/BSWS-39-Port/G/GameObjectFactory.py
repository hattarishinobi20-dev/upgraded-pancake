from G.Assets import character_data_by_name, item_data, projectile_data, area_effect_data
from G.Character import Character
from G.Projectile import Projectile
from G.Item import Item
from G.AreaEffect import AreaEffect

CHARACTER_CLASS  = 16
ITEM_CLASS       = 18
PROJECTILE_CLASS = 6
AREA_CLASS       = 17


def create_character(data_instance: int) -> Character:
    return Character(CHARACTER_CLASS, data_instance)


def create_character_by_name(name: str) -> Character | None:
    data = character_data_by_name(name)
    if data is None:
        return None
    return Character(CHARACTER_CLASS, data['_instance'])


def create_projectile(name: str) -> Projectile:
    data = projectile_data(name)
    return Projectile(PROJECTILE_CLASS, data.get('_instance', 0), name if data else '')


def create_item(name: str) -> Item:
    data = item_data(name)
    return Item(data.get('_instance', 0), name if data else '')


def create_area_effect(name: str) -> AreaEffect:
    data = area_effect_data(name)
    return AreaEffect(AREA_CLASS, data.get('_instance', 0), name if data else '')
