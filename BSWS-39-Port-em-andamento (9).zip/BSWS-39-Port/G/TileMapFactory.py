# -*- coding: utf-8 -*-
"""Factory para criar TileMaps a partir de dados de mapa"""
from G.TileMap import TileMap
from G.Assets import get_map_rows, get_map_rows_by_name

_FALLBACK = ['.' * 21] * 21


def _create(rows):
    """Cria um TileMap a partir de uma lista de strings"""
    if not rows:
        rows = _FALLBACK
    width = max(len(row) for row in rows)
    height = len(rows)
    padded = [row.ljust(width, '.') for row in rows]
    return TileMap(width, height, ''.join(padded))


def create(location_global_id):
    """Cria um TileMap a partir do ID global da localização"""
    rows = get_map_rows(location_global_id) or _FALLBACK
    return _create(rows)


def create_by_name(map_name):
    """Cria um TileMap a partir do nome do mapa"""
    rows = get_map_rows_by_name(map_name) or _FALLBACK
    return _create(rows)


# Garantir que as funções estão exportáveis
__all__ = ['create', 'create_by_name', '_create']
