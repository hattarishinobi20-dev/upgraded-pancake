from G.GameObject import GameObject, OBJECT_TYPE_AREA
from G.Assets import area_effect_data, projectile_data, item_data
from G.LogicMath import get_rotated_x, get_rotated_y
from L.BitStream import BitStream

PLAYBACK_ACTIVE  = 8
PLAYBACK_PAYBACK = 4


class AreaEffect(GameObject):
    __slots__ = (
        'data', 'name', 'playback_type', 'radius',
        'is_active', 'life_time_consumed_percent', 'payback',
        'aoe_dot', 'normal_dmg',
        'display_scale', 'source', 'skill_type', 'damage', 'normal_dmg', 'duration_ticks',
        'tick_counter', 'should_be_destructed', 'ignore_character_ids', 'triggered',
        'is_petrol', 'is_on_fire', 'petrol_expiry_tick',
    )

    def __init__(self, data_class: int = 17, data_instance: int = 0, name: str = ''):
        super().__init__(data_class, data_instance)

        self.data = area_effect_data(name) if name else {}
        self.name = name

        self.playback_type = int(self.data.get('PlaybackType') or 0)
        self.radius        = int(self.data.get('Radius') or 0)

        self.is_active                 = False
        self.aoe_dot                   = 0
        self.normal_dmg                = 0
        self.life_time_consumed_percent = 0
        self.payback                   = 0
        self.display_scale             = 0
        self.source                    = None
        self.skill_type                = 0
        self.damage                    = int(self.data.get('Damage') or 0)
        self.normal_dmg                = self.damage
        self.duration_ticks            = 0
        self.tick_counter              = 0
        self.should_be_destructed      = False
        self.ignore_character_ids     = set()
        self.triggered                 = False
        
        # Petrol (óleo) system
        self.is_petrol                 = False
        self.is_on_fire                = False
        self.petrol_expiry_tick        = 0

    def get_object_type(self) -> int:
        return OBJECT_TYPE_AREA

    def get_radius(self) -> int:
        return self.radius

    def should_destruct(self) -> bool:
        return self.should_be_destructed

    def set_source(self, source, skill_type: int = 0):
        self.source = source
        self.skill_type = skill_type
        self.is_in_realm = bool(getattr(source, 'is_in_realm', False))

    def set_damage(self, damage: int):
        self.damage = damage
        self.normal_dmg = damage

    def trigger(self, duration_ticks: int = 0):
        self.is_active = True
        if duration_ticks <= 0:
            duration_ticks = int(self.data.get('TimeMs') or 0) // 50
        self.duration_ticks = duration_ticks
        if not self.triggered:
            self.triggered = True
            self._apply_instant_effect()

    def _spawn_bullet_explosion(self):
        battle = self.get_battle()
        if battle is None:
            return
        count = int(self.data.get('CustomValue') or 0)
        if count < 1:
            return
        distance = int(self.data.get('BulletExplosionBulletDistance') or 0) * 100
        if self.source is not None and self.skill_type != 2:
            distance += max(0, self.source.get_gear_boost(18))
        start_angle = int(self.data.get('BulletAngleOffset') or 15)
        bullet_name = self.data.get('BulletExplosionBullet') or ''
        item_name = self.data.get('BulletExplosionItem') or ''
        bullet_data = projectile_data(bullet_name) if bullet_name else None
        item_row = item_data(item_name) if item_name else None
        if bullet_data and self.source is not None:
            from G.Projectile import Projectile
            for index in range(count):
                angle = (start_angle + 360 * index // count) % 360
                target_x = self.x + get_rotated_x(distance, 0, angle)
                target_y = self.y + get_rotated_y(distance, 0, angle)
                child = Projectile.shoot_projectile(
                    self.source, self, bullet_data, target_x, target_y,
                    self.damage, 0, battle, index, self.skill_type,
                    self.x, self.y, None, None, 0, self.normal_dmg)
                if child is not None:
                    child.run_early_ticks()
        elif item_row:
            from G.Item import Item
            for index in range(count):
                angle = (start_angle + 360 * index // count) % 360
                item = Item(item_row.get('_instance', 0), item_name)
                item.set_position(
                    self.x + get_rotated_x(distance, 0, angle),
                    self.y + get_rotated_y(distance, 0, angle), self.z)
                item.set_index(self.get_index())
                item.spawning_tick = battle.ticks
                battle.manager.add(item)

    def _apply_instant_effect(self):
        # Apply one-shot area behaviors when the server triggers the object.
        effect_type = (self.data.get('Type') or '').strip()
        
        # PetrolDistribution - espalha óleo na área
        if effect_type == 'PetrolDistribution':
            self._apply_petrol_distribution()
            return
        
        # SetOnFire - incendeia óleo ou causa queimadura
        if effect_type == 'SetOnFire':
            self._apply_set_on_fire()
            return
        
        if effect_type == 'BulletExplosion':
            self._spawn_bullet_explosion()
            return
        if effect_type not in ('Damage', 'Heal', 'HealAndDamage', 'Pushback', 'Stun'):
            return
        battle = self.get_battle()
        if battle is None:
            return
        radius = max(0, self.radius)
        for target in battle.manager.get_characters():
            if not target.is_alive_state or target.get_global_id() in self.ignore_character_ids:
                continue
            if target.is_immune_and_bullets_go_through(self.is_in_realm):
                continue
            same_team = target.get_index() // 16 == self.get_index() // 16
            if effect_type == 'Heal' and not same_team:
                continue
            if effect_type in ('Damage', 'Stun', 'Pushback') and same_team:
                continue
            reach = max(0, radius + target.get_radius() - 50)
            dx, dy = target.x - self.x, target.y - self.y
            if dx * dx + dy * dy > reach * reach:
                continue
            if effect_type == 'Heal':
                target.heal(self.get_index(), abs(self.damage), True)
            elif effect_type == 'HealAndDamage' and same_team:
                target.heal(self.get_index(), abs(self.damage), True)
            elif effect_type == 'Stun':
                target.trigger_stun(int(self.data.get('CustomValue') or 0))
            elif effect_type == 'Pushback':
                target.trigger_pushback(self.x, self.y, int(self.data.get('PushbackStrength') or 0))
            elif self.damage > 0:
                if target.cause_damage(self.damage, self.source, self.skill_type == 2):
                    if self.source is not None and hasattr(self.source, 'gain_ulti_charge'):
                        self.source.gain_ulti_charge(self.normal_dmg)

    def _tick_dot(self):
        battle = self.get_battle()
        if battle is None:
            return
        for target in battle.manager.get_characters():
            if not target.is_alive_state or target.get_global_id() in self.ignore_character_ids:
                continue
            if target.get_index() // 16 == self.get_index() // 16:
                continue
            if target.is_immune_and_bullets_go_through(self.is_in_realm):
                continue
            reach = max(0, self.radius + int(target.data.get('CollisionRadius') or 120) - 50)
            dx, dy = target.x - self.x, target.y - self.y
            if dx * dx + dy * dy > reach * reach:
                continue
            if target.cause_damage(self.damage, self.source, self.skill_type == 2):
                if self.source is not None and hasattr(self.source, 'gain_ulti_charge'):
                    self.source.gain_ulti_charge(self.normal_dmg)

    def _apply_petrol_distribution(self):
        """Aplica distribuição de óleo (PetrolDistribution) na área.
        O óleo fica no chão e pode ser incendiado posteriormente.
        """
        battle = self.get_battle()
        if battle is None:
            return
        
        # Marcar esta área como poça de óleo
        self.is_petrol = True
        
        # Calcular duração em ticks (TimeMs / 50)
        time_ms = int(self.data.get('TimeMs') or 500)
        self.duration_ticks = max(1, time_ms // 50)
        self.petrol_expiry_tick = battle.ticks + self.duration_ticks
        
        # Registrar no battle manager para rastreamento
        if hasattr(battle, 'petrol_pools'):
            battle.petrol_pools.append({
                'effect': self,
                'x': self.x,
                'y': self.y,
                'radius': self.radius,
                'expiry_tick': self.petrol_expiry_tick
            })

    def _apply_set_on_fire(self):
        """Incendeia a área (SetOnFire).
        Se houver óleo na área, causa dano aumentado.
        Se não houver óleo, causa dano normal de queimadura.
        """
        battle = self.get_battle()
        if battle is None:
            return
        
        # Verificar se há óleo nesta área
        has_petrol = False
        if hasattr(battle, 'petrol_pools'):
            # Limpar poças expiradas
            current_tick = battle.ticks
            battle.petrol_pools = [p for p in battle.petrol_pools 
                                   if p['expiry_tick'] > current_tick]
            
            # Verificar sobreposição com poças de óleo
            for pool in battle.petrol_pools[:]:
                dx = pool['x'] - self.x
                dy = pool['y'] - self.y
                dist_sq = dx * dx + dy * dy
                combined_radius = self.radius + pool['radius']
                
                # Se há sobreposição, marcar que tem óleo
                if dist_sq <= combined_radius * combined_radius:
                    has_petrol = True
        
        # Marcar como fogo
        self.is_on_fire = True
        
        # Calcular dano (aumentado se houver óleo)
        damage = self.damage
        if has_petrol:
            # Dano aumentado quando incendeia óleo (2x)
            damage = int(damage * 2.0)
        
        # Aplicar dano aos inimigos na área (DoT)
        for target in battle.manager.get_characters():
            if not target.is_alive_state:
                continue
            if target.get_index() // 16 == self.get_index() // 16:
                continue  # Ignorar aliados
            if target.is_immune_and_bullets_go_through(self.is_in_realm):
                continue
            
            reach = max(0, self.radius + int(target.data.get('CollisionRadius') or 120) - 50)
            dx, dy = target.x - self.x, target.y - self.y
            if dx * dx + dy * dy > reach * reach:
                continue
            
            # Causar dano de queimadura
            if target.cause_damage(damage, self.source, self.skill_type == 2):
                if self.source is not None and hasattr(self.source, 'gain_ulti_charge'):
                    self.source.gain_ulti_charge(self.normal_dmg)

    def tick(self):
        if self.duration_ticks > 0:
            self.tick_counter += 1
            self.life_time_consumed_percent = min(100, self.tick_counter * 100 // self.duration_ticks)
            if (self.data.get('Type') or '').strip() == 'Dot' and self.tick_counter % 20 == 0:
                self._tick_dot()
            if self.tick_counter >= self.duration_ticks:
                self.should_be_destructed = True

    def encode(self, bs: BitStream, is_own: bool, vision_team: int = 0):
        super().encode(bs, is_own, vision_team)

        if self.playback_type == PLAYBACK_ACTIVE:
            bs.write_boolean(self.is_active)

        bs.wpi7(self.life_time_consumed_percent)

        if self.playback_type == PLAYBACK_PAYBACK:
            bs.wpi7(self.payback)

        has_source = self.source is not None
        bs.write_boolean(has_source)
        if has_source:
            bs.wpi27(self.source.get_global_id())

        bs.woften0_65535(self.display_scale)
