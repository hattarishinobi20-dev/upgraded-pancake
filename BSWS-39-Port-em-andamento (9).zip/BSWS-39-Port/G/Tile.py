from G.Assets import tile_data, tile_dynamic_data

CODE_TO_SPAWN = {
    '1': 'team1',
    '2': 'team2',
    '8': 'base',
    '6': 'ball_t1',
    '7': 'ball_t2',
    '4': 'lootbox',
    '5': 'coop_base',
    '0': 'dummy_medium',
    '3': 'dummy_big',
    'Q': 'train_spawner',
    'g': 'invasion_spawn',
    'y': 'heal',
    'K': 'trampoline_up',
    'U': 'trampoline_up_right',
    'H': 'trampoline_right',
    'P': 'trampoline_down_right',
    'L': 'trampoline_down',
    'O': 'trampoline_down_left',
    'G': 'trampoline_left',
    'Z': 'trampoline_up_left',
    'x': 'damage',
    'z': 'slow',
    'w': 'fast',
}


class Tile:
    __slots__ = (
        'code', 'x', 'y', 'data', 'dynamic',
        'blocks_movement', 'blocks_projectiles',
        'is_destructible', 'is_destructible_normal_weapon',
        'respawn_seconds', 'life_time', 'placer_index',
        'hides_hero', '_destructed',
    )

    def __init__(self, code, x: int, y: int, dynamic: bool = False):
        self.code     = code[0] if isinstance(code, str) and code else '.'
        self.x        = x
        self.y        = y
        self.dynamic  = dynamic
        self.data     = tile_dynamic_data(code) if dynamic else tile_data(self.code)

        self.blocks_movement           = self.data.get('BlocksMovement', '') == 'true'
        self.blocks_projectiles        = self.data.get('BlocksProjectiles', '') == 'true'
        self.is_destructible           = self.data.get('IsDestructible', '') == 'true'
        self.is_destructible_normal_weapon = self.data.get('IsDestructibleNormalWeapon', '') == 'true'
        self.respawn_seconds           = int(self.data.get('RespawnSeconds') or 0)
        self.hides_hero                = self.data.get('HidesHero', '').lower() == 'true'
        self.life_time                 = int(self.data.get('Lifetime') or 0)
        self.placer_index              = 0
        self._destructed               = False

    @property
    def name(self) -> str:
        return self.data.get('Name', '')

    @property
    def dynamic_code(self) -> int:
        return int(self.data.get('DynamicCode') or 0)

    def tile_x(self) -> int:
        return self.x // 300

    def tile_y(self) -> int:
        return self.y // 300

    def is_destructed(self) -> bool:
        return self._destructed

    def destruct(self, pierces_environment: bool = True):
        if self.is_destructible and (pierces_environment or self.is_destructible_normal_weapon):
            self._destructed = True

    def construct(self):
        self._destructed = False
