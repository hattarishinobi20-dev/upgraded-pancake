from L.BitStream import BitStream

INPUT_ATTACK  = 0
INPUT_ULTI    = 1
INPUT_MOVE    = 2
INPUT_RESPAWN = 4
INPUT_CHARGE  = 5
INPUT_RELEASE = 6
INPUT_GADGET  = 8
INPUT_EMOTE   = 9
INPUT_AUTO    = 10
INPUT_STOPATK = 13


class ClientInput:
    __slots__ = (
        'index', 'type', 'x', 'y',
        'auto_attack', 'auto_attack_target',
        'emote_index', 'owner_session_id',
    )

    def __init__(self):
        self.index              = 0
        self.type               = 0
        self.x                  = 0
        self.y                  = 0
        self.auto_attack        = False
        self.auto_attack_target = 0
        self.emote_index        = 0
        self.owner_session_id   = 0

    def decode(self, bs: BitStream):
        self.index       = bs.read_positive_int(15)
        self.type        = bs.read_positive_int(4)
        self.x           = bs.read_int(15)
        self.y           = bs.read_int(15)
        self.auto_attack = bs.read_boolean()
        bs.read_boolean()

        if self.type == INPUT_EMOTE:
            self.emote_index = bs.read_positive_int(3)

        if self.type == 11:
            bs.read_positive_vint_max255()

        if self.type == 15:
            self.emote_index = bs.read_positive_int(9) - 6
            bs.read_positive_int(9)

        if self.auto_attack:
            if bs.read_boolean():
                instance_id             = bs.read_positive_int(14)
                self.auto_attack_target = 1000000 + instance_id
