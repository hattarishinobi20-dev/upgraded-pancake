import math

from G.GameObject import GameObject, OBJECT_TYPE_PROJECTILE
from G.Assets import projectile_data, area_effect_data
from G.LogicMath import (
    clamp, path_length, trunc_div, get_angle, get_angle_to, get_rotated_x, get_rotated_y,
)
from L.BitStream import BitStream

STATE_FLYING     = 0
STATE_DEPLOYED   = 4
RAW_TRAVEL_TYPES = (8, 11)
BIG_MAP_WIDTH    = 22
PROJECTILE_CLASS = 6
TICKS_PER_SECOND = 20
DESTROY_TICKS    = 6
SUB_STEPS        = 3
DEFAULT_Z        = 300
SPEED_FIX        = 14


class Projectile(GameObject):
    __slots__ = (
        'data', 'name', 'skin_data',
        'travel_type', 'radius', 'indirect', 'is_bouncing',
        'trigger_with_delay_ms', 'pre_explosion_time_ms', 'rotated_for_tp6',
        'state', 'bounce_tile_index', 'bounce_count', 'on_deploy', 'trigger_delay',
        'ending_tick', 'target_x', 'target_y', 'display_scale',
        'total_delta', 'angle', 'special_effect', 'now_x', 'now_y',
        'owner_index',
        'owner', 'target', 'start_x', 'start_y', 'prev_x', 'prev_y',
        'original_end_x', 'original_end_y', 'deployed_tick', 'destroyed_ticks', 'early_ticks',
        'default_z', 'spawned_item_data', 'percent_damage',
        'percent_damage_buff', 'percent_damage_debuff', 'min_percent_damage',
        'static_percent_damage', 'damage_add_from_bounce', 'healing',
        'heal_others_area_effect', 'cripple_percent', 'freeze_strength',
        'freeze_duration', 'prey_on_weak_damage', 'prey_on_weak_percent',
        'ulti_burn_damage', 'ulti_burn_ticks',
        'total_delta', 'length_delta', 'damage', 'normal_dmg', 'speed',
        'skill_type', 'hit_radius', 'is_destroyed', 'area_effect_name',
        'pierces_characters', 'pierces_environment', 'pushback_strength',
        'hit_objects', 'hit_cooldowns', 'target_hit_counts', 'homing_target', 'belle_weapon_bounces',
        'chain_triggered', 'hit_any', 'is_chained', 'return_spawned',
    )

    def __init__(self, data_class: int = 6, data_instance: int = 0, name: str = ''):
        super().__init__(data_class, data_instance)
        self.area_effect_name = ''

        self.data   = projectile_data(name) if name else {}
        self.name   = name
        self.skin_data = self.data

        self.travel_type            = int(self.data.get('TravelType') or 0)
        self.radius                 = int(self.data.get('Radius') or 0)
        self.indirect               = self.data.get('Indirect', '').lower() == 'true'
        self.is_bouncing            = self.data.get('IsBouncing', '').lower() == 'true'
        self.trigger_with_delay_ms  = int(self.data.get('TriggerWithDelayMs') or 0)
        self.pre_explosion_time_ms  = int(self.data.get('PreExplosionTimeMs') or 0)
        self.rotated_for_tp6        = False
        self.pierces_characters     = self.data.get('PiercesCharacters', '').lower() == 'true'
        self.pierces_environment    = self.data.get('PiercesEnvironment', '').lower() == 'true'
        self.pushback_strength      = int(self.data.get('PushbackStrength') or 0)
        self.hit_objects            = set()
        self.hit_cooldowns          = {}
        self.target_hit_counts      = {}
        self.homing_target          = None
        self.belle_weapon_bounces   = 0
        self.chain_triggered        = False
        self.hit_any                = False
        self.is_chained             = False
        self.return_spawned         = False

        self.state             = 0
        self.bounce_tile_index = -1
        self.bounce_count      = 0
        self.on_deploy         = False
        self.trigger_delay     = 0
        self.ending_tick       = 0
        self.target_x          = 0
        self.target_y          = 0
        self.display_scale     = 0
        self.total_delta       = 0
        self.angle             = 0
        self.special_effect    = False
        self.now_x             = 0
        self.now_y             = 0
        self.owner_index       = 0
        self.owner             = None
        self.target            = None
        self.start_x           = 0
        self.start_y           = 0
        self.prev_x            = 0
        self.prev_y            = 0
        self.original_end_x    = 0
        self.original_end_y    = 0
        self.default_z         = 0
        self.spawned_item_data = None
        self.percent_damage    = 0
        self.percent_damage_buff = 0
        self.percent_damage_debuff = 0
        self.min_percent_damage = 0
        self.static_percent_damage = 0
        self.damage_add_from_bounce = 0
        self.healing = 0
        self.heal_others_area_effect = 0
        self.cripple_percent = 0
        self.freeze_strength = 0
        self.freeze_duration = 0
        self.prey_on_weak_damage = 0
        self.prey_on_weak_percent = 0
        self.ulti_burn_damage = 0
        self.ulti_burn_ticks = 0
        self.deployed_tick     = 0
        self.early_ticks       = 0
        self.destroyed_ticks   = 0
        self.total_delta       = 0
        self.length_delta      = 0
        self.damage            = 0
        self.normal_dmg        = 0
        self.speed             = 0
        self.skill_type        = 0
        self.hit_radius        = 0
        self.is_destroyed      = False

    def get_object_type(self) -> int:
        return OBJECT_TYPE_PROJECTILE

    def should_destruct(self) -> bool:
        return self.is_destroyed

    def on_destruct(self):
        self.is_destroyed = True

    def travel_ticks(self, distance: int, speed: int) -> int:
        speed = max(1, speed)
        if self.data.get('ConstantFlyTime', '').lower() == 'true':
            return max(1, int(18000 / speed + 0.5))
        return max(1, int(20 * distance / speed + 0.5))

    @staticmethod
    def get_projectile_speed(owner, data, is_ultimate: bool) -> int:
        speed = int(data.get('Speed') or 0)
        if owner is None:
            return speed
        bonus = owner.get_card_value_for_passive('projectile_speed', 1)
        if bonus > 0:
            speed += bonus
        value = owner.get_card_value_for_passive('super_range' if is_ultimate else 'attack_range', 1)
        if value >= 0:
            rapid_range = owner.rapid_fire_range
            if rapid_range != value:
                return speed * rapid_range // (rapid_range - value)
            return speed
        if owner.attack_accelerating_factor > 0:
            speed += owner.attack_accelerating_factor
        return speed

    def shot_speed(self) -> int:
        speed = int(self.data.get('Speed') or 0)
        if speed <= 0:
            speed = 3000
        return speed

    def get_spread_max(self, spread: int, distance: int) -> int:
        return Projectile.spread_max(self.data, spread, distance)

    def shoot(self, offset_x, offset_y, owner, target, x: int, y: int,
              damage: int, normal_dmg: int, spread: int, bullet_index: int, skill_type: int,
              start_offset_x=None, start_offset_y=None, speed_adjustment: int = 0):
        battle = self.get_battle() or owner.get_battle()
        if battle is None:
            return None

        self.set_index(owner.get_index())
        self.owner_index = owner.get_index()
        self.owner       = owner
        self.target      = target
        self.skill_type  = skill_type

        dx = x - owner.x
        dy = y - owner.y
        distance = path_length(owner.x, owner.y, x, y)

        target_x = x
        target_y = y

        spread_max = self.get_spread_max(spread, distance)
        if spread_max >= 3:
            perpendicular_x = get_rotated_x(dx, dy, 90)
            perpendicular_y = get_rotated_y(dx, dy, 90)
            length = path_length(0, 0, perpendicular_x, perpendicular_y)
            if length > 0:
                perpendicular_x = perpendicular_x * spread_max // length
                perpendicular_y = perpendicular_y * spread_max // length
            if spread < 0:
                perpendicular_x = -perpendicular_x
                perpendicular_y = -perpendicular_y

            target_x = x + perpendicular_x
            target_y = y + perpendicular_y

            new_distance = path_length(owner.x, owner.y, target_x, target_y)
            if new_distance > 0 and distance > 0:
                target_x = (target_x - owner.x) * distance // new_distance + owner.x
                target_y = (target_y - owner.y) * distance // new_distance + owner.y

        self.init(offset_x, offset_y, owner, target, target_x, target_y,
                  damage, normal_dmg, bullet_index, battle, start_offset_x, start_offset_y,
                  speed_adjustment)
        return self

    def init(self, offset_x: int, offset_y: int, owner, target, target_x: int, target_y: int,
             damage: int, normal_dmg: int, bullet_index: int, battle,
             start_offset_x=None, start_offset_y=None, speed_adjustment: int = 0):
        width  = battle.tilemap.logic_width
        height = battle.tilemap.logic_height

        start_x = owner.x
        start_y = owner.y
        if offset_x == -1:
            dx = target_x - start_x
            dy = target_y - start_y
            length = path_length(0, 0, dx, dy)
            if length > 0:
                dx = dx * 200 // length
                dy = dy * 200 // length
            start_x += dx
            start_y += dy
        elif offset_x is not None:
            start_x = offset_x
            start_y = offset_y
        elif start_offset_x is not None:
            start_x += start_offset_x
            start_y += start_offset_y

        self.damage      = damage
        self.normal_dmg  = normal_dmg
        self.deployed_tick = battle.ticks
        self.speed       = Projectile.get_projectile_speed(owner, self.data, self.skill_type == 2)

        travel = self.travel_ticks(
            path_length(start_x, start_y, target_x, target_y), self.speed - speed_adjustment)
        self.ending_tick  = travel + battle.ticks
        self.length_delta = 1000 // max(1, self.ending_tick - self.deployed_tick)
        self.total_delta  = 0

        self.target_x          = target_x
        self.target_y          = target_y
        self.original_end_x    = target_x
        self.original_end_y    = target_y
        self.start_x           = clamp(start_x, 1, width - 2)
        self.start_y           = clamp(start_y, 1, height - 2)
        self.now_x             = self.start_x
        self.now_y             = self.start_y
        self.prev_x            = self.now_x
        self.prev_y            = self.now_y
        self.x                 = self.start_x
        self.y                 = self.start_y
        if owner is target and owner is not None:
            self.z = owner.z + int(owner.data.get('ProjectileStartZ') or 0)
        else:
            self.z = (target.z if target is not None else 0) + DEFAULT_Z
        self.default_z = self.z
        self.display_scale     = 0
        self.angle             = get_angle(self.target_x - self.start_x, self.target_y - self.start_y)

        if self.trigger_with_delay_ms > 0:
            self.trigger_delay = self.trigger_with_delay_ms // 50 + battle.ticks

    def is_wall_between(self, x: int, y: int) -> bool:
        battle = self.get_battle()
        if battle is None:
            return False
        tile = battle.tilemap.get_tile(x // 300, y // 300, True)
        return tile is None or (tile.blocks_projectiles and not tile.is_destructed())

    def _segment_hits_character(self, x1: int, y1: int, x2: int, y2: int,
                                cx: int, cy: int, radius: int) -> bool:
        """Integer-only swept-circle test to prevent projectile tunnelling."""
        dx, dy = x2 - x1, y2 - y1
        px, py = cx - x1, cy - y1
        length_sq = dx * dx + dy * dy
        radius_sq = radius * radius
        if length_sq == 0:
            return px * px + py * py <= radius_sq
        projection = px * dx + py * dy
        if projection <= 0:
            return px * px + py * py <= radius_sq
        if projection >= length_sq:
            ex, ey = cx - x2, cy - y2
            return ex * ex + ey * ey <= radius_sq
        cross = px * dy - py * dx
        return cross * cross <= radius_sq * length_sq

    def _trace_projectile_walls(self, x1: int, y1: int, x2: int, y2: int) -> bool:
        """Trace every sub-tile segment and stop at the first blocking tile."""
        battle = self.get_battle()
        if battle is None:
            return False
        distance = path_length(x1, y1, x2, y2)
        steps = max(1, (distance + 74) // 75)
        safe_x, safe_y = x1, y1
        for step in range(1, steps + 1):
            px = x1 + (x2 - x1) * step // steps
            py = y1 + (y2 - y1) * step // steps
            if not self.is_wall_between(px, py):
                safe_x, safe_y = px, py
                continue
            self.x, self.y = px, py
            if self.break_wall():
                safe_x, safe_y = px, py
                continue
            self.x, self.y = safe_x, safe_y
            if self._bounce_from_wall(safe_x, safe_y, px, py):
                return True
            self.execute_chain(x=safe_x, y=safe_y, wall_hit=True)
            self.deploy()
            return True
        self.x, self.y = x2, y2
        return False

    def break_wall(self) -> bool:
        battle = self.get_battle()
        if battle is None:
            return False
        tile = battle.tilemap.get_tile(self.x // 300, self.y // 300, True)
        if tile is None:
            return False
        tile.destruct(self.pierces_environment)
        if tile.is_destructed():
            return True
        return False

    def _bounce_from_wall(self, safe_x: int, safe_y: int, hit_x: int, hit_y: int) -> bool:
        if not self.is_bouncing:
            return False
        battle = self.get_battle()
        if battle is None:
            return False
        width = battle.tilemap.width
        hit_tile_x, hit_tile_y = hit_x // 300, hit_y // 300
        self.bounce_tile_index = hit_tile_x + width * hit_tile_y
        maximum = int(self.data.get('MaxDistanceBounces') or 6)
        if self.bounce_count >= maximum:
            self.execute_chain(x=safe_x, y=safe_y, wall_hit=True)
            self.x, self.y = safe_x, safe_y
            self.deploy()
            return True

        safe_tile_x, safe_tile_y = safe_x // 300, safe_y // 300
        crossed_x = hit_tile_x != safe_tile_x
        crossed_y = hit_tile_y != safe_tile_y
        if not crossed_x and not crossed_y:
            crossed_x = abs(self.x - self.prev_x) >= abs(self.y - self.prev_y)
            crossed_y = not crossed_x

        dx, dy = self.target_x - hit_x, self.target_y - hit_y
        if crossed_x:
            dx = -dx
            direction = 2 if self.x >= self.prev_x else 3
        else:
            direction = 4 if self.y >= self.prev_y else 1
        if crossed_y:
            dy = -dy
            direction = 4 if self.y >= self.prev_y else 1

        remaining = path_length(0, 0, dx, dy)
        added_distance = int(self.data.get('DistanceAddFromBounce') or 0)
        if added_distance > 0 and self.bounce_count < 6:
            remaining += added_distance
        vector_length = path_length(0, 0, dx, dy)
        if vector_length < 1 or remaining < 1:
            self.execute_chain(x=safe_x, y=safe_y, wall_hit=True)
            self.x, self.y = safe_x, safe_y
            self.deploy()
            return True
        dx = dx * remaining // vector_length
        dy = dy * remaining // vector_length
        self.target_x = safe_x + dx
        self.target_y = safe_y + dy
        self.start_x, self.start_y = safe_x, safe_y
        self.x, self.y = safe_x, safe_y
        self.now_x, self.now_y = safe_x, safe_y
        self.prev_x, self.prev_y = safe_x, safe_y
        self.angle = get_angle(dx, dy)
        if getattr(self, 'damage_add_from_bounce', 0) >= 1:
            self.damage += self.damage_add_from_bounce
            self.special_effect = True
            self.damage_add_from_bounce = 0
        self.bounce_count += 1
        self.bounce_tile_index = hit_tile_x + width * hit_tile_y
        self.deployed_tick = self.get_ticks_gone() + getattr(self, 'early_ticks', 0)
        travel = self.travel_ticks(remaining, self.speed or int(self.data.get('Speed') or 3000))
        self.ending_tick = self.deployed_tick + travel
        self.length_delta = max(1, 1000 // travel)
        self.total_delta = 0
        return True

    def _uses_steering(self) -> bool:
        return (
            self.homing_target is not None
            or self.travel_type in (4, 5)
            or self.data.get('IsHomingMissile', '').lower() == 'true'
            or self.data.get('IsFriendlyHomingMissile', '').lower() == 'true'
            or int(self.data.get('SteerStrength') or 0) > 0
        )

    def _acquire_homing_target(self):
        if self.homing_target is not None and getattr(self.homing_target, 'is_alive_state', True):
            return
        self.homing_target = None
        if self.travel_type != 4:
            return
        battle = self.get_battle()
        if battle is None:
            return
        home_distance = int(self.data.get('HomeDistance') or 0) * 300
        if home_distance <= 0:
            return
        best_distance_sq = home_distance * home_distance
        for candidate in battle.manager.get_characters():
            if candidate is self.owner or not getattr(candidate, 'is_alive_state', False):
                continue
            if candidate.get_index() // 16 == self.owner_index // 16:
                continue
            if getattr(candidate, 'is_invisible', False) and not getattr(candidate, 'yellow_eye', False):
                continue
            dx, dy = candidate.x - self.x, candidate.y - self.y
            distance_sq = dx * dx + dy * dy
            if distance_sq < best_distance_sq:
                best_distance_sq = distance_sq
                self.homing_target = candidate

    def _advance_steered_position(self):
        self._acquire_homing_target()
        target_x, target_y = self.target_x, self.target_y
        if self.homing_target is not None and getattr(self.homing_target, 'is_alive_state', True):
            target_x, target_y = self.homing_target.x, self.homing_target.y
        elapsed = getattr(self, 'early_ticks', 0) + self.get_ticks_gone() - self.deployed_tick
        steer_ignore = int(self.data.get('SteerIgnoreTicks') or 0)
        steer = int(self.data.get('SteerStrength') or 0)
        if elapsed > steer_ignore:
            desired_angle = get_angle(target_x - self.x, target_y - self.y)
            angle_delta = (desired_angle - self.angle + 180) % 360 - 180
            if steer <= 0:
                steer = 12
            self.angle = (self.angle + clamp(angle_delta, -steer, steer)) % 360
        speed = self.speed
        if self.travel_type == 5:
            progress = clamp(self.total_delta, 0, 1000)
            speed = speed * 400 // 1000 + speed * 600 * progress // 1000000
        speed_per_tick = max(1, speed // TICKS_PER_SECOND)
        self.x += get_rotated_x(speed_per_tick, 0, self.angle)
        self.y += get_rotated_y(speed_per_tick, 0, self.angle)
        self.total_delta = min(1000, self.total_delta + max(1, self.length_delta))

    def _rotate_travel_type_6(self):
        if getattr(self, 'rotated_for_tp6', False) or self.travel_type != 6 or self.total_delta < 500:
            return
        original_duration = max(1, self.ending_tick - self.deployed_tick)
        midpoint_x = self.start_x + trunc_div(self.original_end_x - self.start_x, 2)
        midpoint_y = self.start_y + trunc_div(self.original_end_y - self.start_y, 2)
        dx, dy = self.original_end_x - midpoint_x, self.original_end_y - midpoint_y
        distance = path_length(0, 0, dx, dy)
        if distance < 1:
            self.rotated_for_tp6 = True
            return
        self.start_x, self.start_y = midpoint_x, midpoint_y
        self.target_x = self.original_end_x + trunc_div(900 * dx, distance)
        self.target_y = self.original_end_y + trunc_div(900 * dy, distance)
        current_tick = self.early_ticks + self.get_ticks_gone()
        added_flight = self.travel_ticks(900, self.speed or int(self.data.get('Speed') or 1))
        self.deployed_tick = current_tick - 1
        self.ending_tick = current_tick + max(1, original_duration // 2) + added_flight
        self.rotated_for_tp6 = True
        self.angle = get_angle(self.target_x - self.start_x, self.target_y - self.start_y)

    def update_position(self):
        if self.length_delta <= 0:
            return
        travel = max(1, self.ending_tick - self.deployed_tick)
        elapsed = max(0, self.early_ticks + self.get_ticks_gone() - self.deployed_tick)
        local_percent = min(1000, 1000 * elapsed // travel)
        if self.travel_type == 6 and self.rotated_for_tp6:
            self.total_delta = min(1000, 500 + local_percent // 2)
            percent = local_percent
        else:
            self.total_delta = local_percent
            percent = self.total_delta
        dx, dy = self.target_x - self.start_x, self.target_y - self.start_y
        distance = path_length(0, 0, dx, dy)
        bounce_percent = int(self.data.get('BouncePercent') or 0)
        gravity = int(self.data.get('Gravity') or 0)
        base_z = getattr(self, 'default_z', self.z)
        if elapsed <= travel:
            if bounce_percent > 0 and distance > 0:
                first_fraction = 5 * bounce_percent
                second_fraction = 10 * bounce_percent
                rise_end = 1000 - 2 * first_fraction
                extension_x = extension_y = 0
                if 10 * bounce_percent * distance + 1499 >= 2999:
                    extension = second_fraction * distance // 1500
                    extension_x = trunc_div(extension * dx, distance)
                    extension_y = trunc_div(extension * dy, distance)
                extended_x = self.target_x + extension_x
                extended_y = self.target_y + extension_y
                if percent <= rise_end:
                    phase_ticks = max(1, rise_end * travel // 1000)
                    phase = trunc_div(1000 * elapsed, phase_ticks)
                    self.x = trunc_div((1000 - percent) * self.start_x + extended_x * percent, 1000)
                    self.y = trunc_div((1000 - percent) * self.start_y + extended_y * percent, 1000)
                    base_z = trunc_div(base_z * (1000 - phase), 1000)
                else:
                    late = percent - rise_end
                    remaining = second_fraction - late
                    first_x = trunc_div(second_fraction * self.start_x + extended_x * rise_end, 1000)
                    first_y = trunc_div(second_fraction * self.start_y + extended_y * rise_end, 1000)
                    apex_x = trunc_div((extended_x - self.start_x) * rise_end, 1000) + self.start_x
                    apex_x += trunc_div((extended_x - self.start_x) * second_fraction, 2000)
                    apex_y = trunc_div((extended_y - self.start_y) * rise_end, 1000) + self.start_y
                    apex_y += trunc_div((extended_y - self.start_y) * second_fraction, 2000)
                    if second_fraction > 0:
                        self.x = trunc_div(first_x * remaining + apex_x * late, second_fraction)
                        self.y = trunc_div(first_y * remaining + apex_y * late, second_fraction)
                    else:
                        self.x, self.y = self.target_x, self.target_y
                    base_z = 0
            else:
                move_elapsed = elapsed
                move_duration = travel
                if self.travel_type == 11:
                    delay = int(self.data.get('TravelTypeVariable') or 0)
                    move_elapsed = max(0, move_elapsed - delay)
                    move_duration = max(1, move_duration - delay)
                remaining = move_duration - move_elapsed
                self.x = trunc_div(remaining * self.start_x, move_duration)
                self.x += trunc_div(move_elapsed * self.target_x, move_duration)
                self.y = trunc_div(remaining * self.start_y, move_duration)
                self.y += trunc_div(move_elapsed * self.target_y, move_duration)
                if gravity > 0:
                    base_z = trunc_div(base_z * remaining, move_duration)
        else:
            self.x, self.y = self.target_x, self.target_y
            base_z = base_z if gravity < 1 else 0

        height_delta = 0
        if gravity > 0 and distance > 0:
            speed = max(1, int(self.data.get('Speed') or self.speed or 1))
            speed_scale = max(speed * 0.1, 0.1)
            if bounce_percent < 1:
                traveled = path_length(self.start_x, self.start_y, self.x, self.y)
                elapsed_flight = traveled / speed_scale
                total_flight = distance / speed_scale
                acceleration = -gravity * (0.001 if self.data.get('ConstantFlyTime', '').lower() == 'true'
                                           else 1.0 / (math.sqrt(distance) * 40.0))
                if self.data.get('ConstantFlyTime', '').lower() == 'true':
                    height_curve = elapsed_flight * (acceleration * 2000000.0 / (distance * distance)) * (elapsed_flight - total_flight)
                else:
                    height_curve = elapsed_flight * acceleration * (elapsed_flight - total_flight)
            else:
                acceleration = -gravity / (math.sqrt(distance) * 40.0)
                bounce_offset = bounce_percent * distance
                if bounce_offset + 149 >= 299:
                    scaled_offset = bounce_offset // 150
                    bounce_x = trunc_div(scaled_offset * dx, distance)
                    bounce_y = trunc_div(scaled_offset * dy, distance)
                else:
                    bounce_x = bounce_y = 0
                pivot_x, pivot_y = self.target_x - bounce_x, self.target_y - bounce_y
                dot = bounce_x * (self.x - pivot_x) + bounce_y * (self.y - pivot_y)
                if dot <= -1:
                    segment_start_x, segment_start_y = self.start_x, self.start_y
                    segment_distance = path_length(self.start_x, self.start_y, pivot_x, pivot_y)
                else:
                    segment_start_x, segment_start_y = pivot_x, pivot_y
                    segment_distance = path_length(pivot_x, pivot_y, self.target_x, self.target_y)
                elapsed_flight = path_length(segment_start_x, segment_start_y, self.x, self.y) / speed_scale
                total_flight = max(0.1, segment_distance / speed_scale)
                height_curve = elapsed_flight * acceleration * (elapsed_flight - total_flight)
            height_delta = int(height_curve * 300.0)
        self.z = clamp(base_z + height_delta, 0, 3000)

    def modified_damage(self, base_damage: int, target_global_id=None,
                        *, normal_damage: bool = False) -> int:
        start_percent = int(self.data.get('DamagePercentStart') or 100)
        end_percent = int(self.data.get('DamagePercentEnd') or 100)
        damage = base_damage
        if start_percent != end_percent:
            bias = 150 if end_percent > start_percent else -150
            progress = clamp(self.total_delta + bias, 0, 1000)
            scale = start_percent * (1000 - progress) + end_percent * progress
            damage = damage * scale // 100000
        owner = getattr(self, 'owner', None)
        repeat_delay = int(self.data.get('DamagesConstantlyTickDelay') or 0)
        if (not normal_damage and repeat_delay > 0 and target_global_id is not None
                and owner is not None):
            bonus = getattr(owner, 'get_card_value_for_passive', lambda *_args: -1)(
                'increase_dmg_consecutive_dot', 1)
            if bonus >= 0:
                prior_hits = getattr(self, 'target_hit_counts', {}).get(target_global_id, 0)
                damage = damage * (100 + prior_hits * bonus) // 100
        owner = getattr(self, 'owner', None)
        if owner is not None:
            if self.skill_type == 2:
                missile_bonus = getattr(owner, 'get_card_value_for_passive', lambda *_args: -1)(
                    'increase_missile_dmg_over_distance', 1)
                if missile_bonus >= 1:
                    damage += clamp(self.total_delta, 0, 1000) * missile_bonus // 1000
            grow_damage = getattr(owner, 'get_card_value_for_passive', lambda *_args: -1)(
                'grow_damage_shrapnel', 1)
            if grow_damage >= 1 and self.skill_type == 1:
                weapon = getattr(owner, 'weapon_skill', None)
                if weapon is not None and self.data.get('Name') != weapon.data.get('Projectile', ''):
                    bias = -150 if self.total_delta < 800 else 0
                    progress = clamp(self.total_delta + bias, 0, 1000)
                    scale = (100 + grow_damage) * (1000 - progress) + 100 * progress
                    damage = damage * scale // 100000
        return damage

    def collision_radius(self) -> int:
        radius = int(self.data.get('Radius') or 0)
        scale_start = int(self.data.get('ScaleStart') or 100)
        scale_end = int(self.data.get('ScaleEnd') or 100)
        scale = scale_start + (scale_end - scale_start) * clamp(self.total_delta, 0, 1000) // 1000
        return max(0, radius * scale // 100)

    def _should_chain(self, character_hit=False, wall_hit=False, no_hit=False) -> bool:
        special = int(self.data.get('ExecuteChainSpecialCase') or 0)
        chains_to_enemies = int(self.data.get('ChainsToEnemies') or 0)
        owner = getattr(self, 'owner', None)
        always_bounce = -1
        if owner is not None:
            always_bounce = getattr(owner, 'get_card_value_for_passive', lambda *_a: -1)(
                'always_bounce_shot', 1)
        if character_hit:
            return special in (0, 2, 3) or chains_to_enemies > 0
        if wall_hit:
            return special in (2, 3) or always_bounce >= 0
        if no_hit:
            return special in (1, 2) or always_bounce >= 0
        return False

    def execute_chain(self, x=None, y=None, *, character_hit=False,
                      wall_hit=False, no_hit=False):
        if getattr(self, 'chain_triggered', False) or getattr(self, 'is_chained', False):
            return []
        chain_name = self.data.get('ChainBullet') or ''
        if not chain_name or not self._should_chain(character_hit, wall_hit, no_hit):
            return []
        chains_to_enemies = int(self.data.get('ChainsToEnemies') or 0)
        chain_count = int(self.data.get('ChainBullets') or 0)
        if chains_to_enemies < 1 and chain_count < 1:
            return []
        battle = self.get_battle()
        if battle is None:
            return []
        chain_data = projectile_data(chain_name)
        if not chain_data:
            return []

        impact_x = self.x if x is None else x
        impact_y = self.y if y is None else y
        self.chain_triggered = True
        spawned = []
        damage = self.modified_damage(self.damage)
        normal_damage = self.modified_damage(self.normal_dmg)
        if no_hit and int(self.data.get('ExecuteChainSpecialCase') or 0) == 1:
            damage //= max(1, chain_count)
            normal_damage //= max(1, chain_count)

        if chains_to_enemies > 0:
            candidate, distance = None, 30000 * 30000
            for other in battle.manager.get_characters():
                if other is self.owner or not getattr(other, 'is_alive_state', False):
                    continue
                if other.get_index() // 16 == self.owner_index // 16:
                    continue
                if other.get_global_id() in self.hit_objects:
                    continue
                if getattr(other, 'is_train', False):
                    continue
                if other.is_immune_and_bullets_go_through(self.is_in_realm):
                    continue
                dx, dy = other.x - impact_x, other.y - impact_y
                distance_sq = dx * dx + dy * dy
                if distance_sq < distance:
                    candidate, distance = other, distance_sq
            if candidate is None:
                return []
            max_distance = int(self.data.get('ChainTravelDistance') or 0) * 100
            if max_distance <= 0:
                return []
            dx, dy = candidate.x - impact_x, candidate.y - impact_y
            distance = path_length(0, 0, dx, dy)
            if distance > max_distance:
                dx = dx * max_distance // distance
                dy = dy * max_distance // distance
            child = Projectile.shoot_projectile(
                self.owner, self.owner, chain_data, impact_x + dx, impact_y + dy,
                damage, 0, battle, 0, self.skill_type, impact_x, impact_y,
                None, None, 0, normal_damage)
            if child is not None:
                child.hit_objects = set(self.hit_objects)
                child.is_chained = True
                child.run_early_ticks()
                spawned.append(child)
            return spawned

        if getattr(self.owner, 'get_power_level', lambda: 0)() > 2:
            chain_count = 6
        chain_distance = int(self.data.get('ChainTravelDistance') or 0) * 100
        if chain_distance < 1:
            return []
        chain_spread = int(self.data.get('ChainSpread') or 0) * 5
        spread_step = 2 * chain_spread // max(1, chain_count - 1)
        base_angle = get_angle(self.target_x - self.start_x, self.target_y - self.start_y)
        travel_type = int(self.data.get('TravelType') or 0)
        if travel_type == 7:
            damage //= 2
            normal_damage //= 2
        radial_angles = (90, 270, 60, 120, 240, 300)
        for index in range(chain_count):
            if travel_type == 7:
                angle = (base_angle + radial_angles[index % len(radial_angles)]) % 360
                spread = 0
            else:
                angle = base_angle
                spread = -chain_spread + spread_step * index if chain_count > 1 else 0
            end_x = impact_x + get_rotated_x(chain_distance, 0, angle)
            end_y = impact_y + get_rotated_y(chain_distance, 0, angle)
            if spread:
                dx, dy = end_x - impact_x, end_y - impact_y
                distance = path_length(0, 0, dx, dy)
                spread_distance = distance * abs(spread) // 300
                perp_x = get_rotated_x(dx, dy, 90)
                perp_y = get_rotated_y(dx, dy, 90)
                perp_length = path_length(0, 0, perp_x, perp_y)
                if perp_length > 0:
                    perp_x = trunc_div(perp_x * spread_distance, perp_length)
                    perp_y = trunc_div(perp_y * spread_distance, perp_length)
                if spread < 0:
                    perp_x, perp_y = -perp_x, -perp_y
                spread_x, spread_y = end_x + perp_x, end_y + perp_y
                spread_length = path_length(impact_x, impact_y, spread_x, spread_y)
                if spread_length > 0 and distance > 0:
                    end_x = impact_x + (spread_x - impact_x) * distance // spread_length
                    end_y = impact_y + (spread_y - impact_y) * distance // spread_length
            child_damage = damage
            child_normal = normal_damage
            child = Projectile.shoot_projectile(
                self.owner, self.owner, chain_data, end_x, end_y,
                child_damage, 0, battle, index, self.skill_type,
                impact_x, impact_y, None, None, 0, child_normal)
            if child is not None:
                child.hit_objects = set(self.hit_objects)
                child.is_chained = True
                child.run_early_ticks()
                spawned.append(child)
        return spawned

    def check_collisions(self):
        battle = self.get_battle()
        if battle is None:
            return False
        if self.data.get('Indirect', '').lower() == 'true':
            return False
        radius = self.collision_radius()
        for other in battle.manager.get_characters():
            if other is self.owner or not other.is_alive_state:
                continue
            same_team = other.get_index() // 16 == self.owner_index // 16
            heal_percent = int(self.data.get('HealOwnPercent') or 0)
            friendly_homing = self.data.get('IsFriendlyHomingMissile', '').lower() == 'true'
            healing = getattr(self, 'healing', 0)
            heals_allies_only = (heal_percent > 0 or friendly_homing) and healing >= 0
            can_heal_allies = heal_percent > 0 or friendly_homing or healing > 0
            if (same_team and not can_heal_allies) or (not same_team and heals_allies_only):
                continue
            if same_team and getattr(self, 'healing', 0) > 0 and not getattr(other, 'is_hero', False):
                continue
            global_id = other.get_global_id()
            repeat_delay = int(self.data.get('DamagesConstantlyTickDelay') or 0)
            current_tick = self.get_ticks_gone() + getattr(self, 'early_ticks', 0)
            if global_id in self.hit_objects:
                if repeat_delay <= 0 or self.hit_cooldowns.get(global_id, 0) > current_tick:
                    continue
            hit_radius = radius + int(other.data.get('CollisionRadius') or 120)
            if self._segment_hits_character(self.prev_x, self.prev_y, self.x, self.y,
                                            other.x, other.y, hit_radius):
                self.hit(other)
                if repeat_delay > 0:
                    self.hit_cooldowns[global_id] = current_tick + repeat_delay
                if not self.pierces_characters:
                    return True
                self.hit_objects.add(global_id)
        return False

    def hit(self, character):
        target_global_id = character.get_global_id()
        self.hit_objects.add(target_global_id)
        self.hit_any = True
        counts = getattr(self, 'target_hit_counts', None)
        if counts is None:
            counts = {}
            self.target_hit_counts = counts
        damage = self.modified_damage(self.damage, target_global_id)
        normal_damage = self.modified_damage(
            self.normal_dmg, target_global_id, normal_damage=True)
        if int(self.data.get('DamagesConstantlyTickDelay') or 0) > 0:
            counts[target_global_id] = counts.get(target_global_id, 0) + 1
        if getattr(self, 'percent_damage', 0) > 0:
            damage_buff = getattr(self, 'percent_damage_buff', 0)
            damage_debuff = getattr(self, 'percent_damage_debuff', 0)
            minimum = getattr(self, 'min_percent_damage', 750)
            if getattr(character, 'is_hero', False):
                percent_base = int(character.hp * self.percent_damage / 100 + 0.5)
                boosted = percent_base * damage_buff // 100 + percent_base
                boosted -= boosted * damage_debuff // 100
            else:
                boosted = damage + damage * damage_buff // 100
            min_boosted = minimum * damage_buff // 100 + minimum
            min_boosted -= min_boosted * damage_debuff // 100
            damage = getattr(self, 'static_percent_damage', 0) + max(boosted, min_boosted)
            normal_damage = 1000
        heal_percent = int(self.data.get('HealOwnPercent') or 0)
        friendly_homing = self.data.get('IsFriendlyHomingMissile', '').lower() == 'true'
        same_team = character.get_index() // 16 == self.owner_index // 16
        if (getattr(self, 'prey_on_weak_damage', 0) > 0
                and character.get_hitpoint_percentage() <= getattr(self, 'prey_on_weak_percent', 0)):
            damage += self.prey_on_weak_damage
        damage_applied = False
        if same_team:
            heal_amount = 0
            if getattr(self, 'healing', 0) > 0:
                heal_amount = self.healing
            elif heal_percent > 0 or friendly_homing:
                heal_amount = damage * (heal_percent if heal_percent > 0 else 100) // 100
            if heal_amount > 0:
                character.heal(self.owner_index, heal_amount, True, self.data)
        elif (heal_percent > 0 or friendly_homing) and getattr(self, 'healing', 0) < 0:
            damage_applied = character.cause_damage(-self.healing, self.owner, self.skill_type == 2)
        elif not (heal_percent > 0 or friendly_homing):
            damage_applied = character.cause_damage(damage, self.owner, self.skill_type == 2)
            if damage_applied:
                if self.owner is not None:
                    self.owner.gain_ulti_charge(normal_damage)
                    weapon = getattr(self.owner, 'weapon_skill', None)
                    max_charged = getattr(self.owner, 'get_max_charged_shots', lambda: -1)()
                    is_hero_target = getattr(character, 'is_hero', False) or getattr(character, 'is_training_dummy', False)
                    secondary = weapon.data.get('SecondaryProjectile', '') if weapon is not None else ''
                    if (self.skill_type != 2 and is_hero_target and max_charged >= 1
                            and not (secondary and self.data.get('Name') == secondary)):
                        self.owner.charged_shot_count = min(
                            max_charged, getattr(self.owner, 'charged_shot_count', 0) + 1)
                    reload = getattr(self.owner, 'get_card_value_for_passive', lambda *_args: -1)(
                        'reload_on_hit', 1)
                    if reload >= 0 and weapon is not None:
                        weapon.add_charge(reload)
                suppress_healing = int(self.data.get('SuppressHealing') or 0)
                suppress_ticks = int(self.data.get('SuppressHealingTicks') or 0)
                if suppress_healing > 0 and suppress_ticks > 0:
                    character.apply_healing_suppression(suppress_healing, suppress_ticks)
                poison_type = int(self.data.get('PoisonType') or 0)
                poison_percent = int(self.data.get('PoisonDamagePercent') or 0)
                if poison_type > 0 and poison_percent > 0:
                    character.add_poison(
                        damage * poison_percent // 100,
                        normal_damage * poison_percent // 100,
                        self.skill_type == 2,
                        self.owner,
                        self.owner_index % 16,
                        poison_type,
                    )
                # Apply ulti_burn passive
                if getattr(self, 'ulti_burn_damage', 0) > 0:
                    character.add_poison(
                        self.ulti_burn_damage,
                        self.ulti_burn_damage,
                        True,
                        self.owner,
                        self.owner_index % 16,
                        1,  # burn type
                    )
                cripple = getattr(self, 'cripple_percent', 0)
                if cripple > 0:
                    character.cripple(cripple)
                stun_ticks = int(self.data.get('StunLengthMS') or 0) // 50
                if stun_ticks > 0:
                    character.trigger_stun(stun_ticks)
                freeze_duration = getattr(self, 'freeze_duration', 0)
                freeze_strength = getattr(self, 'freeze_strength', 0)
                if freeze_duration <= 0:
                    freeze_duration = int(self.data.get('FreezeDurationMS') or 0) // 50
                    freeze_strength = int(self.data.get('FreezeStrength') or 0)
                if freeze_duration > 0 and freeze_strength > 0:
                    character.give_speed_slower_buff(-freeze_strength, freeze_duration)
                life_steal_percent = int(self.data.get('LifeStealPercent') or 0)
                if life_steal_percent > 0 and self.owner is not None:
                    heal_base = damage
                    heal_boost = getattr(self.owner, 'get_card_value_for_passive', lambda *_args: -1)(
                        'self_heal_increase', 1)
                    if heal_boost >= 1:
                        heal_base += heal_base * heal_boost // 100
                    self.owner.heal(self.owner_index, heal_base * life_steal_percent // 100, True, self.data)
                if getattr(self, 'heal_others_area_effect', 0) >= 1 and self.owner is not None:
                    from G.Assets import area_effect_data
                    effect_data = area_effect_data('HealWithAutoAttack')
                    self.owner.add_area_effect(
                        0, 0, effect_data, self.skill_type, False,
                        damage_override=-self.heal_others_area_effect)
                unique_property = int(self.data.get('UniqueProperty') or 0)
                if unique_property == 2 and getattr(character, 'is_hero', False):
                    character.add_extra_health_regen(61, damage, self.owner_index)
                elif unique_property == 3 and getattr(self, 'belle_weapon_bounces', 0) < 3:
                    character.give_electrocution(
                        damage, normal_damage,
                        int(self.data.get('AppliedEffectVisualType') or 0),
                        getattr(self, 'belle_weapon_bounces', 0),
                    )
        if self.pushback_strength != 0:
            character.trigger_pushback(self.x, self.y, self.pushback_strength)
        self.execute_chain(x=self.x, y=self.y, character_hit=True)
        if not self.pierces_characters:
            self.deploy()
        return True

    def _spawn_boomerang_return(self):
        if getattr(self, 'return_spawned', False):
            return None
        if self.data.get('IsBoomerang', '').lower() != 'true':
            return None
        return_name = self.data.get('ChainBullet') or ''
        if not return_name or self.owner is None:
            return None
        battle = self.get_battle()
        return_data = projectile_data(return_name)
        if battle is None or not return_data:
            return None
        self.return_spawned = True
        returned = Projectile.shoot_projectile(
            self.owner, self.owner, return_data, self.owner.x, self.owner.y,
            self.damage, 0, battle, 0, self.skill_type,
            self.x, self.y, None, None, 0, self.normal_dmg)
        if returned is not None:
            returned.homing_target = self.owner
            returned.hit_objects = set()
            returned.run_early_ticks()
        return returned

    def deploy(self):
        if self.state >= STATE_DEPLOYED:
            return
        self._spawn_boomerang_return()
        self.area_effect_name = self.data.get('SpawnAreaEffectObject') or ''
        if self.area_effect_name:
            self.spawn_area_effect(self.area_effect_name)
        second_effect = self.data.get('SpawnAreaEffectObject2') or ''
        if second_effect:
            second_damage_percent = int(self.data.get('AreaEffect2DamagePercent') or 0)
            if second_damage_percent < 1:
                second_damage_percent = 100
            self.spawn_area_effect(second_effect, second_damage_percent)
        item_data = getattr(self, 'spawned_item_data', None)
        if item_data and item_data.get('Name'):
            battle = self.get_battle()
            if battle is not None:
                from G.GameObjectFactory import create_item
                item = create_item(item_data.get('Name'))
                item.set_position(self.x, self.y, 0)
                item.set_index(self.owner_index)
                item.damage = self.damage
                battle.manager.add(item)
        self.state           = STATE_DEPLOYED
        self.on_deploy       = True
        self.display_scale   = 1000
        self.target_x        = self.x
        self.target_y        = self.y

    def spawn_area_effect(self, name: str, damage_percent: int = 100):
        battle = self.get_battle()
        if battle is None or not name:
            return None
        from G.GameObjectFactory import create_area_effect
        effect = create_area_effect(name)
        if effect is None:
            return None
        effect.set_position(self.x, self.y, 0)
        effect.set_index(self.owner_index)
        effect.set_source(self.owner, self.skill_type)
        effect.damage = self.modified_damage(self.damage) * max(0, damage_percent) // 100
        effect.normal_dmg = self.modified_damage(self.normal_dmg) * max(0, damage_percent) // 100
        effect.ignore_character_ids.update(self.hit_objects)
        battle.manager.add(effect)
        effect.trigger()
        return effect

    def tick(self):
        if self.is_destroyed:
            return
        if self.state >= STATE_DEPLOYED:
            self.destroyed_ticks += 1
            if self.destroyed_ticks >= DESTROY_TICKS:
                self.is_destroyed = True
            return

        self.prev_x = self.now_x
        self.prev_y = self.now_y

        if self.travel_type == 1:
            factor = 1.5 - self.total_delta * 0.0015
            self.target_x = self.original_end_x + int((self.original_end_x - self.start_x) * factor)
            self.target_y = self.original_end_y + int((self.original_end_y - self.start_y) * factor)
        self._rotate_travel_type_6()
        if self._uses_steering():
            self._advance_steered_position()
        else:
            self.update_position()
            self.angle = get_angle(self.target_x - self.start_x, self.target_y - self.start_y)

        # Non-indirect shots sweep against projectile-blocking tiles; direct
        # endpoint checks miss thin walls when a projectile advances quickly.
        if not self.indirect and self._trace_projectile_walls(self.prev_x, self.prev_y, self.x, self.y):
            return
        if self.check_collisions():
            return

        self.now_x = self.x
        self.now_y = self.y

        current_tick = self.early_ticks + self.get_ticks_gone()
        if self.trigger_with_delay_ms > 0 and current_tick >= self.trigger_delay:
            if not getattr(self, 'hit_any', False):
                self.execute_chain(x=self.x, y=self.y, no_hit=True)
            self.deploy()
            return
        if self.trigger_with_delay_ms <= 0 and (
                self.total_delta >= 1000 or current_tick >= self.ending_tick):
            if not getattr(self, 'hit_any', False):
                self.execute_chain(x=self.x, y=self.y, no_hit=True)
            self.deploy()

    def run_early_ticks(self):
        data_early_ticks = int(self.data.get('EarlyTicks') or 0)
        if data_early_ticks >= 1:
            for _ in range(data_early_ticks):
                self.early_ticks += 1
                self.tick()
                self.on_deploy = True

    @staticmethod
    def spread_max(data, spread: int, distance: int) -> int:
        value = abs(spread)
        if data.get('ConstantFlyTime', '').lower() == 'true':
            return 3 * value
        if data.get('Indirect', '').lower() == 'true':
            min_distance = int(data.get('MinDistanceForSpread') or 0)
            if min_distance > distance:
                distance = min_distance
        return distance * value // 300

    @staticmethod
    def shoot_projectile(owner, target, data, x: int, y: int,
                         damage: int, spread: int, battle,
                         bullet_index: int = 0, skill_type: int = 1,
                         offset_x=None, offset_y=None,
                         start_offset_x=None, start_offset_y=None,
                         speed_adjustment: int = 0, normal_dmg=None):
        if not data:
            return None
        projectile = Projectile(PROJECTILE_CLASS, data.get('_instance', 0), data.get('Name', ''))
        projectile.data = data
        projectile.pierces_characters  = data.get('PiercesCharacters', '').lower() == 'true'
        projectile.pierces_environment = data.get('PiercesEnvironment', '').lower() == 'true'
        projectile.pushback_strength   = int(data.get('PushbackStrength') or 0)
        projectile.attach(battle.manager, 0)
        battle.manager.add(projectile)
        return projectile.shoot(offset_x, offset_y, owner, target, x, y, damage,
                                damage if normal_dmg is None else normal_dmg,
                                spread, bullet_index, skill_type, start_offset_x, start_offset_y,
                                speed_adjustment)

    def uses_raw_position(self) -> bool:
        if self.travel_type in RAW_TRAVEL_TYPES:
            return True
        return self.data.get('IgnoreLevelBoarder', '').lower() == 'true'

    def rendering(self) -> str:
        return self.skin_data.get('Rendering', '')

    def encode(self, bs: BitStream, is_own: bool, vision_team: int = 0):
        super().encode(bs, is_own, vision_team)

        battle = self.get_battle()
        tilemap = getattr(battle, 'tilemap', None) if battle else None
        big_map = tilemap is not None and tilemap.width >= BIG_MAP_WIDTH

        bs.wpi3(self.state)

        if self.state != STATE_DEPLOYED:
            if self.is_bouncing:
                if self.bounce_tile_index < 0:
                    bs.write_boolean(False)
                    self._encode_tail(bs, big_map)
                    return
                bs.write_boolean(True)
            else:
                self._encode_tail(bs, big_map)
                return

        if big_map:
            bs.wpi12(self.bounce_tile_index)
        else:
            bs.wpi10(clamp(self.bounce_tile_index, 0, 1023))

        self._encode_tail(bs, big_map)

    def _encode_tail(self, bs: BitStream, big_map: bool):
        bs.write_boolean(self.on_deploy)

        if self.trigger_with_delay_ms > 0:
            bs.wpvint65535(self.trigger_delay)
        elif self.pre_explosion_time_ms > 0:
            bs.wpvint65535(self.ending_tick)

        if self.pre_explosion_time_ms > 0:
            bs.wpvint65535(self.target_x)
            bs.wpvint65535(self.target_y)

        bs.wpi10(clamp(self.display_scale if self.display_scale != 0 else self.total_delta, 0, 1023))

        if self.rendering() != 'DoNotRotateClip':
            bs.wpi9(self.angle & 0x1FF)

        bs.write_boolean(self.special_effect)
        if self.special_effect:
            if self.travel_type in RAW_TRAVEL_TYPES:
                bs.wi16(self.now_x)
                bs.wi16(self.now_y)
            else:
                bs.wpvint65535(clamp(self.now_x, 0, 65535))
                bs.wpvint65535(clamp(self.now_y, 0, 65535))
