INTRO_TICKS    = 100
NO_TIME_TICKS  = 16000
NORMAL_TICKS   = 3180
TICKS_PER_SECOND = 20


def players_collect_power_cubes(variation: int) -> bool:
    v1 = variation - 6
    if v1 <= 8:
        return ((0x119 >> v1) & 1) != 0
    return False


def get_battle_ticks(variation: int) -> int:
    v2 = 2400
    if variation in (0, 5, 16, 22, 23):
        v2 = 4200
    elif variation in (3, 7, 8):
        v2 = 2400
    elif variation in (6, 9, 10, 12, 13, 18, 20):
        return NO_TIME_TICKS
    elif variation == 14:
        v2 = 9600
    elif variation in (17, 21):
        v2 = 3600
    else:
        v2 = TICKS_PER_SECOND * ((NORMAL_TICKS - INTRO_TICKS) // TICKS_PER_SECOND)
    return INTRO_TICKS + v2


def get_respawn_seconds(variation: int) -> int:
    if variation in (0, 2):
        return 3
    if variation == 3:
        return 1
    if variation in (13, 7):
        return 3
    if variation == 10:
        return 15
    if variation == 15:
        return 1
    if variation == 9:
        return 15
    if variation == 17:
        return 3
    return 5


def players_collect_bounty_stars(variation: int) -> bool:
    return variation == 3 or variation == 15


def get_number_of_rounds(variation: int) -> int:
    return 3 if variation == 20 else 1


def has_two_teams(variation: int) -> bool:
    if variation in (15, 28, 6, 9, 33):
        return False
    return True


def has_big_map(variation: int) -> bool:
    return variation in (6, 0x21, 0x2E, 15, 9)


def has_five_teams(variation: int) -> bool:
    return False


def has_two_bases(variation: int) -> bool:
    return variation == 2 or variation == 11


def mode_has_carryables(variation: int) -> bool:
    return variation in (5, 16, 21, 22, 23, 24)


def is_gem_grab(variation: int) -> bool:
    return variation in (0, 0x21, 0x2E)


def get_game_mode_variation(mode: str) -> int:
    return _GMV_BY_NAME.get(mode, -1)


_GMV_BY_NAME = {
    "CoinRush":          0,
    "GemGrab":           0,
    "Heist":             2,
    "AttackDefend":      2,
    "Bounty":            3,
    "BountyHunter":      3,
    "Artifact":          4,
    "LaserBall":         5,
    "BrawlBall":         5,
    "BattleRoyale":      6,
    "Showdown":          6,
    "BigGame":           7,
    "BattleRoyaleTeam":  9,
    "DuoShowdown":       9,
    "RoboRumble":        8,
    "BossFight":         10,
    "Siege":             11,
    "Tutorial":          12,
    "Training":          13,
    "CTF":               16,
    "KingOfHill":        17,
    "Knockout":          20,
    "LoneStar":          15,
    "TagTeam":           24,
    "Deathmatch":        25,
    "DeathmatchFFA":     28,
    "ReachExit":         30,
    "BossFight_TownCrush": 18,
    "Deathmatch5v5":     31,
    "BrawlBall5v5":      32,
    "GemGrab5v5":        33,
    "HoldTheBall":       21,
    "BasketBrawl":       22,
    "VolleyBrawl":       23,
    "Payload":           26,
    "Invasion":          27,
    "ProtectKing":       19,
    "MapPrint":          99,
}
