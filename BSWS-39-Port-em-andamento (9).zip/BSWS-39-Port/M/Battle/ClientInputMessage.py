from collections import deque
from L.BStream import Buf
from L.BitStream import BitStream
from G.ClientInput import ClientInput


class ClientInputMessage(Buf):
    id = 10555

    def __init__(self, connection, header_bytes):
        super().__init__(header_bytes)
        self.connection = connection
        self.inputs: deque[ClientInput] = deque()

    def decode(self):
        bs = BitStream(bytes(self.bytes_of_packets))

        bs.read_positive_int(14)
        bs.read_positive_int(10)
        bs.read_positive_int(13)
        bs.read_positive_int(10)
        bs.read_positive_int(10)

        count = bs.read_positive_int(5)
        for _ in range(count):
            inp = ClientInput()
            inp.decode(bs)
            self.inputs.append(inp)

    def process(self):
        battle = getattr(self.connection, 'battle', None)
        if battle is None:
            return
        session_id = id(self.connection)
        while self.inputs:
            inp = self.inputs.popleft()
            battle.add_input(inp, session_id)
