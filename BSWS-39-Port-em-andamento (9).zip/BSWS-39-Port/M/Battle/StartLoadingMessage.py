from L.BStream import Pkt


_GMV_MSG_MODE = {
    6: 6,
    9: 9,
}


class StartLoadingMessage(Pkt):
    id      = 20559
    version = 1

    def __init__(self, client, players: list, own_index: int,
                 team_index: int, location_global_id: int,
                 gmv: int, is_friendly: bool = False,
                 game_type: int = 0, spectate_mode: int = 0,
                 msg_game_mode: int = 0):
        super().__init__(client)
        self.players            = players
        self.own_index          = own_index
        self.team_index         = team_index
        self.location_global_id = location_global_id
        self.gmv                = gmv
        self.is_friendly        = is_friendly
        self.game_type          = game_type
        self.spectate_mode      = spectate_mode
        self.msg_game_mode      = msg_game_mode
        self.map_mode           = 1

    def encode(self):
        msg_game_mode = self.msg_game_mode or _GMV_MSG_MODE.get(self.gmv, 1)

        self.wint(len(self.players))
        self.wint(self.own_index)
        self.wint(self.team_index)

        self.wint(len(self.players))
        for player in self.players:
            player.encode(self)

        self.wint(0)
        self.wint(0)
        self.wint(0)

        self.wvint(self.game_type)
        self.wvint(self.map_mode)
        self.wvint(msg_game_mode)
        self.wbool(False)
        self.wvint(self.spectate_mode)
        self.wvint(0)

        loc_class    = self.location_global_id // 1000000
        loc_instance = self.location_global_id % 1000000
        self.wvint(loc_class)
        self.wvint(loc_instance)

        self.wbool(False)

        self.wbool(self.is_friendly)

        self.wvint(0)
        self.wvint(0)
