from L.BStream import Pkt


class KeepAliveServerMessage(Pkt):
    id      = 20108
    version = 0

    def encode(self):
        pass
