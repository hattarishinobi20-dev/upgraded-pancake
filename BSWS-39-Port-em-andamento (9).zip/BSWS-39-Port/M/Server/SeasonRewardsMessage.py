from L.BStream import Pkt

STAR_POINTS_TROPHIES_START = (550, 600, 650, 700, 750, 800, 850, 900, 950, 1000, 1050, 1100, 1150, 1200, 1250, 1300, 1350, 1400)
STAR_POINTS_TROPHIES_END   = (599, 649, 699, 749, 799, 849, 899, 949, 999, 1049, 1099, 1149, 1199, 1249, 1299, 1349, 1399, -1)
STAR_POINTS_REWARD_AMOUNT  = (70, 120, 160, 200, 220, 240, 260, 280, 300, 320, 340, 360, 380, 400, 420, 440, 460, 480)
STAR_POINTS_TROPHIES_RESET = (525, 550, 600, 650, 700, 725, 750, 775, 800, 825, 850, 875, 900, 925, 950, 975, 1000, 1025)


class SeasonRewardsMessage(Pkt):
    id      = 24123
    version = 0

    def encode(self):
        self.wvint(1)
        self.wvint(len(STAR_POINTS_TROPHIES_START))
        for index in range(len(STAR_POINTS_TROPHIES_START)):
            self.wvint(STAR_POINTS_TROPHIES_START[index] * 10)
            if STAR_POINTS_TROPHIES_END[index] != -1:
                self.wvint(STAR_POINTS_TROPHIES_END[index] * 10)
            else:
                self.wvint(-1)
            self.wvint(STAR_POINTS_REWARD_AMOUNT[index])
            self.wvint(STAR_POINTS_TROPHIES_RESET[index] * 10)
            self.wvint(0)
            self.wvint(0)
