from L.BStream import Pkt


class PlayerProfileMessage(Pkt):
    id = 24113

    def encode(self):
        self.wvlong(0, 1)
        self.wvint(0)

        # Brawlers
        brawlers = [0, 1]
        self.wvint(len(brawlers))
        for i in brawlers:
            self.wref(16, i)
            self.wref(0, 0)
            self.wvint(1250)
            self.wvint(1250)
            self.wvint(10)

        self.wvint(15)

        self.wvint(1)
        self.wvint(0)     # 3v3 Victories

        self.wvint(2)
        self.wvint(0)     # Experience

        self.wvint(3)
        self.wvint(13)    # Current Trophies

        self.wvint(4)
        self.wvint(-1337) # Highest Trophies

        self.wvint(5)
        self.wvint(len(brawlers))  # Brawlers Count

        self.wvint(8)
        self.wvint(0)     # Solo Victories

        self.wvint(11)
        self.wvint(0)     # Duo Victories

        self.wvint(9)
        self.wvint(0)     # Highest Robo Rumble LVL

        self.wvint(12)
        self.wvint(0)     # Highest Boss Fight LVL

        self.wvint(13)
        self.wvint(100)

        self.wvint(14)
        self.wvint(0)

        self.wvint(15)
        self.wvint(0)     # Most Challenge Wins

        self.wvint(16)
        self.wvint(0)     # Highest Rampage LVL

        self.wvint(18)
        self.wvint(0)     # Highest Solo League

        self.wvint(17)
        self.wvint(0)     # Highest Team League

        self.wstr("BSWS")
        self.wvint(100)
        self.wvint(28000000 + 2)   # Icon (Shelly default)
        self.wvint(43000000 + 4)
        self.wvint(-64)

        self.wvint(0)
        self.wvint(0)
