import time

from L.BStream import Buf
from M.Server.KeepAliveServerMessage import KeepAliveServerMessage
from M.Server.LobbyInfoMessage import LobbyInfoMessage


class KeepAliveMessage(Buf):
    id = 10108

    def __init__(self, connection, header_bytes):
        super().__init__(header_bytes)
        self.connection = connection

    def decode(self):
        pass

    def process(self):
        self.connection.last_keep_alive = time.monotonic()
        KeepAliveServerMessage(self.connection).send(0)
        LobbyInfoMessage(self.connection).send(0)
