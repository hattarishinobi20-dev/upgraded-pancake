from L.BStream import Buf
import G.Training as Training


class SinglePlayerMatchRequestMessage(Buf):
    def __init__(self, connection, header_bytes):
        super().__init__(header_bytes)
        self.connection = connection

    def decode(self):
        self.character_class    = self.rvint()
        self.character_instance = self.rvint()
        self.skin_class         = self.rvint()
        self.skin_instance      = self.rvint()

    def process(self):
        character_global_id = self.character_class * 1000000 + self.character_instance
        skin_global_id      = self.skin_class * 1000000 + self.skin_instance
        Training.start(self.connection, character_global_id, skin_global_id)
