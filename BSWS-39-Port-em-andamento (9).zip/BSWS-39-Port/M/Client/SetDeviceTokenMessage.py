from L.BStream import Buf


class SetDeviceTokenMessage(Buf):
    id = 10113

    def __init__(self, connection, header_bytes):
        super().__init__(header_bytes)
        self.connection = connection

    def decode(self):
        self.token_length = self.rint()
        self.device_token = self.rbytes(self.token_length)
        self.device_type  = self.rint()

    def process(self):
        pass
