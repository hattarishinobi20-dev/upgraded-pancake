from L.BStream import Buf
import G.Matchmaking as Matchmaking


class CancelMatchmakingMessage(Buf):
    def __init__(self, connection, header_bytes):
        super().__init__(header_bytes)
        self.connection = connection

    def decode(self):
        pass

    def process(self):
        Matchmaking.cancel(self.connection)
