from L.BStream import Buf


class AttributionMessage(Buf):
    id = 30000

    def __init__(self, connection, header_bytes):
        super().__init__(header_bytes)
        self.connection = connection

    def decode(self):
        self.media_source = self.rstr()
        self.campaign     = self.rstr()
        self.ad_set       = self.rstr()
        self.ad           = self.rstr()
        self.channel      = self.rstr()
        self.sub_params   = [self.rstr() for _ in range(6)]
        self.agency       = self.rstr()
        self.attribution_type = self.rvint()
        self.install_time = self.rlong()
        self.click_time   = self.rlong()
        self.is_organic          = self.rbool()
        self.is_retargeting      = self.rbool()
        self.is_deferred_deeplink = self.rbool()
        self.is_first_launch     = self.rbool()
        self.country_code = self.rstr()
        self.language     = self.rstr()
        self.identifiers  = [self.rstr() for _ in range(14)]
        self.facebook_id  = self.rstr()

    def process(self):
        pass
