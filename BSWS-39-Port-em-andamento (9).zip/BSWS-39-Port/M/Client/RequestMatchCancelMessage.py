from L.BStream import Buf

import G.Matchmaking as Matchmaking
from M.Server.OwnHomeDataMessage import OwnHomeDataMessage


class RequestMatchCancelMessage(Buf):
    id = 14117

    def __init__(self, connection, header_bytes):
        super().__init__(header_bytes)
        self.connection = connection

    def decode(self):
        pass

    def process(self):
        Matchmaking.cancel(self.connection)
        OwnHomeDataMessage(self.connection).send(0)
