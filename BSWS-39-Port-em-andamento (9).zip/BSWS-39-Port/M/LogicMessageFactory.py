from M.Client.LoginMessage import LoginMessage
from M.Client.KeepAliveMessage import KeepAliveMessage
from M.Client.AnalyticEventMessage import AnalyticEventMessage
from M.Client.AccountIdentifiersMessage import AccountIdentifiersMessage
from M.Client.SetDeviceTokenMessage import SetDeviceTokenMessage
from M.Client.PlayerStatusMessage import PlayerStatusMessage
from M.Client.RequestLatencyTestStatusMessage import RequestLatencyTestStatusMessage
from M.Client.AttributionMessage import AttributionMessage
from M.Client.GetSeasonRewardsMessage import GetSeasonRewardsMessage
from M.Client.GetPlayerProfileMessage import GetPlayerProfileMessage
from M.Client.MatchmakeRequestMessage import MatchmakeRequestMessage
from M.Client.CancelMatchmakingMessage import CancelMatchmakingMessage
from M.Client.ClientInfoMessage import ClientInfoMessage
from M.Client.SinglePlayerMatchRequestMessage import SinglePlayerMatchRequestMessage
from M.Client.RequestMatchCancelMessage import RequestMatchCancelMessage
from M.Client.EndClientTurnMessage import EndClientTurnMessage
from M.Battle.ClientInputMessage import ClientInputMessage

identifiers = {
    10101: LoginMessage,
    10108: KeepAliveMessage,
    10110: AnalyticEventMessage,
    10111: AccountIdentifiersMessage,
    10113: SetDeviceTokenMessage,
    10177: ClientInfoMessage,
    10555: ClientInputMessage,
    14102: EndClientTurnMessage,
    14103: MatchmakeRequestMessage,
    14106: CancelMatchmakingMessage,
    14113: GetPlayerProfileMessage,
    14117: RequestMatchCancelMessage,
    19004: RequestLatencyTestStatusMessage,
    30000: AttributionMessage,
    14118: SinglePlayerMatchRequestMessage,
    14277: GetSeasonRewardsMessage,
    14366: PlayerStatusMessage,
}
