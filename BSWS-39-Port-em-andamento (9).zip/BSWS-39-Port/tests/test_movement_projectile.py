import csv
import sys
import unittest
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from G.Character import Character
from G.Skill import Skill
from G.Projectile import Projectile
from G.AreaEffect import AreaEffect
from G.Item import Item
from G.Assets import skill_data, projectile_data, area_effect_data, item_data


class FakeTile:
    def __init__(self, blocks_movement=False, blocks_projectiles=False, destructible=False):
        self.blocks_movement = blocks_movement
        self.blocks_projectiles = blocks_projectiles
        self.destructible = destructible
        self.destroyed = False

    def is_destructed(self):
        return self.destroyed

    def destruct(self, _pierces_environment=False):
        if self.destructible:
            self.destroyed = True


class FakeTileMap:
    def __init__(self, width=4, height=2, blocked=None):
        self.width = width
        self.height = height
        self.logic_width = width * 300
        self.logic_height = height * 300
        self.blocked = blocked or {}

    def get_tile(self, x, y, *_args):
        if not (0 <= x < self.width and 0 <= y < self.height):
            return None
        return self.blocked.get((x, y), FakeTile())


class FakePlayer:
    def __init__(self, team, index):
        self.team_index = team
        self.player_index = index
        self.ulti_charge = 0
        self.over_charging = False

    def add_ulti_charge(self, amount):
        self.ulti_charge = max(0, min(self.ulti_charge + amount, 4000))


class FakeBattle:
    def __init__(self, tilemap, ticks=0, characters=None):
        self.tilemap = tilemap
        self.ticks = ticks
        self.characters = characters or []
        self.players = []
        self.player = None


class FakeManager:
    def __init__(self, battle):
        self.battle = battle
        self.objects = []

    def add(self, game_object):
        self.objects.append(game_object)
        if hasattr(game_object, 'attach') and game_object.get_manager() is None:
            game_object.attach(self, 2000000 + len(self.objects))

    def get_characters(self):
        return self.battle.characters

    def get_by_index(self, index):
        return next((character for character in self.battle.characters
                     if character.get_index() == index), None)


class FakeCharacter:
    def __init__(self, global_id, index, x, y, radius=30):
        self.global_id = global_id
        self.index = index
        self.x, self.y = x, y
        self.radius = radius
        self.data = {'CollisionRadius': radius}
        self.is_alive_state = True
        self.is_hero = False
        self.is_in_realm = False
        self.hp = 1000
        self.max_hp = 1000
        self.healing_suppression_percent = 0
        self.healing_suppression_ticks = 0
        self.poison_events = []
        self.ulti_charge_gained = 0
        self.stun_ticks = 0
        self.slow_events = []
        self.extra_regen_events = []
        self.electrocution_events = []
        self.star_power_data = None

    def get_card_value_for_passive(self, passive_type, index):
        cards = self.star_power_data
        if cards is None:
            return -1
        if isinstance(cards, list):
            for card in cards:
                if card.get('Type') == passive_type:
                    if index == 2:
                        return int(card.get('Value3') or 0)
                    if index > 0:
                        return int(card.get('Value') or 0)
                    return int(card.get('Value2') or 0)
            return -1
        card = cards
        if not card or card.get('Type') != passive_type:
            return -1
        if index == 2:
            return int(card.get('Value3') or 0)
        if index > 0:
            return int(card.get('Value') or 0)
        return int(card.get('Value2') or 0)

    def add_extra_health_regen(self, ticks, amount, index):
        self.extra_regen_events.append((ticks, amount, index))

    def give_electrocution(self, damage, normal_damage, effect_type, bounces):
        self.electrocution_events.append((damage, normal_damage, effect_type, bounces))

    def get_global_id(self):
        return self.global_id

    def get_index(self):
        return self.index

    def get_radius(self):
        return self.radius

    def get_hitpoint_percentage(self):
        return self.hp * 100 // max(1, self.max_hp)

    def is_alive(self):
        return self.hp > 0

    def get_player(self):
        return None

    def cripple(self, percent, ticks=80):
        self.cripple_event = (percent, ticks)

    def is_immune_and_bullets_go_through(self, _is_in_realm=False):
        return False

    def cause_damage(self, damage, _source=None, _is_ulti=False):
        self.hp -= damage
        return True

    def heal(self, _dealer_index, healing, _show, _projectile_data=None):
        self.hp += healing
        return True

    def gain_ulti_charge(self, damage):
        self.ulti_charge_gained += damage

    def get_gear_boost(self, _logic_type):
        return 0

    def apply_healing_suppression(self, percent, ticks):
        self.healing_suppression_percent = max(self.healing_suppression_percent, percent)
        self.healing_suppression_ticks = max(self.healing_suppression_ticks, ticks)

    def add_poison(self, damage, normal_dmg, is_ulti, source, source_index, poison_type):
        self.poison_events.append((damage, normal_dmg, is_ulti, source, source_index, poison_type))

    def trigger_stun(self, ticks, _force=False):
        self.stun_ticks = ticks

    def give_speed_slower_buff(self, modifier, duration):
        self.slow_events.append((modifier, duration))

    def trigger_pushback(self, _x, _y, _length):
        pass


class MovementAndProjectileTests(unittest.TestCase):
    def _new_melee_owner(self, battle, index=0, x=100, y=100):
        character = Character.__new__(Character)
        character._manager = FakeManager(battle)
        character.data = {'CollisionRadius': 50}
        character.x, character.y = x, y
        character.set_index(index)
        character.is_in_realm = False
        character.is_alive_state = True
        character.skills = []
        character.weapon_skill = None
        character.ultimate_skill = None
        character.speed = 720
        character.unique_property = 0
        character.charged_shot_count = 0
        character.charged_shot_misses = 0
        character.move_angle = 0
        character.attack_angle = 0
        character.using_ulti = False
        character.star_power_data = None
        character.rapid_fire_projectile = None
        character.rapid_fire_bullets = 1
        character.rapid_fire_spread = 0
        character.rapid_fire_normal_dmg = 0
        character.rapid_fire_attack_pattern = 0
        character.rapid_fire_shoot_times = 1
        character.rapid_fire_range = 0
        character.shoot_index = 0
        character.cripple_percent = 0
        character.melee_attack_pushbacks = False
        character.charge_pushback = 0
        character.hp = 1000
        character.max_hp = 1000
        character.left_hand = 0
        character.hero_level = 0
        character.immunities = []
        character.healing_suppression_ticks = 0
        character.healing_suppression_percent = 0
        character.damage_numbers = []
        battle.manager = character._manager
        return character

    def test_melee_attack_supports_single_target_and_wide_swing(self):
        near = FakeCharacter(1000001, 16, 400, 100)
        far = FakeCharacter(1000002, 32, 410, 130)
        battle = FakeBattle(FakeTileMap(), characters=[near, far])
        owner = self._new_melee_owner(battle)
        hits = owner.melee_attack(600, 100, 300, range_limit=500, spread=300,
                                  multi_target=False, aim_range=500)
        self.assertEqual(hits, 1)
        self.assertEqual(near.hp, 700)
        self.assertEqual(far.hp, 1000)

        near.hp = far.hp = 1000
        hits = owner.melee_attack(600, 100, 300, range_limit=500, spread=300,
                                  multi_target=True, aim_range=500)
        self.assertEqual(hits, 2)
        self.assertEqual(near.hp, 700)
        self.assertEqual(far.hp, 700)

    def test_attack_pattern_7_fans_parallel_projectiles_by_projectile_radius(self):
        battle = FakeBattle(FakeTileMap())
        owner = self._new_melee_owner(battle, x=100, y=100)
        owner.data['TwoWeaponAttackEffectOffset'] = '0'
        owner.left_hand = 0
        owner.rapid_fire_projectile = {
            'Name': 'BlowerProjectile', 'Radius': '50', 'Speed': '3000',
        }
        owner.rapid_fire_bullets = 6
        owner.rapid_fire_spread = 0
        owner.rapid_fire_normal_dmg = 280
        owner.rapid_fire_attack_pattern = 7
        owner.rapid_fire_shoot_times = 1
        owner.shoot_index = 0
        owner.using_ulti = False
        owner.cripple_percent = 0
        owner.rapid_fire_range = 25
        captured = []
        with patch.object(Character, 'spawn_projectile',
                          side_effect=lambda *args: captured.append(
                              (args[2], args[3], args[10], args[11]))):
            owner.fire_attack(500, 100, damage=280)
        self.assertEqual(len(captured), 6)
        self.assertEqual([shot[1] for shot in captured], [-150, -50, 50, 150, 250, 350])
        self.assertEqual([shot[0] for shot in captured], [500] * 6)
        self.assertEqual([shot[3] for shot in captured], [-250, -150, -50, 50, 150, 250])
        self.assertEqual([shot[1] for shot in captured],
                         [100 + shot[3] for shot in captured])

    def test_attack_passives_add_damage_and_apply_bush_ambush_only_to_weapon(self):
        for passive_type, value, in_bush, ultimate, expected_hp in (
            ('damage_main_attack', 200, False, False, 800),
            ('ambush', 200, True, False, 800),
            ('gain_damage_super', 200, False, True, 800),
        ):
            with self.subTest(passive=passive_type):
                target = FakeCharacter(1000001, 16, 400, 100)
                target.hp = 2000
                battle = FakeBattle(FakeTileMap(), characters=[target])
                owner = self._new_melee_owner(battle)
                owner.star_power_data = {'Type': passive_type, 'Value': str(value)}
                owner.cripple_percent = 0
                owner.using_ulti = ultimate
                patcher = patch.object(Character, 'is_in_bush', return_value=in_bush)
                with patcher:
                    owner.fire_attack(600, 100, damage=1000, normal_dmg=1000)
                self.assertEqual(target.hp, expected_hp)

    def test_spawn_projectile_copies_attack_passives_into_projectile_state(self):
        battle = FakeBattle(FakeTileMap())
        owner = self._new_melee_owner(battle)
        projectile = Projectile(6, 0, 'SniperProjectile')
        values = {
            ('heal_main_attack', 1): 700,
            ('heal_others_main_attack', 1): 48,
            ('bounced_bullets_stronger', 1): 124,
            ('cripple', 1): 25,
            ('basic_freeze', 1): 10,
            ('basic_freeze', 0): 350,
            ('prey_on_the_weak', 1): 50,
            ('prey_on_the_weak', 0): 152,
        }
        with (
            patch.object(Projectile, 'shoot_projectile', return_value=projectile),
            patch.object(Projectile, 'run_early_ticks'),
            patch.object(Character, 'get_card_value_for_passive',
                         side_effect=lambda kind, index: values.get((kind, index), -1)),
        ):
            owner.spawn_projectile(
                battle, projectile.data, 500, 100, 300, 250, 0, 0, False,
                0, 0, 0)
        self.assertEqual(projectile.healing, 700)
        self.assertEqual(projectile.heal_others_area_effect, 48)
        self.assertEqual(projectile.damage_add_from_bounce, 124)
        self.assertEqual(projectile.cripple_percent, 25)
        self.assertEqual((projectile.freeze_duration, projectile.freeze_strength), (10, 350))
        self.assertEqual((projectile.prey_on_weak_percent, projectile.prey_on_weak_damage), (50, 152))

    def test_projectile_attack_passives_apply_prey_cripple_and_freeze_on_hit(self):
        owner = FakeCharacter(1000000, 0, 100, 100)
        target = FakeCharacter(1000001, 16, 100, 100)
        target.max_hp = 1000
        target.hp = 400
        projectile = Projectile.__new__(Projectile)
        projectile.hit_objects = set()
        projectile.data = {'Name': 'TestAttack'}
        projectile.owner_index = 0
        projectile.damage = 100
        projectile.normal_dmg = 90
        projectile.owner = owner
        projectile.skill_type = 1
        projectile.pushback_strength = 0
        projectile.pierces_characters = True
        projectile.prey_on_weak_percent = 50
        projectile.prey_on_weak_damage = 152
        projectile.cripple_percent = 25
        projectile.freeze_duration = 10
        projectile.freeze_strength = 350
        projectile.x = projectile.y = 100
        projectile.hit(target)
        self.assertEqual(target.hp, 148)
        self.assertEqual(target.cripple_event, (25, 80))
        self.assertEqual(target.slow_events, [(-350, 10)])

    def test_projectile_heal_attack_passive_heals_allies(self):
        target = FakeCharacter(1000001, 1, 100, 100)
        target.is_hero = True
        target.hp = 500
        projectile = Projectile.__new__(Projectile)
        projectile.hit_objects = set()
        projectile.data = {'Name': 'TestAttack'}
        projectile.owner_index = 0
        projectile.damage = 300
        projectile.normal_dmg = 250
        projectile.owner = FakeCharacter(1000000, 0, 100, 100)
        projectile.skill_type = 1
        projectile.pushback_strength = 0
        projectile.pierces_characters = True
        projectile.healing = 200
        projectile.x = projectile.y = 100
        projectile.hit(target)
        self.assertEqual(target.hp, 700)
        self.assertEqual(target.ulti_charge_gained, 0)

    def test_heal_self_main_attack_heals_owner_on_non_ulti_shot(self):
        battle = FakeBattle(FakeTileMap())
        owner = self._new_melee_owner(battle)
        owner.hp = 500
        owner.max_hp = 1000
        owner.star_power_data = {'Type': 'heal_self_main_attack', 'Value': '300'}
        owner.rapid_fire_projectile = {'Name': 'TestWeaponProjectile', 'Speed': '1000'}
        fake_proj = Projectile.__new__(Projectile)
        fake_proj.hit_objects = set()
        fake_proj.hit_cooldowns = {}
        fake_proj.target_hit_counts = {}
        with (patch.object(Projectile, 'shoot_projectile', return_value=fake_proj),
              patch.object(Projectile, 'run_early_ticks'),
              patch.object(Projectile, 'set_index')):
            owner.fire_attack(500, 100, damage=200)
        self.assertEqual(owner.hp, 800)

    def _make_shield_target(self, passive):
        target = Character.__new__(Character)
        target._manager = None
        target._index = 16
        target.data = {}
        target.hp = 1000
        target.max_hp = 1000
        target.is_alive_state = True
        target.is_invincible = False
        target.gear1 = None
        target.gear2 = None
        target.star_power_data = passive
        target.shield_ticks = 0
        target.shield_percent = 0
        target.move_angle = 0
        target.x = 100
        target.y = 100
        target.skills = []
        target.using_ulti = False
        return target

    def test_reduce_all_damage_passive_shields_incoming_damage(self):
        target = self._make_shield_target({'Type': 'reduce_all_damage', 'Value': '30'})
        attacker = FakeCharacter(1000000, 0, 500, 100)
        with (patch.object(Character, 'get_player', return_value=None),
              patch.object(Character, 'die')):
            target.cause_damage(1000, attacker)
        self.assertEqual(target.hp, 300)

    def test_running_reduces_damage_passive_shields_when_attacker_is_behind(self):
        target = self._make_shield_target(
            {'Type': 'running_reduces_damage', 'Value': '20', 'Value2': '180'})
        attacker = FakeCharacter(1000000, 0, -300, 100)
        with (patch.object(Character, 'get_player', return_value=None),
              patch.object(Character, 'die')):
            target.cause_damage(1000, attacker)
        self.assertEqual(target.hp, 200)

    def test_always_bounce_shot_forces_chain_on_wall_and_no_hit(self):
        owner = FakeCharacter(1000000, 0, 100, 100)
        owner.star_power_data = {'Type': 'always_bounce_shot', 'Value': '1'}
        projectile = Projectile.__new__(Projectile)
        projectile.data = {
            'ChainBullet': 'TestChain', 'ChainBullets': '3',
            'ChainTravelDistance': '10', 'ExecuteChainSpecialCase': '0',
        }
        projectile.owner = owner
        projectile.owner_index = 0
        projectile.hit_objects = set()
        projectile.is_in_realm = False
        projectile.is_chained = False
        projectile.chain_triggered = False
        self.assertTrue(projectile._should_chain(no_hit=True))
        self.assertTrue(projectile._should_chain(wall_hit=True))

    def test_heal_others_attack_passive_spawns_owner_centered_healing_area(self):
        ally = FakeCharacter(1000002, 1, 250, 100)
        ally.hp = 500
        enemy = FakeCharacter(1000003, 16, 120, 100)
        battle = FakeBattle(FakeTileMap(), characters=[ally, enemy])
        owner = self._new_melee_owner(battle, index=0, x=100, y=100)
        projectile = Projectile.__new__(Projectile)
        projectile.hit_objects = set()
        projectile.data = {'Name': 'TestAttack'}
        projectile.owner_index = 0
        projectile.damage = 100
        projectile.normal_dmg = 90
        projectile.owner = owner
        projectile.skill_type = 1
        projectile.pushback_strength = 0
        projectile.pierces_characters = True
        projectile.heal_others_area_effect = 48
        projectile.x = projectile.y = 120
        projectile.hit(enemy)
        self.assertEqual(enemy.hp, 900)
        self.assertEqual(ally.hp, 548)
        self.assertEqual(len(battle.manager.objects), 1)
        self.assertEqual(battle.manager.objects[0].damage, -48)

    def test_reload_on_hit_passive_recharges_weapon(self):
        enemy = FakeCharacter(1000001, 16, 100, 100)
        battle = FakeBattle(FakeTileMap(), characters=[enemy])
        owner = self._new_melee_owner(battle)
        owner.hero_level = 0
        owner.star_power_data = {'Type': 'reload_on_hit', 'Value': '40'}
        owner.weapon_skill = Skill('SniperWeapon', False, owner)
        owner.weapon_skill.charge = 1000
        projectile = Projectile.__new__(Projectile)
        projectile.hit_objects = set()
        projectile.data = {'Name': 'SniperProjectile'}
        projectile.owner_index = 0
        projectile.damage = 100
        projectile.normal_dmg = 90
        projectile.owner = owner
        projectile.skill_type = 1
        projectile.pushback_strength = 0
        projectile.pierces_characters = True
        projectile.x = projectile.y = 100
        projectile.hit(enemy)
        self.assertEqual(owner.weapon_skill.charge, 1400)

    def test_increase_dmg_consecutive_dot_scales_repeat_hits(self):
        target = FakeCharacter(1000001, 16, 100, 100)
        battle = FakeBattle(FakeTileMap(), characters=[target])
        owner = self._new_melee_owner(battle)
        owner.star_power_data = {'Type': 'increase_dmg_consecutive_dot', 'Value': '25'}
        projectile = Projectile.__new__(Projectile)
        projectile._manager = battle.manager
        projectile.hit_objects = set()
        projectile.hit_cooldowns = {}
        projectile.target_hit_counts = {}
        projectile.data = {
            'Name': 'MummyProjectile', 'DamagesConstantlyTickDelay': '7',
            'DamagePercentStart': '100', 'DamagePercentEnd': '100',
        }
        projectile.total_delta = 0
        projectile.damage = 1000
        projectile.normal_dmg = 0
        projectile.owner = owner
        projectile.owner_index = 0
        projectile.skill_type = 1
        projectile.pushback_strength = 0
        projectile.pierces_characters = True
        projectile.x = projectile.y = 100
        projectile.prev_x = projectile.prev_y = 100
        projectile.hit(target)
        first_damage = 1000 - target.hp
        target.hp = 1000
        projectile.hit(target)
        second_damage = 1000 - target.hp
        self.assertEqual(first_damage, 1000)
        self.assertEqual(second_damage, 1250)

    def test_charge_hit_applies_fire_dot_ulti_and_charge_ulti_on_kill(self):
        enemy = FakeCharacter(1000001, 16, 100, 100)
        enemy.hp = 50
        battle = FakeBattle(FakeTileMap(), characters=[enemy])
        player = FakePlayer(0, 0)
        battle.player = player
        battle.players = [player]
        owner = self._new_melee_owner(battle, index=0)
        passives = {
            'fire_dot_ulti': {'Value': '200'},
            'charge_ulti_on_kill': {'Value': '1'},
        }

        def get_passive(kind, index):
            card = passives.get(kind)
            if card is None:
                return -1
            if index == 2:
                return int(card.get('Value3') or 0)
            if index > 0:
                return int(card.get('Value') or 0)
            return int(card.get('Value2') or 0)

        with patch.object(Character, 'get_card_value_for_passive',
                          side_effect=lambda kind, index: get_passive(kind, index)):
            owner.is_charging = True
            owner.active_charge_type = 4
            owner.is_boss = False
            owner.is_train = False
            owner.charge_damage = 100
            owner.charge_normal_dmg = 90
            owner.charge_hit_ids = []
            owner.charge_pushback = 0
            owner.charge_hits = 0
            owner.cripple_percent = 0
            owner.buffs = []
            owner.tick_charge()
        self.assertLessEqual(enemy.hp, 0)
        self.assertEqual(len(enemy.poison_events), 1)
        self.assertEqual(enemy.poison_events[0][0], 200)
        self.assertEqual(player.ulti_charge, 4000)

    def test_undertaker_weapon_dispatches_its_data_defined_charge(self):
        battle = FakeBattle(FakeTileMap())
        owner = self._new_melee_owner(battle)
        owner.hero_level = 0
        owner.charge_normal_dmg = 0
        skill = Skill('UndertakerWeapon', False, owner)
        skill.x, skill.y = 700, 100
        with patch.object(Character, 'trigger_charge', return_value=True) as trigger:
            skill.run_behavior(owner, 0)
        trigger.assert_called_once_with(700, 100, 2700, 4, 990, 0, False, {})
        self.assertEqual(owner.charge_normal_dmg, 900)
        self.assertFalse(skill.on_activate)

    def test_fire_attack_routes_projectileless_weapon_to_melee_resolver(self):
        target = FakeCharacter(1000001, 16, 400, 100)
        battle = FakeBattle(FakeTileMap(), characters=[target])
        owner = self._new_melee_owner(battle)
        owner.weapon_skill = None
        owner.rapid_fire_projectile = None
        owner.rapid_fire_bullets = 1
        owner.rapid_fire_spread = 300
        owner.rapid_fire_normal_dmg = 300
        owner.using_ulti = False
        owner.rapid_fire_attack_pattern = 0
        owner.rapid_fire_shoot_times = 1
        owner.shoot_index = 0
        owner.cripple_percent = 0
        owner.rapid_fire_range = 5
        owner.fire_attack(600, 100, damage=300)
        self.assertEqual(target.hp, 700)

    def test_melee_attack_obeys_walls(self):
        target = FakeCharacter(1000001, 16, 450, 100)
        tilemap = FakeTileMap(blocked={(1, 0): FakeTile(blocks_movement=True)})
        battle = FakeBattle(tilemap, characters=[target])
        owner = self._new_melee_owner(battle)
        hits = owner.melee_attack(600, 100, 300, range_limit=500, spread=300,
                                  multi_target=True, aim_range=500)
        self.assertEqual(hits, 0)
        self.assertEqual(target.hp, 1000)

    def test_every_hero_weapon_skill_and_projectile_reference_resolves(self):
        base = ROOT / 'Assets' / 'csv_logic'
        with (base / 'characters.csv').open(encoding='utf-8-sig', newline='') as handle:
            characters = list(csv.DictReader(handle))
        with (base / 'skills.csv').open(encoding='utf-8-sig', newline='') as handle:
            skill_rows = {row['Name']: row for row in csv.DictReader(handle)}
        missing = []
        heroes = [row for row in characters if row.get('Type') == 'Hero']
        projectile_names = set()
        projectile_reference_names = set()
        supported_behaviors = {'Attack', 'Charge'}
        supported_patterns = {0, 1, 2, 3, 4, 5, 6, 7, 10}
        for hero in heroes:
            skill_name = hero.get('WeaponSkill', '')
            skill = skill_rows.get(skill_name) or skill_data(skill_name)
            if not skill:
                missing.append((hero['Name'], 'weapon-skill', skill_name))
                continue
            behavior = skill.get('BehaviorType', '')
            if behavior not in supported_behaviors:
                missing.append((hero['Name'], 'weapon-behavior', behavior))
            spawned_item = skill.get('SpawnedItem', '')
            if spawned_item and not item_data(spawned_item):
                missing.append((hero['Name'], 'spawned-item', spawned_item))
            secondary_projectile = skill.get('SecondaryProjectile', '')
            if secondary_projectile:
                projectile_reference_names.add(secondary_projectile)
                if not projectile_data(secondary_projectile):
                    missing.append((hero['Name'], 'secondary-projectile', secondary_projectile))
            projectile_name = skill.get('Projectile', '')
            if projectile_name:
                projectile_names.add(projectile_name)
                projectile_reference_names.add(projectile_name)
                if not projectile_data(projectile_name):
                    missing.append((hero['Name'], 'projectile', projectile_name))
            if behavior == 'Attack':
                pattern = int(skill.get('AttackPattern') or 0)
                if pattern not in supported_patterns:
                    missing.append((hero['Name'], 'attack-pattern', pattern))
                if not projectile_name:
                    area_name = skill.get('AreaEffectObject') or ''
                    if area_name and not area_effect_data(area_name):
                        missing.append((hero['Name'], 'weapon-area-effect', area_name))
                    if not (area_name or skill.get('AttackEffect')):
                        missing.append((hero['Name'], 'nonprojectile-attack-handler', skill_name))
        for projectile_name in sorted(projectile_reference_names):
            data = projectile_data(projectile_name)
            for field in ('ChainBullet', 'SpawnAreaEffectObject', 'SpawnAreaEffectObject2'):
                reference = data.get(field, '')
                if not reference:
                    continue
                resolved = projectile_data(reference) if field == 'ChainBullet' else area_effect_data(reference)
                if not resolved:
                    missing.append((projectile_name, field, reference))
        self.assertEqual(len(heroes), 58)
        self.assertEqual(len(projectile_names), 50)
        self.assertEqual(missing, [])

    def test_constant_flight_time_is_independent_of_aim_distance(self):
        cluster_bomb = Projectile(6, 0, 'ClusterBombProjectile')
        wally = Projectile(6, 0, 'WallyProjectile')
        self.assertEqual(cluster_bomb.travel_ticks(500, 450), 40)
        self.assertEqual(cluster_bomb.travel_ticks(5000, 450), 40)
        self.assertEqual(wally.travel_ticks(500, 1700), 11)
        self.assertEqual(wally.travel_ticks(5000, 1700), 11)

    def test_travel_type_1_projectile_tracks_its_receding_aim_point(self):
        battle = FakeBattle(FakeTileMap(width=12, height=4), ticks=1)
        manager = FakeManager(battle)
        battle.manager = manager
        projectile = Projectile(6, 0, 'MummyProjectile')
        projectile._manager = manager
        projectile.deployed_tick = 0
        projectile.ending_tick = 20
        projectile.length_delta = 50
        projectile.start_x = projectile.now_x = projectile.x = 100
        projectile.start_y = projectile.now_y = projectile.y = 100
        projectile.target_x = projectile.original_end_x = 1000
        projectile.target_y = projectile.original_end_y = 100
        projectile.tick()
        self.assertEqual(projectile.target_x, 2350)
        self.assertEqual(projectile.x, 212)

    def test_travel_type_6_rebases_and_extends_after_half_flight(self):
        battle = FakeBattle(FakeTileMap(width=12, height=4), ticks=10)
        manager = FakeManager(battle)
        battle.manager = manager
        projectile = Projectile(6, 0, 'ControllerProjectile')
        projectile._manager = manager
        projectile.deployed_tick = 0
        projectile.ending_tick = 20
        projectile.length_delta = 50
        projectile.start_x = projectile.now_x = projectile.x = 100
        projectile.start_y = projectile.now_y = projectile.y = 100
        projectile.target_x = projectile.original_end_x = 1000
        projectile.target_y = projectile.original_end_y = 100
        projectile.tick()
        self.assertFalse(projectile.rotated_for_tp6)
        self.assertEqual(projectile.total_delta, 500)
        battle.ticks = 11
        projectile.tick()
        self.assertTrue(projectile.rotated_for_tp6)
        self.assertGreater(projectile.target_x, projectile.original_end_x)
        self.assertGreaterEqual(projectile.total_delta, 500)

    def test_bouncing_indirect_projectile_uses_arc_and_gravity_height(self):
        battle = FakeBattle(FakeTileMap(), ticks=0)
        manager = FakeManager(battle)
        battle.manager = manager
        projectile = Projectile(6, 0, 'TntDudeProjectile')
        projectile._manager = manager
        projectile.deployed_tick = 0
        projectile.ending_tick = 20
        projectile.length_delta = 50
        projectile.start_x = projectile.now_x = projectile.x = 100
        projectile.start_y = projectile.now_y = projectile.y = 100
        projectile.target_x, projectile.target_y = 2600, 100
        projectile.default_z = projectile.z = 300
        battle.ticks = 10
        projectile.update_position()
        self.assertNotEqual(projectile.x, 100 + (2600 - 100) // 2)
        self.assertGreater(projectile.z, 300)
        battle.ticks = 20
        projectile.update_position()
        self.assertEqual(projectile.z, 0)
        self.assertLess(abs(projectile.x - projectile.target_x), 100)

    def test_tnt_bounce_trajectory_matches_v39_piecewise_position_and_gravity(self):
        battle = FakeBattle(FakeTileMap(), ticks=3)
        manager = FakeManager(battle)
        battle.manager = manager
        projectile = Projectile(6, 0, 'TntDudeProjectile')
        projectile._manager = manager
        projectile.deployed_tick = 0
        projectile.ending_tick = 11
        projectile.length_delta = 90
        projectile.start_x = projectile.now_x = projectile.x = 100
        projectile.start_y = projectile.now_y = projectile.y = 100
        projectile.target_x, projectile.target_y = 1100, 100
        projectile.default_z = projectile.z = 300

        projectile.update_position()
        self.assertEqual((projectile.x, projectile.y, projectile.z), (435, 100, 579))
        battle.ticks = 8
        projectile.update_position()
        self.assertEqual((projectile.x, projectile.y, projectile.z), (948, 100, 34))
        battle.ticks = 11
        projectile.update_position()
        self.assertEqual((projectile.x, projectile.y, projectile.z), (1116, 100, 0))
        battle.ticks = 12
        projectile.update_position()
        self.assertEqual((projectile.x, projectile.y, projectile.z), (1100, 100, 0))

    def test_delayed_indirect_projectile_detonates_at_configured_tick(self):
        battle = FakeBattle(FakeTileMap(), ticks=0)
        manager = FakeManager(battle)
        battle.manager = manager
        projectile = Projectile(6, 0, 'TntDudeProjectile')
        projectile._manager = manager
        projectile.trigger_with_delay_ms = 100
        projectile.trigger_delay = 2
        projectile.deployed_tick = 0
        projectile.ending_tick = 1
        projectile.length_delta = 1000
        projectile.start_x, projectile.start_y = 100, 100
        projectile.target_x, projectile.target_y = 1000, 100
        projectile.x = projectile.now_x = projectile.prev_x = 100
        projectile.y = projectile.now_y = projectile.prev_y = 100
        projectile.owner = None
        projectile.hit_objects = set()
        projectile.hit_cooldowns = {}
        projectile.chain_triggered = False
        projectile.hit_any = False
        projectile.is_chained = False
        projectile.return_spawned = False
        battle.ticks = 1
        projectile.tick()
        self.assertEqual(projectile.state, 0)
        battle.ticks = 2
        projectile.tick()
        self.assertEqual(projectile.state, 4)
        self.assertEqual(projectile.total_delta, 1000)

    def test_boomerang_deploy_spawns_homing_return_projectile(self):
        owner = FakeCharacter(1000000, 0, 100, 100)
        battle = FakeBattle(FakeTileMap())
        manager = FakeManager(battle)
        battle.manager = manager
        source = Projectile.__new__(Projectile)
        source._manager = manager
        source.data = {
            'IsBoomerang': 'true', 'ChainBullet': 'WhirlwindProjectile2',
        }
        source.owner = owner
        source.skill_type = 1
        source.damage = 400
        source.normal_dmg = 400
        source.x, source.y = 600, 200
        source.state = 0
        source.display_scale = 0
        source.total_delta = 1000
        source.target_x, source.target_y = 600, 200
        source.on_deploy = False
        source.is_destroyed = False
        source.return_spawned = False
        captured = []
        returned = []

        class ReturningProjectile:
            def __init__(self):
                self.homing_target = None
                self.hit_objects = set()

            def run_early_ticks(self):
                pass

        def make_returning_projectile(*args):
            child = ReturningProjectile()
            captured.append(args)
            returned.append(child)
            return child

        with patch.object(Projectile, 'shoot_projectile', side_effect=make_returning_projectile):
            source.deploy()
        self.assertEqual(len(captured), 1)
        self.assertEqual(captured[0][2]['Name'], 'WhirlwindProjectile2')
        self.assertEqual((captured[0][3], captured[0][4]), (100, 100))
        self.assertEqual((captured[0][10], captured[0][11]), (600, 200))
        self.assertIs(returned[0].homing_target, owner)
        self.assertEqual(source.state, 4)
        self.assertTrue(source.return_spawned)

    def test_bouncing_projectile_reflects_at_wall_and_preserves_remaining_travel(self):
        wall = FakeTile(blocks_projectiles=True)
        battle = FakeBattle(FakeTileMap(blocked={(1, 0): wall}), ticks=10)
        manager = FakeManager(battle)
        battle.manager = manager
        projectile = Projectile.__new__(Projectile)
        projectile._manager = manager
        projectile.data = {
            'IsBouncing': 'true', 'MaxDistanceBounces': '1',
            'DistanceAddFromBounce': '0', 'Speed': '3000',
        }
        projectile.is_bouncing = True
        projectile.bounce_count = 0
        projectile.bounce_tile_index = -1
        projectile.pierces_environment = False
        projectile.speed = 3000
        projectile.start_x, projectile.start_y = 100, 150
        projectile.target_x, projectile.target_y = 500, 150
        projectile.x, projectile.y = 400, 150
        projectile.prev_x, projectile.prev_y = 100, 150
        projectile.now_x, projectile.now_y = 100, 150
        projectile.early_ticks = 0
        projectile.deployed_tick = 10
        projectile.ending_tick = 20
        projectile.total_delta = 300
        projectile.length_delta = 100
        projectile.hit_objects = set()
        projectile.hit_cooldowns = {}
        projectile.owner = None
        projectile.owner_index = 0
        projectile.skill_type = 1
        projectile.damage = 300
        projectile.damage_add_from_bounce = 124
        projectile.special_effect = False
        projectile.state = 0
        projectile.on_deploy = False
        self.assertTrue(projectile._trace_projectile_walls(100, 150, 400, 150))
        self.assertEqual((projectile.x, projectile.y), (250, 150))
        self.assertEqual((projectile.start_x, projectile.start_y), (250, 150))
        self.assertEqual((projectile.target_x, projectile.target_y), (75, 150))
        self.assertEqual(projectile.bounce_count, 1)
        self.assertEqual(projectile.bounce_tile_index, 1)
        self.assertEqual(projectile.damage, 424)
        self.assertEqual(projectile.damage_add_from_bounce, 0)
        self.assertTrue(projectile.special_effect)
        self.assertEqual(projectile.total_delta, 0)
        self.assertEqual(projectile.state, 0)

    def test_swept_projectile_collision_hits_between_tick_positions(self):
        projectile = Projectile.__new__(Projectile)
        self.assertTrue(projectile._segment_hits_character(0, 0, 1000, 0, 500, 50, 50))
        self.assertFalse(projectile._segment_hits_character(0, 0, 1000, 0, 500, 51, 50))
        self.assertFalse(projectile._segment_hits_character(0, 0, 1000, 0, 1002, 0, 1))

    def test_character_movement_stops_before_solid_tile(self):
        tilemap = FakeTileMap(blocked={(1, 0): FakeTile(blocks_movement=True)})
        character = Character.__new__(Character)
        character._manager = FakeManager(FakeBattle(tilemap, ticks=10))
        character.data = {'CollisionRadius': 50}
        character.x, character.y = 150, 150
        character.way_point_start = (150, 150)
        character.way_point = (750, 150)
        character.path_length = 600
        character.move_start, character.move_end = 0, 10
        character.update_position()
        self.assertLessEqual(character.x + character.get_radius(), 300)
        self.assertEqual(character.y, 150)

    def test_area_effect_uses_area_radius_and_does_not_hit_friendly_team(self):
        enemy = FakeCharacter(1000001, 16, 170, 150)
        friendly = FakeCharacter(1000002, 1, 170, 150)
        outside = FakeCharacter(1000003, 16, 181, 150)
        battle = FakeBattle(FakeTileMap(), characters=[enemy, friendly, outside])
        manager = FakeManager(battle)
        battle.manager = manager
        effect = AreaEffect(17, 0)
        effect.data = {'Type': 'Damage', 'TimeMs': '250', 'Radius': '100'}
        effect.radius = 100
        effect.attach(manager, 2000001)
        effect.set_position(100, 150, 0)
        effect.set_index(0)
        effect.damage = 400
        effect.set_source(None, 0)
        effect.trigger()
        self.assertEqual(enemy.hp, 600)
        self.assertEqual(friendly.hp, 1000)
        self.assertEqual(outside.hp, 1000)
        # Triggering an already active effect must not apply its instant damage twice.
        effect.trigger()
        self.assertEqual(enemy.hp, 600)

    def test_homing_projectile_acquires_nearest_enemy_and_steers_toward_it(self):
        enemy = FakeCharacter(1000001, 16, 450, 150)
        friendly = FakeCharacter(1000002, 1, 200, 150)
        battle = FakeBattle(FakeTileMap(), characters=[friendly, enemy])
        manager = FakeManager(battle)
        battle.manager = manager
        projectile = Projectile.__new__(Projectile)
        projectile._manager = manager
        projectile.data = {'HomeDistance': '2', 'SteerStrength': '5', 'SteerIgnoreTicks': '2'}
        projectile.travel_type = 4
        projectile.deployed_tick = -10
        projectile.early_ticks = 0
        projectile.homing_target = None
        projectile.owner = friendly
        projectile.owner_index = 0
        projectile.x, projectile.y = 150, 150
        projectile.target_x, projectile.target_y = 900, 150
        projectile.angle = 90
        projectile.speed = 2000
        projectile.length_delta = 100
        projectile.total_delta = 0
        projectile._acquire_homing_target()
        self.assertIs(projectile.homing_target, enemy)
        projectile._advance_steered_position()
        self.assertEqual(projectile.angle, 85)
        self.assertGreater(projectile.x, 150)
        self.assertGreater(projectile.y, 150)

    def test_healing_projectile_hits_teammates_only(self):
        owner = FakeCharacter(1000000, 0, 100, 150)
        ally = FakeCharacter(1000001, 1, 120, 150)
        enemy = FakeCharacter(1000002, 16, 120, 150)
        battle = FakeBattle(FakeTileMap(), characters=[owner, ally, enemy])
        manager = FakeManager(battle)
        battle.manager = manager
        projectile = Projectile.__new__(Projectile)
        projectile._manager = manager
        projectile.data = {'HealOwnPercent': '100', 'Radius': '0'}
        projectile.indirect = False
        projectile.pierces_characters = True
        projectile.owner = owner
        projectile.owner_index = 0
        projectile.damage = 400
        projectile.normal_dmg = 400
        projectile.skill_type = 1
        projectile.pushback_strength = 0
        projectile.hit_objects = set()
        projectile.total_delta = 1000
        projectile.x = projectile.prev_x = 100
        projectile.y = projectile.prev_y = 150
        self.assertFalse(projectile.check_collisions())
        self.assertEqual(ally.hp, 1400)
        self.assertEqual(enemy.hp, 1000)

    def test_projectile_applies_poison_stun_slow_and_lifesteal(self):
        owner = FakeCharacter(1000000, 0, 100, 150)
        owner.hp = 500
        target = FakeCharacter(1000001, 16, 200, 150)
        projectile = Projectile.__new__(Projectile)
        projectile.hit_objects = set()
        projectile.data = {
            'PoisonType': '1', 'PoisonDamagePercent': '25',
            'StunLengthMS': '1000', 'FreezeStrength': '30',
            'FreezeDurationMS': '500', 'LifeStealPercent': '20',
            'SuppressHealing': '40', 'SuppressHealingTicks': '80',
        }
        projectile.owner_index = 0
        projectile.damage = 400
        projectile.normal_dmg = 300
        projectile.owner = owner
        projectile.skill_type = 1
        projectile.pushback_strength = 0
        projectile.pierces_characters = True
        projectile.x, projectile.y = 100, 150
        projectile.hit(target)
        self.assertEqual(target.hp, 600)
        self.assertEqual(target.poison_events[0][:3], (100, 75, False))
        self.assertEqual(target.stun_ticks, 20)
        self.assertEqual(target.slow_events, [(-30, 10)])
        self.assertEqual(target.healing_suppression_percent, 40)
        self.assertEqual(target.healing_suppression_ticks, 80)
        self.assertEqual(owner.hp, 580)
        self.assertEqual(owner.ulti_charge_gained, 300)

    def test_snake_oil_regeneration_uses_stackable_health_regen_buff(self):
        target = Character.__new__(Character)
        target.buffs = []
        target.buffed_speed = 0
        target.add_extra_health_regen(61, 120, 16)
        self.assertEqual(len(target.buffs), 1)
        self.assertEqual((target.buffs[0].type, target.buffs[0].duration,
                          target.buffs[0].modifier, target.buffs[0].source_index),
                         (10, 61, 120, 16))

    def test_bea_charged_hit_loads_and_fires_secondary_projectile(self):
        owner = self._new_melee_owner(FakeBattle(FakeTileMap()))
        skill = Skill('BeeSniperWeapon', False)
        owner.weapon_skill = skill
        owner.skills = [skill]
        owner.charged_shot_count = 1
        owner.rapid_fire_projectile = projectile_data('BeeSniperProjectile')
        owner.rapid_fire_bullets = 1
        owner.rapid_fire_spread = 0
        owner.rapid_fire_normal_dmg = 800
        owner.rapid_fire_attack_pattern = 0
        owner.rapid_fire_shoot_times = 1
        owner.shoot_index = 0
        owner.cripple_percent = 0
        owner.rapid_fire_range = 30
        owner.left_hand = 0
        captured = []
        with patch.object(Character, 'spawn_projectile',
                          side_effect=lambda *args: captured.append(args)):
            owner.fire_attack(500, 100, damage=800)
        self.assertEqual(owner.charged_shot_count, 0)
        self.assertEqual(owner.charged_shot_misses, 1)
        self.assertEqual(captured[0][1]['Name'], 'BeeSniperChargedProjectile')
        self.assertEqual(captured[0][4], 2200)

    def test_bea_primary_hit_recharges_charged_shot(self):
        owner = FakeCharacter(1000000, 0, 100, 150)
        owner.weapon_skill = Skill('BeeSniperWeapon', False)
        owner.charged_shot_count = 0
        owner.get_max_charged_shots = lambda: 1
        target = FakeCharacter(1000001, 16, 200, 150)
        target.is_hero = True
        projectile = Projectile.__new__(Projectile)
        projectile.hit_objects = set()
        projectile.data = {'Name': 'BeeSniperProjectile'}
        projectile.owner_index = 0
        projectile.damage = projectile.normal_dmg = 200
        projectile.owner = owner
        projectile.skill_type = 1
        projectile.pushback_strength = 0
        projectile.pierces_characters = True
        projectile.x = projectile.y = 100
        projectile.hit(target)
        self.assertEqual(owner.charged_shot_count, 1)

    def test_colette_percent_damage_uses_current_hero_health_and_minimum(self):
        owner = FakeCharacter(1000000, 0, 100, 150)
        target = FakeCharacter(1000001, 16, 200, 150)
        target.is_hero = True
        target.hp = 4000
        projectile = Projectile.__new__(Projectile)
        projectile.hit_objects = set()
        projectile.data = {'Name': 'PercenterProjectile'}
        projectile.percent_damage = 37
        projectile.owner_index = 0
        projectile.damage = 1000
        projectile.normal_dmg = 800
        projectile.owner = owner
        projectile.skill_type = 1
        projectile.pushback_strength = 0
        projectile.pierces_characters = True
        projectile.x = projectile.y = 100
        projectile.hit(target)
        self.assertEqual(target.hp, 2520)
        self.assertEqual(owner.ulti_charge_gained, 1000)

    def test_percent_damage_applies_temporary_boost_and_cripple_with_original_order(self):
        owner = FakeCharacter(1000000, 0, 100, 150)
        target = FakeCharacter(1000001, 16, 200, 150)
        target.is_hero = True
        target.hp = 4000
        projectile = Projectile.__new__(Projectile)
        projectile.hit_objects = set()
        projectile.data = {'Name': 'PercenterProjectile'}
        projectile.percent_damage = 37
        projectile.percent_damage_buff = 20
        projectile.percent_damage_debuff = 10
        projectile.min_percent_damage = 750
        projectile.static_percent_damage = 0
        projectile.owner_index = 0
        projectile.damage = 1000
        projectile.normal_dmg = 800
        projectile.owner = owner
        projectile.skill_type = 1
        projectile.pushback_strength = 0
        projectile.pierces_characters = True
        projectile.x = projectile.y = 100
        projectile.hit(target)
        self.assertEqual(target.hp, 2401)

    def test_percent_damage_nonhero_uses_regular_damage_boost_not_cripple(self):
        owner = FakeCharacter(1000000, 0, 100, 150)
        target = FakeCharacter(1000001, 16, 200, 150)
        target.hp = 3000
        projectile = Projectile.__new__(Projectile)
        projectile.hit_objects = set()
        projectile.data = {'Name': 'PercenterProjectile'}
        projectile.percent_damage = 37
        projectile.percent_damage_buff = 20
        projectile.percent_damage_debuff = 50
        projectile.min_percent_damage = 750
        projectile.static_percent_damage = 0
        projectile.owner_index = 0
        projectile.damage = 1000
        projectile.normal_dmg = 800
        projectile.owner = owner
        projectile.skill_type = 1
        projectile.pushback_strength = 0
        projectile.pierces_characters = True
        projectile.x = projectile.y = 100
        projectile.hit(target)
        self.assertEqual(target.hp, 1800)

    def test_projectile_unique_properties_apply_snake_oil_regen_and_belle_chain(self):
        owner = FakeCharacter(1000000, 0, 100, 150)
        target = FakeCharacter(1000001, 16, 200, 150)
        target.is_hero = True
        snake_oil = Projectile.__new__(Projectile)
        snake_oil.hit_objects = set()
        snake_oil.data = {'UniqueProperty': '2'}
        snake_oil.owner_index = 0
        snake_oil.damage = snake_oil.normal_dmg = 120
        snake_oil.owner = owner
        snake_oil.skill_type = 1
        snake_oil.pushback_strength = 0
        snake_oil.pierces_characters = True
        snake_oil.x = snake_oil.y = 100
        snake_oil.hit(target)
        self.assertEqual(target.extra_regen_events, [(61, 120, 0)])

        belle = Projectile.__new__(Projectile)
        belle.hit_objects = set()
        belle.data = {'UniqueProperty': '3', 'AppliedEffectVisualType': '1'}
        belle.owner_index = 0
        belle.damage, belle.normal_dmg = 300, 250
        belle.owner = owner
        belle.skill_type = 1
        belle.pushback_strength = 0
        belle.pierces_characters = True
        belle.belle_weapon_bounces = 2
        belle.x = belle.y = 100
        belle.hit(target)
        self.assertEqual(target.electrocution_events, [(300, 250, 1, 2)])

    def test_healing_suppression_reduces_heals_then_expires(self):
        victim = Character.__new__(Character)
        victim._manager = None
        victim.hp = 500
        victim.max_hp = 1000
        victim.immunities = []
        victim.damage_numbers = []
        victim.healing_suppression_percent = 0
        victim.healing_suppression_ticks = 0
        victim.apply_healing_suppression(40, 1)
        victim.heal(0, 500, True)
        self.assertEqual(victim.hp, 800)
        self.assertEqual(victim.damage_numbers[-1]['value'], -300)
        victim.tick_healing_suppression()
        self.assertEqual(victim.healing_suppression_percent, 0)
        victim.heal(0, 100, True)
        self.assertEqual(victim.hp, 900)

    def test_chain_to_enemy_excludes_hit_target_and_clamps_chain_range(self):
        owner = FakeCharacter(1000000, 0, 100, 100)
        already_hit = FakeCharacter(1000001, 16, 250, 100)
        next_enemy = FakeCharacter(1000002, 16, 1800, 100)
        battle = FakeBattle(FakeTileMap(), characters=[owner, already_hit, next_enemy])
        manager = FakeManager(battle)
        battle.manager = manager
        source = Projectile.__new__(Projectile)
        source._manager = manager
        source.data = {
            'ChainBullet': 'MechanicProjectile2', 'ChainsToEnemies': '1',
            'ChainTravelDistance': '5', 'ExecuteChainSpecialCase': '0',
        }
        source.owner = owner
        source.owner_index = 0
        source.is_in_realm = False
        source.hit_objects = {already_hit.get_global_id()}
        source.chain_triggered = False
        source.is_chained = False
        source.x, source.y = 250, 100
        source.start_x, source.start_y = 100, 100
        source.target_x, source.target_y = 250, 100
        source.damage = source.normal_dmg = 300
        source.total_delta = 1000
        source.skill_type = 1
        spawned = []

        class Child:
            def __init__(self):
                self.hit_objects = set()
                self.is_chained = False

            def run_early_ticks(self):
                pass

        def fake_shoot(*args):
            child = Child()
            spawned.append((args, child))
            return child

        with patch.object(Projectile, 'shoot_projectile', side_effect=fake_shoot):
            children = source.execute_chain(x=250, y=100, character_hit=True)
        self.assertEqual(len(children), 1)
        args, child = spawned[0]
        self.assertEqual(args[2]['Name'], 'MechanicProjectile2')
        self.assertEqual((args[3], args[4]), (750, 100))
        self.assertEqual((args[10], args[11]), (250, 100))
        self.assertEqual(child.hit_objects, {already_hit.get_global_id()})
        self.assertTrue(child.is_chained)

    def test_power_leveler_chain_splits_followup_projectile_damage(self):
        battle = FakeBattle(FakeTileMap(width=12, height=6), ticks=0)
        manager = FakeManager(battle)
        battle.manager = manager
        owner = FakeCharacter(1000000, 0, 100, 100)
        owner.get_power_level = lambda: 0
        projectile = Projectile(6, 0, 'PowerLevelerProjectile')
        projectile._manager = manager
        projectile.owner = owner
        projectile.owner_index = owner.index
        projectile.skill_type = 1
        projectile.damage = 400
        projectile.normal_dmg = 300
        projectile.x = projectile.y = 500
        projectile.start_x = projectile.start_y = 100
        projectile.target_x, projectile.target_y = 500, 100
        created = []

        class Child:
            def __init__(self):
                self.hit_objects = set()
                self.is_chained = False

            def run_early_ticks(self):
                pass

        def spawn(*args):
            created.append(args)
            return Child()

        with patch.object(Projectile, 'shoot_projectile', side_effect=spawn):
            children = projectile.execute_chain(character_hit=True)
        self.assertEqual(len(children), 2)
        self.assertEqual([shot[5] for shot in created], [200, 200])
        self.assertEqual([shot[15] for shot in created], [150, 150])

    def test_chain_bullet_fan_spawns_data_defined_count_and_no_hit_damage_split(self):
        owner = FakeCharacter(1000000, 0, 100, 100)
        battle = FakeBattle(FakeTileMap())
        manager = FakeManager(battle)
        battle.manager = manager
        source = Projectile.__new__(Projectile)
        source._manager = manager
        source.data = {
            'ChainBullet': 'HookProjectile2', 'ChainBullets': '6',
            'ChainSpread': '200', 'ChainTravelDistance': '17',
            'ExecuteChainSpecialCase': '1',
        }
        source.owner = owner
        source.owner_index = 0
        source.is_in_realm = False
        source.hit_objects = set()
        source.chain_triggered = False
        source.is_chained = False
        source.x, source.y = 400, 100
        source.start_x, source.start_y = 100, 100
        source.target_x, source.target_y = 400, 100
        source.damage = source.normal_dmg = 600
        source.total_delta = 1000
        source.skill_type = 1
        spawned = []

        class Child:
            def __init__(self):
                self.hit_objects = set()
                self.is_chained = False

            def run_early_ticks(self):
                pass

        def fake_shoot(*args):
            child = Child()
            spawned.append((args, child))
            return child

        with patch.object(Projectile, 'shoot_projectile', side_effect=fake_shoot):
            children = source.execute_chain(x=400, y=100, no_hit=True)
        self.assertEqual(len(children), 6)
        self.assertTrue(all(args[5] == 100 and args[15] == 100 for args, _ in spawned))
        self.assertEqual(len({(args[3], args[4]) for args, _ in spawned}), 6)
        self.assertTrue(all(child.is_chained for _, child in spawned))

    def test_constant_damage_tick_respects_shared_projectile_cooldown(self):
        target = FakeCharacter(1000001, 16, 150, 100)
        battle = FakeBattle(FakeTileMap(), characters=[target])
        manager = FakeManager(battle)
        battle.manager = manager
        owner = FakeCharacter(1000000, 0, 100, 100)
        hit_objects = set()
        hit_cooldowns = {}

        def make_projectile():
            projectile = Projectile(6, 0, 'MummyProjectile')
            projectile._manager = manager
            projectile.owner = owner
            projectile.owner_index = 0
            projectile.skill_type = 1
            projectile.damage = 100
            projectile.normal_dmg = 100
            projectile.prev_x, projectile.prev_y = 100, 100
            projectile.x, projectile.y = 200, 100
            projectile.hit_objects = hit_objects
            projectile.hit_cooldowns = hit_cooldowns
            return projectile

        first, second = make_projectile(), make_projectile()
        first.check_collisions()
        second.check_collisions()
        self.assertEqual(target.hp, 900)
        battle.ticks = 7
        second.check_collisions()
        self.assertEqual(target.hp, 800)

    def test_projectile_damage_percent_scales_with_travel_progress(self):
        projectile = Projectile.__new__(Projectile)
        projectile.data = {'DamagePercentStart': '50', 'DamagePercentEnd': '150'}
        projectile.total_delta = 0
        self.assertEqual(projectile.modified_damage(1000), 650)
        projectile.total_delta = 500
        self.assertEqual(projectile.modified_damage(1000), 1150)
        projectile.total_delta = 1000
        self.assertEqual(projectile.modified_damage(1000), 1500)

    def test_damage_only_one_projectile_shares_target_hit_registry(self):
        owner = self._new_melee_owner(FakeBattle(FakeTileMap()), index=0)
        owner.data = {'TwoWeaponAttackEffectOffset': '0'}
        owner.left_hand = 0
        owner.rapid_fire_projectile = {'Name': 'pellet', 'DamageOnlyWithOneProj': 'true'}
        owner.rapid_fire_bullets = 3
        owner.rapid_fire_spread = 100
        owner.rapid_fire_normal_dmg = 200
        owner.rapid_fire_attack_pattern = 0
        owner.rapid_fire_shoot_times = 1
        owner.shoot_index = 0
        owner.using_ulti = False
        owner.cripple_percent = 0
        owner.rapid_fire_range = 5
        captured = []
        with patch.object(Character, 'spawn_projectile',
                          side_effect=lambda _self, *args: captured.append(args[-2:])):
            owner.fire_attack(500, 100, damage=200)
        self.assertEqual(len(captured), 3)
        hit_registry, cooldown_registry = captured[0]
        self.assertIsNotNone(hit_registry)
        self.assertTrue(all(registries[0] is hit_registry for registries in captured))
        self.assertTrue(all(registries[1] is cooldown_registry for registries in captured))

    def test_projectile_radius_uses_data_scale_not_flight_percentage(self):
        projectile = Projectile.__new__(Projectile)
        projectile.data = {'Radius': '150'}
        projectile.total_delta = 1000
        self.assertEqual(projectile.collision_radius(), 150)
        projectile.data = {'Radius': '150', 'ScaleStart': '0', 'ScaleEnd': '200'}
        projectile.total_delta = 500
        self.assertEqual(projectile.collision_radius(), 150)

    def test_knockback_stops_at_blocking_wall(self):
        tilemap = FakeTileMap(blocked={(1, 0): FakeTile(blocks_movement=True)})
        character = Character.__new__(Character)
        character._manager = FakeManager(FakeBattle(tilemap, ticks=1))
        character.data = {'CollisionRadius': 50}
        character.is_alive_state = True
        character.knockbacked = False
        character.knockback_ticks = 0
        character.x, character.y = 150, 150
        character.trigger_pushback(0, 150, 100)
        self.assertLessEqual(character.x + character.get_radius(), 300)
        self.assertEqual(character.y, 150)
        self.assertTrue(character.knockbacked)

    def test_sticky_bomb_weapon_spawns_and_triggers_its_mine_item(self):
        owner = FakeCharacter(1000000, 0, 100, 100)
        target = FakeCharacter(1000001, 16, 250, 100)
        battle = FakeBattle(FakeTileMap(), ticks=0, characters=[owner, target])
        manager = FakeManager(battle)
        battle.manager = manager
        projectile = Projectile(6, 0, 'StickyBombProjectile')
        projectile._manager = manager
        projectile.owner_index = owner.index
        projectile.owner = owner
        projectile.spawned_item_data = item_data('StickyBomb')
        projectile.damage = 1000
        projectile.x = projectile.y = 100
        projectile.deploy()
        mine = next(obj for obj in manager.objects if isinstance(obj, Item))
        self.assertEqual(mine.name, 'StickyBomb')
        self.assertEqual(mine.damage, 1000)
        mine.tick()
        self.assertTrue(mine.is_destroyed)
        self.assertTrue(mine.is_triggered)
        self.assertEqual(target.hp, 0)

    def test_weapon_bullet_explosion_spawns_child_projectiles_and_mines(self):
        source = FakeCharacter(1000000, 0, 100, 100)
        battle = FakeBattle(FakeTileMap())
        manager = FakeManager(battle)
        battle.manager = manager
        effect = AreaEffect(17, 0)
        effect.data = {
            'Type': 'BulletExplosion', 'CustomValue': '6',
            'BulletExplosionBullet': 'CactusSpike',
            'BulletExplosionBulletDistance': '13', 'BulletAngleOffset': '15',
        }
        effect.attach(manager, 2000001)
        effect.set_position(300, 300, 0)
        effect.set_index(0)
        effect.set_source(source, 1)
        effect.damage = effect.normal_dmg = 200
        spawned = []
        with patch.object(Projectile, 'shoot_projectile',
                          side_effect=lambda *args: spawned.append(args)):
            effect.trigger()
        self.assertEqual(len(spawned), 6)
        self.assertTrue(all(args[2]['Name'] == 'CactusSpike' for args in spawned))
        self.assertTrue(all((args[10], args[11]) == (300, 300) for args in spawned))
        self.assertTrue(all(args[5] == 200 and args[15] == 200 for args in spawned))

        mine_effect = AreaEffect(17, 0)
        mine_effect.data = {
            'Type': 'BulletExplosion', 'CustomValue': '3',
            'BulletExplosionItem': 'ClusterMine',
            'BulletExplosionBulletDistance': '4', 'BulletAngleOffset': '15',
        }
        mine_effect.attach(manager, 2000002)
        mine_effect.set_position(300, 300, 0)
        mine_effect.set_index(0)
        mine_effect.trigger()
        mines = [obj for obj in manager.objects if getattr(obj, 'name', '') == 'ClusterMine']
        self.assertEqual(len(mines), 3)
        self.assertTrue(all(obj.get_index() == 0 for obj in mines))

    def test_dot_area_effect_ticks_on_enemies_and_not_allies(self):
        source = FakeCharacter(1000000, 0, 100, 150)
        enemy = FakeCharacter(1000001, 16, 150, 150)
        ally = FakeCharacter(1000002, 1, 150, 150)
        battle = FakeBattle(FakeTileMap(), characters=[source, enemy, ally])
        manager = FakeManager(battle)
        battle.manager = manager
        effect = AreaEffect(17, 0)
        effect.data = {'Type': 'Dot', 'TimeMs': '1000', 'Radius': '100'}
        effect.radius = 100
        effect.attach(manager, 2000001)
        effect.set_position(100, 150, 0)
        effect.set_index(0)
        effect.set_source(source, 1)
        effect.damage = 100
        effect.normal_dmg = 100
        effect.trigger()
        for _ in range(19):
            effect.tick()
        self.assertEqual(enemy.hp, 1000)
        effect.tick()
        self.assertEqual(enemy.hp, 900)
        self.assertEqual(ally.hp, 1000)
        self.assertEqual(source.ulti_charge_gained, 100)

    def test_heal_and_damage_area_heals_team_and_damages_enemies(self):
        ally = FakeCharacter(1000001, 1, 120, 150)
        enemy = FakeCharacter(1000002, 16, 120, 150)
        battle = FakeBattle(FakeTileMap(), characters=[ally, enemy])
        manager = FakeManager(battle)
        battle.manager = manager
        effect = AreaEffect(17, 0)
        effect.data = {'Type': 'HealAndDamage', 'TimeMs': '250', 'Radius': '100'}
        effect.radius = 100
        effect.attach(manager, 2000001)
        effect.set_position(100, 150, 0)
        effect.set_index(0)
        effect.damage = 250
        effect.trigger()
        self.assertEqual(ally.hp, 1250)
        self.assertEqual(enemy.hp, 750)

    def test_active_nonmoving_skill_aligns_move_angle_when_attack_fires(self):
        battle = FakeBattle(FakeTileMap())
        owner = self._new_melee_owner(battle)
        owner.skills = [Skill('test', False)]
        owner.skills[0].data = {'CanMoveAtSameTime': 'false'}
        owner.skills[0].ticks_active = 1
        owner.left_hand = 0
        owner.rapid_fire_projectile = {'Name': 'test', 'Radius': '0', 'Speed': '3000'}
        owner.rapid_fire_bullets = 1
        owner.rapid_fire_spread = 0
        owner.rapid_fire_normal_dmg = 100
        owner.rapid_fire_attack_pattern = 0
        owner.rapid_fire_shoot_times = 1
        owner.shoot_index = 0
        owner.cripple_percent = 0
        owner.rapid_fire_range = 25
        with patch.object(Character, 'spawn_projectile', return_value=None):
            owner.fire_attack(100, 500, damage=100)
        self.assertEqual(owner.move_angle, 90)

    def test_casting_skill_flag_pauses_movement_and_default_allows_it(self):
        battle = FakeBattle(FakeTileMap(), ticks=7)
        owner = Character.__new__(Character)
        owner._manager = FakeManager(battle)
        owner.skills = []
        owner.casting_time = 100
        owner.move_start, owner.move_end = 5, 10
        skill = Skill('test', False)
        skill.data = {'CastingTime': '250', 'CanMoveAtSameTime': 'false'}
        skill.on_activate = True
        owner.skills = [skill]
        self.assertFalse(skill.can_move_at_same_time())
        owner.pause_movement_for_casting()
        self.assertEqual((owner.move_start, owner.move_end), (6, 11))
        skill.data['CanMoveAtSameTime'] = 'true'
        owner.pause_movement_for_casting()
        self.assertEqual((owner.move_start, owner.move_end), (6, 11))
        owner.casting_time = 50
        with patch.object(Skill, 'tick'):
            owner.tick_skills()
        self.assertEqual(owner.casting_time, 0)

    def test_character_can_finish_unobstructed_move(self):
        character = Character.__new__(Character)
        character._manager = FakeManager(FakeBattle(FakeTileMap(), ticks=10))
        character.data = {'CollisionRadius': 50}
        character.x, character.y = 150, 150
        character.way_point_start = (150, 150)
        character.way_point = (750, 150)
        character.path_length = 600
        character.move_start, character.move_end = 0, 10
        character.update_position()
        self.assertEqual((character.x, character.y), (750, 150))
        self.assertEqual(character.path_length, 0)

    def test_ultimate_passives_apply_larger_area_and_burn(self):
        """Test that larger_area_ulti, damage_buff_super, and ulti_burn are applied"""
        owner = Character.__new__(Character)
        owner._manager = None
        owner._index = 0
        owner.data = {}
        owner.star_power_data = {'Type': 'larger_area_ulti', 'Value': '50'}
        
        # Create a projectile
        projectile = Projectile.__new__(Projectile)
        projectile.data = {'Radius': '200'}
        projectile.radius = 200
        projectile.damage = 1000
        projectile.normal_dmg = 900
        projectile.owner = owner
        projectile.owner_index = 0
        projectile.skill_type = 2  # ultimate
        projectile.hit_objects = set()
        projectile.hit_cooldowns = {}
        projectile.target_hit_counts = {}
        projectile.ulti_burn_damage = 100
        projectile.ulti_burn_ticks = 40
        
        # Test larger_area_ulti
        larger_area = owner.get_card_value_for_passive('larger_area_ulti', 1)
        if larger_area >= 1:
            projectile.radius = projectile.radius * (100 + larger_area) // 100
        self.assertEqual(projectile.radius, 300)  # 200 * 1.5 = 300
        
        # Test damage_buff_super
        owner.star_power_data = {'Type': 'damage_buff_super', 'Value': '25'}
        damage_buff = owner.get_card_value_for_passive('damage_buff_super', 1)
        if damage_buff >= 1:
            projectile.damage = projectile.damage * (100 + damage_buff) // 100
        self.assertEqual(projectile.damage, 1250)  # 1000 * 1.25 = 1250
        
        # Test ulti_burn attributes exist on projectile
        self.assertEqual(projectile.ulti_burn_damage, 100)
        self.assertEqual(projectile.ulti_burn_ticks, 40)

    def test_super_passives_in_spawn_projectile(self):
        """Test that spawn_projectile applies super passives correctly"""
        from unittest.mock import patch
        
        battle = FakeBattle(FakeTileMap(), ticks=0)
        owner = Character.__new__(Character)
        owner._manager = FakeManager(battle)
        owner._index = 0
        owner.data = {}
        owner.star_power_data = {'Type': 'larger_area_ulti', 'Value': '30'}
        owner.using_ulti = True
        owner.x = 100
        owner.y = 100
        
        # Mock get_card_value_for_passive to return our test values
        def mock_get_card_value(self_char, passive, idx):
            values = {
                ('larger_area_ulti', 1): 30,
                ('damage_buff_super', 1): 20,
                ('ulti_burn', 1): 150,
                ('ulti_burn', 0): 60,
            }
            return values.get((passive, idx), -1)
        
        # Create a test projectile
        test_projectile = Projectile.__new__(Projectile)
        test_projectile.data = {'Radius': '100'}
        test_projectile.radius = 100
        test_projectile.damage = 500
        test_projectile.normal_dmg = 450
        test_projectile.owner = owner
        test_projectile.owner_index = 0
        test_projectile.skill_type = 2
        test_projectile.hit_objects = set()
        test_projectile.hit_cooldowns = {}
        test_projectile.target_hit_counts = {}
        test_projectile.ulti_burn_damage = 0
        test_projectile.ulti_burn_ticks = 0
        
        with patch.object(Character, 'get_card_value_for_passive', mock_get_card_value):
            with patch.object(Projectile, 'shoot_projectile', return_value=test_projectile):
                with patch.object(Projectile, 'run_early_ticks'):
                    result = owner.spawn_projectile(
                        battle, {'Name': 'TestUltiProjectile'}, 500, 500, 500, 450, 0, 0, True, 0, 0, 0
                    )
        
        # Verify passives were applied
        self.assertEqual(result.radius, 130)  # 100 * 1.3 = 130
        self.assertEqual(result.damage, 600)  # 500 * 1.2 = 600
        self.assertEqual(result.ulti_burn_damage, 150)
        self.assertEqual(result.ulti_burn_ticks, 60)

    def test_use_accessory_heal_type(self):
        """Test that heal accessory works correctly"""
        from G.Accessory import Accessory
        from unittest.mock import patch
        
        # Create a character with an accessory
        character = Character.__new__(Character)
        character._manager = None
        character._index = 0
        character.data = {}
        character.hp = 500
        character.max_hp = 1000
        character.attack_angle = 0
        
        # Create a fake player with accessory
        player = type('Player', (), {})()
        player.accessory = Accessory.__new__(Accessory)
        player.accessory.uses = 3
        player.accessory.cool_down = 0
        player.accessory.data = {
            'Type': 'heal',
            'CustomValue1': '400',
            'Cooldown': '140'
        }
        
        with patch.object(Character, 'get_player', return_value=player):
            with patch.object(Character, 'heal', return_value=True) as mock_heal:
                result = character.use_accessory()
        
        self.assertTrue(result)
        self.assertEqual(player.accessory.uses, 2)
        self.assertEqual(player.accessory.cool_down, 140)
        mock_heal.assert_called_once()

    def test_use_accessory_dash_type(self):
        """Test that dash accessory works correctly"""
        from G.Accessory import Accessory
        from unittest.mock import patch
        
        character = Character.__new__(Character)
        character._manager = None
        character._index = 0
        character.data = {}
        character.attack_angle = 0
        
        player = type('Player', (), {})()
        player.accessory = Accessory.__new__(Accessory)
        player.accessory.uses = 2
        player.accessory.cool_down = 0
        player.accessory.data = {
            'Type': 'dash',
            'CustomValue1': '1500',
            'Cooldown': '100'
        }
        
        with patch.object(Character, 'get_player', return_value=player):
            result = character.use_accessory()
        
        self.assertTrue(result)
        self.assertEqual(player.accessory.uses, 1)
        self.assertEqual(player.accessory.cool_down, 100)

    def test_use_accessory_spawn_with_area_effect(self):
        """Test that spawn accessory creates area effect"""
        from G.Accessory import Accessory
        from unittest.mock import patch, MagicMock
        
        character = Character.__new__(Character)
        character._manager = MagicMock()
        character._index = 0
        character.data = {}
        character.x = 100
        character.y = 200
        
        player = type('Player', (), {})()
        player.accessory = Accessory.__new__(Accessory)
        player.accessory.uses = 3
        player.accessory.cool_down = 0
        player.accessory.data = {
            'Type': 'spawn',
            'AreaEffect': 'TestAreaEffect',
            'Cooldown': '140'
        }
        
        with patch.object(Character, 'get_player', return_value=player):
            with patch('G.Character.AreaEffect') as mock_area_effect_class:
                mock_effect = MagicMock()
                mock_area_effect_class.return_value = mock_effect
                result = character.use_accessory()
        
        self.assertTrue(result)
        self.assertEqual(player.accessory.uses, 2)
        self.assertEqual(player.accessory.cool_down, 140)
        mock_area_effect_class.assert_called_once_with('TestAreaEffect')
        mock_effect.set_index.assert_called_once()
        mock_effect.set_position.assert_called_once_with(100, 200, 0)

    def test_use_accessory_shield_type(self):
        """Test that shield accessory applies shield"""
        from G.Accessory import Accessory
        from unittest.mock import patch
        
        character = Character.__new__(Character)
        character._manager = None
        character._index = 0
        character.data = {}
        character.shield_ticks = 0
        character.shield_percent = 0
        
        player = type('Player', (), {})()
        player.accessory = Accessory.__new__(Accessory)
        player.accessory.uses = 3
        player.accessory.cool_down = 0
        player.accessory.data = {
            'Type': 'shield',
            'ShieldPercent': '40',
            'ShieldTicks': '60',
            'Cooldown': '100'
        }
        
        with patch.object(Character, 'get_player', return_value=player):
            with patch.object(Character, 'add_shield') as mock_add_shield:
                result = character.use_accessory()
        
        self.assertTrue(result)
        self.assertEqual(player.accessory.uses, 2)
        self.assertEqual(player.accessory.cool_down, 100)
        mock_add_shield.assert_called_once_with(60, 40)


if __name__ == '__main__':
    unittest.main()
