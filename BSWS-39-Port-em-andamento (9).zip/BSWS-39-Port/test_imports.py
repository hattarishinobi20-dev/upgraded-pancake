#!/usr/bin/env python3
"""Script de diagnóstico de imports"""
import sys
import os

print("="*60)
print("DIAGNÓSTICO DE IMPORTS")
print("="*60)

# Verificar diretório atual
print(f"\nDiretório atual: {os.getcwd()}")
print(f"Python: {sys.version}")

# Verificar se está no diretório correto
if not os.path.exists('G/TileMapFactory.py'):
    print("\n❌ ERRO: Arquivo G/TileMapFactory.py não encontrado!")
    print("Certifique-se de estar no diretório BSWS-39-Port")
    sys.exit(1)

# Testar import
try:
    print("\n1. Testando import G.TileMapFactory...")
    import G.TileMapFactory
    print("   ✓ Módulo importado")
    
    print("\n2. Verificando atributos...")
    attrs = dir(G.TileMapFactory)
    print(f"   Atributos encontrados: {len(attrs)}")
    
    if 'create' in attrs:
        print("   ✓ Função 'create' encontrada")
    else:
        print("   ❌ ERRO: Função 'create' NÃO encontrada!")
        sys.exit(1)
    
    print("\n3. Testando chamada da função...")
    tilemap = G.TileMapFactory.create(1)
    print(f"   ✓ TileMap criado: {tilemap.width}x{tilemap.height}")
    
    print("\n4. Testando BattleMode import...")
    from G.BattleMode import BattleMode
    print("   ✓ BattleMode importado")
    
    print("\n" + "="*60)
    print("✓✓✓ TODOS OS IMPORTS FUNCIONANDO ✓✓✓")
    print("="*60)
    
except Exception as e:
    print(f"\n❌ ERRO: {e}")
    import traceback
    traceback.print_exc()
    sys.exit(1)
