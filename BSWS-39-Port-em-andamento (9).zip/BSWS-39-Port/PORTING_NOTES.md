# Notas do port — ataques e movimentação v39

Este diretório mantém a arquitetura, dados e protocolo Python v39 do BSWS-39, portando comportamentos de batalha seletivamente a partir das referências C#. Referências consultadas: `allbrawl/ProjectColette-public` (`120070e5b5fa18471e562158f3a58ae711c2d911`), `xmopser/GuitarBrawl` (`f73a68dca7e796d1760db6b01b4ddd29dde05ad4`) e BSWSV39 (`1dc98542b505d63e2366ed4745128a3cb01fb3aa`). Os repositórios C# ajudam a confirmar comportamento, mas não substituem a engine Python nem seus dados/protocolo v39.

## Portes e correções presentes

- Movimento de personagem e knockback varridos contra geometria, limites do mapa e tiles bloqueadores; projéteis usam varredura de colisão por segmento para não atravessar paredes/alvos entre ticks.
- Raio de projétil respeita `ScaleStart`/`ScaleEnd`; dados de dono/equipe são preservados nos projéteis e efeitos.
- Efeitos de projétil validam e acionam `SpawnAreaEffectObject` e `SpawnAreaEffectObject2`, sem inferir dano genérico a partir do raio de colisão. Áreas cobrem dano/cura, equipe, empurrão e estados básicos.
- Ataques incluem padrões observados nos dados primários, espalhamento/rajadas, lanes paralelas de `AttackPattern=7`, melee sem projétil, carga da arma de Undertaker e bônus aditivos de `damage_main_attack`/`gain_damage_super` e `ambush` em arbusto.
- `DamageOnlyWithOneProj` compartilha registros de alvos/cooldown; dano ao longo do trajeto usa `DamagePercentStart`/`DamagePercentEnd`; dano repetido respeita `DamagesConstantlyTickDelay`.
- Projéteis incluem homing/steering, retorno, cadeia, explosões, recochete e trajetória indireta. A aritmética de `ConstantFlyTime` usa o tempo fixo de `GetTravelTicks`; a trajetória de TNT com bounce usa a equação por trechos e o cálculo de altura da referência.
- Projéteis e áreas podem aplicar cura a aliados, dano a inimigos, poison, stun, slow/freeze-strength e lifesteal; `SuppressHealing` reduz cura recebida durante o tempo configurado.
- Exceções verificadas: StickyBomb cria e detona item ao detectar inimigo no raio; Bea carrega/consome o tiro secundário e recarrega ao acertar; Colette calcula dano percentual pela vida atual do herói e aplica buffs/debuffs e mínimo segundo a ordem da função C#.
- Testes de cobertura registram referências de habilidades e projéteis dos 58 heróis, incluindo projéteis secundários e campos de referência de área/cadeia.

## Validação disponível

Executar a partir de `/home/user`:

```sh
python -m unittest discover -s BSWS-39-Port/tests -v
python -m compileall -q BSWS-39-Port
```

Última execução: **44 testes aprovados**, `compileall` sem erros.

## Status e limitações abertas

A Etapa 1 continua **em andamento**. A contagem de referências e os testes provam apenas a cobertura dos caminhos efetivamente testados; ainda é necessário terminar a comparação por brawler de todas as rotas de ataque, movimentação e combinações de colisão/estado. Não concluir a etapa nem distribuir os pacotes como finais até concluir essa auditoria, adicionar os testes restantes e validar de novo.

Os arquivos `BSWS-39-movement-projectiles.patch` e `BSWS-39-movement-projectiles-port.zip` ainda precisam ser regenerados depois de fechar a cobertura. Os repositórios C# usados como referência são GPL-3.0; o diretório inclui o texto da licença e deve mantê-lo em redistribuições derivadas.
