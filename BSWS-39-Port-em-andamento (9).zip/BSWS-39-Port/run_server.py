#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Script de inicialização do servidor BSWS v39
Com diagnóstico completo de imports
"""
import sys
import os

def check_environment():
    """Verifica o ambiente de execução"""
    print("="*60)
    print("BSWS v39 - Servidor de Brawl Stars")
    print("="*60)
    print(f"\nPython: {sys.version}")
    print(f"Diretório: {os.getcwd()}")
    
    # Verificar se está no diretório correto
    if not os.path.exists('Core.py'):
        print("\n❌ ERRO: Core.py não encontrado!")
        print("Certifique-se de estar no diretório BSWS-39-Port")
        return False
    
    if not os.path.exists('G/__init__.py'):
        print("\n❌ ERRO: G/__init__.py não encontrado!")
        return False
    
    return True

def check_imports():
    """Verifica todos os imports críticos"""
    print("\nVerificando imports...")
    
    critical_imports = [
        ('G.TileMapFactory', 'create'),
        ('G.BattleMode', 'BattleMode'),
        ('G.Character', 'Character'),
        ('G.Projectile', 'Projectile'),
        ('G.Skill', 'Skill'),
        ('G.AreaEffect', 'AreaEffect'),
        ('G.Accessory', 'Accessory'),
    ]
    
    for module_name, attr in critical_imports:
        try:
            module = __import__(module_name, fromlist=[attr])
            if not hasattr(module, attr):
                print(f"  ❌ {module_name}.{attr} não encontrado")
                return False
        except ImportError as e:
            print(f"  ❌ Erro ao importar {module_name}: {e}")
            return False
        except Exception as e:
            print(f"  ❌ Erro inesperado em {module_name}: {e}")
            return False
    
    print("  ✓ Todos os imports OK")
    return True

def start_server():
    """Inicia o servidor"""
    print("\nIniciando servidor...")
    try:
        from Core import Core
        server = Core()
        server.CoreInit()
    except KeyboardInterrupt:
        print("\n\nServidor encerrado pelo usuário")
    except Exception as e:
        print(f"\n❌ Erro ao iniciar servidor: {e}")
        import traceback
        traceback.print_exc()
        return False
    return True

def main():
    """Função principal"""
    if not check_environment():
        sys.exit(1)
    
    if not check_imports():
        print("\n❌ Falha na verificação de imports")
        sys.exit(1)
    
    print("\n✓ Verificação completa concluída")
    
    if not start_server():
        sys.exit(1)

if __name__ == '__main__':
    main()
