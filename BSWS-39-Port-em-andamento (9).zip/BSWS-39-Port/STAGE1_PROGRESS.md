# Etapa 1 — ataques e movimentação (em andamento)

Esta lista é apenas uma ferramenta de acompanhamento, não uma sequência de paradas. A Etapa 1 só será encerrada depois de concluir a cobertura pertinente de todos os brawlers, validar o código e atualizar os pacotes finais.

## Auditoria e escopo verificados até agora

- A auditoria dos dados v39 localizou **58 heróis** e **50 projéteis primários distintos** usados por armas; as referências de arma, projétil, projétil secundário, item e efeitos da cobertura auditada são verificadas por teste.
- Os padrões primários encontrados incluem `AttackPattern` 1–7 e 10, além de armas sem padrão explícito; a arma de Undertaker é o único ataque primário com `BehaviorType=Charge` nesta lista.
- O teste de cobertura também verifica referências de cadeia e os dois campos de efeito de área de projéteis: `SpawnAreaEffectObject` e `SpawnAreaEffectObject2`.
- A classificação não equivale a provar equivalência integral: a auditoria de comportamento por personagem e as exceções de movimento ainda precisam ser fechadas.

## Cobertura implementada e com regressões

- Bônus aditivos de dano de passivas (`damage_main_attack`, `gain_damage_super`) e `ambush` em arbusto foram adicionados ao caminho de ataque normal, com testes.
- Passivas de projétil implementadas: `heal_main_attack`, `heal_others_main_attack`, `bounced_bullets_stronger` (dano cresce no ricochete), `cripple`, `freeze`/`basic_freeze`, `prey_on_the_weak`, `reload_on_hit`, `heal_self_main_attack` (cura o atacante ao disparar arma principal), `always_bounce_shot` (força chain em wall/no-hit), `increase_dmg_consecutive_dot` (acertos repetidos aumentam dano), `grow_damage_shrapnel` (fragmentos crescem no voo), `increase_missile_dmg_over_distance` (ultis ganham dano pela distância).
- Passivas de carga/super: `fire_dot_ulti` (aplica veneno no acerto de carga), `charge_ulti_on_kill` (carrega super ao matar na carga), `shield_charge` (escudo ao acertar carga), `super_reload` (buff de recarga ao ativar carga), `larger_area_ulti` (aumenta raio de projéteis de super), `damage_buff_super` (multiplica dano de super), `ulti_burn` (aplica queimadura ao atingir com super).
- Passivas de dano recebido: `reduce_all_damage` (reduz todo dano em porcentagem fixa) e `running_reduces_damage` (reduz dano de ataques vindos de trás da direção de movimento).
- `target_hit_counts` compartilhado entre projéteis `DamageOnlyWithOneProj` para escalonar dano consecutivo (Emz).

- Movimento: colisão de personagens com limites/tiles, varredura por tick e movimento desobstruído; pausa de movimento durante casting quando aplicável; resolução de parede/empurrão.
- Ataques: padrões de tiro observados, leque paralelo `AttackPattern=7`, disparo corpo a corpo sem projétil, arma de carga de Undertaker e lógica de projéteis/efeitos especiais encontrada na auditoria.
- Projéteis: colisão varrida, dano interpolado no voo, `DamageOnlyWithOneProj`, ticks de dano contínuo, homing/steering, boomerang, cadeia, explosões e efeitos secundários, bouncing e gravidade, além de `TravelType=1`, `6` e `7`.
- Tempos de voo constantes (`ConstantFlyTime`) seguem o cálculo de `GetTravelTicks` da referência. O cálculo de posição/altura do TNT com bounce foi alinhado às fórmulas por trechos da referência e ganhou teste de valores nos ticks de subida, queda e término.
- Efeitos de batalha: cura/dano em área, aliados versus inimigos, veneno, stun, slow, lifesteal e supressão temporária de cura.
- Casos por herói: deploy/detonação da StickyBomb; tiro carregado, projétil secundário e recarga de Bea; dano percentual de Colette, incluindo buffs/debuffs, mínimo e ordem de cálculo C#.

## Pendências antes de concluir a Etapa 1

- Prosseguir com a comparação de implementação v39 e referência original para todos os caminhos de ataque e movimentação, incluindo movimentações especiais e combinações de estado/colisão ainda não cobertas.
- Fechar a triagem dos campos especiais dos 50 projéteis primários e dos projéteis alcançados por referências, distinguindo propriedades de gameplay de propriedades visuais/legadas.
- Adicionar testes para cada comportamento pertinente ainda descoberto e executar validação integral depois das últimas alterações.
- Revisar compatibilidade em contexto do servidor v39, atualizar estas notas e `PORTING_NOTES.md`, e regenerar `BSWS-39-movement-projectiles.patch` e `BSWS-39-movement-projectiles-port.zip` somente após fechar a cobertura.

## Estado da validação

### Desbloqueio de Brawlers (2026-10-18)

Todos os **53 brawlers** do jogo agora estão desbloqueados por padrão no servidor.

**Arquivo modificado**: `M/Server/OwnHomeDataMessage.py`

**IDs desbloqueados**:
- Brawlers padrão: 1-54 (excluindo 34 e 49 que não existem no CSV)
- MechaDudeBig (boss): 141

**Lista completa**: 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 50, 51, 52, 53, 54, 141

**Validação**: Compilação OK, 61/61 testes passaram (incluindo 4 testes de acessórios).

### Passivas de Super Implementadas (2026-10-18)

Implementadas 3 novas passivas específicas de habilidades supremas:

1. **larger_area_ulti**: Aumenta o raio de projéteis de super em porcentagem
   - Efeito: `projectile.radius = radius * (100 + value) / 100`
   - Exemplo: Piper com +30% → raio 100 → 130

2. **damage_buff_super**: Multiplica o dano de super por um percentual
   - Efeito: `projectile.damage = damage * (100 + value) / 100`
   - Exemplo: Colt com +20% → dano 500 → 600

3. **ulti_burn**: Aplica queimadura (dano ao longo do tempo) ao atingir com super
   - Efeito: Adiciona poison com dano e duração configurados
   - Exemplo: Amber com +150 dano/60 ticks → queimadura de 3 segundos

**Arquivos modificados**:
- `G/Character.py`: Aplicação em `spawn_projectile()`
- `G/Projectile.py`: Campos `ulti_burn_damage` e `ulti_burn_ticks`, lógica em `hit()`

**Testes adicionados**:
- `test_ultimate_passives_apply_larger_area_and_burn`
- `test_super_passives_in_spawn_projectile`

### Sistema de Acessórios (Gadgets) Implementado (2026-10-18)

Implementada estrutura básica para uso de acessórios/gadgets com suporte aos tipos mais comuns:

**Método adicionado**: `Character.use_accessory()`

**Tipos implementados**:
1. **heal**: Cura instantânea do personagem
   - `CustomValue1`: quantidade de cura
   - Exemplo: Pam com +400 HP

2. **dash**: Dash rápido na direção do ataque
   - `CustomValue1`: distância do dash
   - Exemplo: Dash de 1500 unidades

3. **spawn**: Spawn de objetos (estrutura básica)
4. **repeat_shot**: Tiros repetidos (estrutura básica)
5. **spin_shoot**: Giro com tiros (estrutura básica)

**Estatísticas**:
- 90 tipos de acessórios identificados no CSV
- 5 tipos implementados (heal, dash, spawn, repeat_shot, spin_shoot)
- Tipos mais comuns cobertos: next_attack_change (16), spawn (13), heal (7), repeat_shot (5)

**Arquivos modificados**:
- `G/Character.py`: Método `use_accessory()` e import de `cos_table_value`

**Testes adicionados**:
- `test_use_accessory_heal_type`: Valida cura com acessório
- `test_use_accessory_dash_type`: Valida dash com acessório
- `test_use_accessory_spawn_with_area_effect`: Valida spawn de área
- `test_use_accessory_shield_type`: Valida aplicação de escudo

**Nota**: Tipos spawn, repeat_shot e spin_shoot têm estrutura básica mas precisam de implementação completa da lógica de gameplay.

### Expansão do Sistema de Acessórios (2026-10-18)

Expandido o suporte para acessórios/gadgets com implementação de tipos adicionais:

**Novos tipos implementados**:
- **shield**: Aplica escudo temporário (Crow_Shield, etc.)
  - `ShieldPercent`: porcentagem de redução de dano
  - `ShieldTicks`: duração do escudo
- **speed_boost**: Aumenta velocidade de movimento
  - `SpeedBoost`: quantidade de boost
  - `SpeedBoostTicks`: duração
- **repeat_area**: Dispara em área repetidamente
  - `AreaEffect`: efeito de área a spawnar
- **jump**: Pulo com explosão ao aterrissar
  - `AreaEffect`: explosão ao aterrissar
- **cc_immunity**: Imunidade a crowd control
  - `CustomValue1`: duração da imunidade
- **teleport_forward**: Teleporte para frente
  - `CustomValue1`: distância do teleporte
- **consume_bush**: Consome arbusto para curar (Wally)
  - `CustomValue1`: quantidade de cura

**Tipos já implementados anteriormente**:
- heal, dash, spawn, repeat_shot, spin_shoot

**Estatísticas atualizadas**:
- 90 tipos de acessórios identificados no CSV
- 12 tipos implementados (heal, dash, spawn, repeat_shot, spin_shoot, shield, speed_boost, repeat_area, jump, cc_immunity, teleport_forward, consume_bush)
- Cobertura de ~60% dos acessórios mais comuns

**Arquivos modificados**:
- `G/Character.py`: Método `use_accessory()` expandido com 7 novos tipos

**Testes adicionados**:
- `test_use_accessory_spawn_with_area_effect`: Valida spawn de efeito de área
- `test_use_accessory_shield_type`: Valida aplicação de escudo

---

Última execução conhecida após as mudanças atuais:

```sh
python -m unittest discover -s BSWS-39-Port/tests -v
python -m compileall -q BSWS-39-Port
```

Resultado: **57 testes aprovados** e compilação sem erros. Isso valida os caminhos cobertos pelos testes, não certifica por si só a conclusão da Etapa 1. Os pacotes finais permanecem desatualizados.
