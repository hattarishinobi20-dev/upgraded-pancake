# Instruções de Execução - BSWS v39

## ⚠️ Problema de Import Resolvido

O erro `ImportError: cannot import name 'create' from 'G.TileMapFactory'` foi causado por:
- Arquivo possivelmente corrompido durante download/extração
- Ambiente Python sem suporte a encoding UTF-8

## ✅ Solução Aplicada

1. **Arquivo corrigido**: `G/TileMapFactory.py` foi reescrito com:
   - Declaração de encoding UTF-8
   - Docstrings em todas as funções
   - Lista `__all__` para exportação explícita
   - Tratamento de casos edge

2. **Script de inicialização**: `run_server.py` criado com:
   - Diagnóstico completo de imports
   - Verificação de ambiente
   - Mensagens de erro claras
   - Tratamento de exceções

## 📱 Como Executar no Celular

### Passo 1: Extrair o ZIP
```bash
# Descompacte o arquivo BSWS-39-Port-em-andamento.zip
# Certifique-se de que a estrutura esteja correta:
#   BSWS-39-Port/
#     ├── Core.py
#     ├── run_server.py  ← NOVO!
#     ├── G/
#     │   ├── __init__.py
#     │   ├── TileMapFactory.py
#     │   └── ...
#     └── ...
```

### Passo 2: Navegar para o Diretório
```bash
cd /storage/emulated/0/Download/BSWS-39-Port-em-andamento/BSWS-39-Port
```

### Passo 3: Executar o Script de Diagnóstico
```bash
python3 test_imports.py
```

Se aparecer "✓✓✓ TODOS OS IMPORTS FUNCIONANDO ✓✓✓", está tudo OK!

### Passo 4: Iniciar o Servidor
```bash
python3 run_server.py
```

Você deve ver:
```
============================================================
BSWS v39 - Servidor de Brawl Stars
============================================================

Python: 3.x.x
Diretório: /caminho/para/BSWS-39-Port

Verificando imports...
  ✓ Todos os imports OK

✓ Verificação completa concluída

Iniciando servidor...
+ server :9339
```

## 🔍 Diagnóstico de Problemas

### Erro: "cannot import name 'create'"

**Causa provável:**
- Arquivo corrompido
- Encoding incorreto
- Cache Python (.pyc) antigo

**Solução:**
```bash
# 1. Limpar cache
find . -type d -name "__pycache__" -exec rm -rf {} +
find . -name "*.pyc" -delete

# 2. Verificar arquivo
cat G/TileMapFactory.py | head -5

# Deve mostrar:
# # -*- coding: utf-8 -*-
# """Factory para criar TileMaps a partir de dados de mapa"""
# from G.TileMap import TileMap
# from G.Assets import get_map_rows, get_map_rows_by_name

# 3. Testar import direto
python3 -c "from G.TileMapFactory import create; print('OK')"
```

### Erro: "No module named 'G'"

**Causa:**
- Não está no diretório correto
- Falta arquivo `G/__init__.py`

**Solução:**
```bash
# Verificar diretório atual
pwd

# Deve ser algo como: /storage/emulated/0/Download/BSWS-39-Port-em-andamento/BSWS-39-Port

# Verificar arquivo __init__.py
ls -la G/__init__.py

# Se não existir, criar:
touch G/__init__.py
```

### Erro: "SyntaxError" em arquivos

**Causa:**
- Encoding incorreto
- Caracteres especiais

**Solução:**
```bash
# Re-extrair o ZIP
# Ou usar o arquivo original do repositório
```

## 🧪 Testes

Para executar os testes automatizados:
```bash
python3 -m pytest tests/ -v
```

Resultado esperado:
```
==================== 61 passed, 3 subtests passed in 0.10s =====================
```

## 📋 Arquivos Corrigidos

- ✅ `G/TileMapFactory.py` - Reescrito com encoding e exportação explícita
- ✅ `run_server.py` - Novo script de inicialização com diagnóstico
- ✅ `test_imports.py` - Script de teste de imports

## 🆘 Suporte

Se ainda houver problemas:

1. Verifique a versão do Python:
   ```bash
   python3 --version
   ```
   Deve ser Python 3.8 ou superior.

2. Execute o script de diagnóstico:
   ```bash
   python3 test_imports.py
   ```

3. Envie a saída completa do erro para análise.

---

**Última atualização:** 2026-10-18
