import socket
import sys
import threading

import G.Matchmaking as Matchmaking
import G.Sessions as Sessions
import L.Udp as Udp
from M.Battle.ClientInputMessage import ClientInputMessage
from M.LogicMessageFactory import identifiers


class Core:
    def __init__(self):
        self.server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

    def CoreInit(self):
        if len(sys.argv) > 1:
            Udp.set_public_host(sys.argv[1])
        self.server.bind(('0.0.0.0', 9339))
        Udp.init()
        Udp.register_handler(ClientInputMessage.id, ClientInputMessage)
        Matchmaking.init()
        print("+ server :9339")
        try:
            while True:
                self.server.listen()
                sock, address = self.server.accept()
                print(f"+ {address[0]}")
                CoreClient(sock, address).start()
        except KeyboardInterrupt:
            print("- server")
            self.server.close()


class CoreClient(threading.Thread):
    def __init__(self, client, address):
        super().__init__(daemon=True)
        self.address              = address
        self.client               = client
        self.is_open              = True
        self.matchmake_slot       = -1
        self.matchmaking_entry    = None
        self.player_name          = "BSWS"
        self.account_id           = 1
        self.character_global_id  = 16000000
        self.skin_global_id       = 0
        self.hero_power_level     = 9
        self.player_status        = 0
        self.last_keep_alive      = 0.0
        self.udp_session_id       = Udp.create_session()
        Udp.register(self.udp_session_id, self)

    def recv(self, n):
        data = bytearray()
        while len(data) < n:
            packet = self.client.recv(n - len(data))
            if not packet:
                return None
            data.extend(packet)
        return data

    def read_header(self):
        packetInfo = self.client.recv(7)
        if len(packetInfo):
            packet_identifier = int.from_bytes(packetInfo[:2], 'big')
            length            = int.from_bytes(packetInfo[2:5], 'big')
            data              = self.recv(length)

            if packet_identifier in identifiers:
                message = identifiers[packet_identifier](self, data)
                message.decode()
                message.process()
            else:
                print(f"? {packet_identifier}")

    def run(self):
        Sessions.add(self)
        try:
            while True:
                self.read_header()
        except (ConnectionAbortedError, ConnectionResetError, TimeoutError, OSError) as e:
            self.is_open = False
            Sessions.remove(self)
            Udp.unregister(self.udp_session_id)
            print(f"- {self.address[0]}  {type(e).__name__.lower()}")
            self.client.close()


if __name__ == '__main__':
    server = Core()
    server.CoreInit()
